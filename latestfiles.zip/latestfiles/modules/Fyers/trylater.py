import pandas as pd
from fyers_apiv3 import fyersModel
import datetime as dt
import pytz
import numpy as np
import time

import json
import os

from scipy.signal import argrelextrema
import numpy as np


#generate trading session
client_id = open("client_id.txt",'r').read()
access_token = open("access_token.txt",'r').read()
# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")



def save_to_json(data, filename):
    # Custom handler for non-serializable objects
    def default_serializer(o):
        if isinstance(o, np.bool_):  # Convert numpy bool to Python bool
            return bool(o)
        elif isinstance(o, bool):
            return o  # Python bools are serializable by default
        raise TypeError(f"Type {type(o)} not serializable")

    with open(filename, 'w') as f:
        json.dump(data, f, indent=4, default=default_serializer)


def load_from_json(filename='indicator_values.json'):
    if os.path.exists(filename):
        with open(filename, 'r') as f:
            return json.load(f)
    return {}



def fetchOHLC2(ticker, interval, duration):
    range_from = dt.date.today() - dt.timedelta(duration)
    range_to = dt.date.today()

    from_date_string = range_from.strftime("%Y-%m-%d")
    to_date_string = range_to.strftime("%Y-%m-%d")
    data = {
        "symbol": ticker,
        "resolution": interval,
        "date_format": "1",
        "range_from": from_date_string,
        "range_to": to_date_string,
        "cont_flag": "1"
    }

    response = fyers.history(data=data)['candles']

    # Create a DataFrame
    columns = ['Timestamp', 'Open', 'High', 'Low', 'Close', 'Volume']
    df = pd.DataFrame(response, columns=columns)

    # Convert Timestamp to datetime in UTC
    df['Timestamp2'] = pd.to_datetime(df['Timestamp'], unit='s').dt.tz_localize(pytz.utc)

    # Convert Timestamp to IST
    ist = pytz.timezone('Asia/Kolkata')
    df['Timestamp2'] = df['Timestamp2'].dt.tz_convert(ist)
    df.drop(columns=['Timestamp'], inplace=True)

    return df


def bollinger_bands(df, window=20, width=2):
    """Calculate Bollinger Bands."""
    rolling_mean = df['Close'].rolling(window=window).mean()
    rolling_std = df['Close'].rolling(window=window).std()
    df['BB_upper'] = rolling_mean + (rolling_std * width)
    df['BB_lower'] = rolling_mean - (rolling_std * width)
    return df


def ema(df, window=21):
    df[f"EMA{window}"] = df['Close'].ewm(span=window, adjust=False).mean()
    return df


def atr(DF, n):
    df = DF.copy()
    df['High-Low'] = abs(df['High'] - df['Low'])
    df['High-PrevClose'] = abs(df['High'] - df['Close'].shift(1))
    df['Low-PrevClose'] = abs(df['Low'] - df['Close'].shift(1))
    df['TR'] = df[['High-Low', 'High-PrevClose', 'Low-PrevClose']].max(axis=1, skipna=False)
    df['ATR'] = df['TR'].ewm(com=n, min_periods=n).mean()
    return df['ATR']


# def supertrend(DF, period=21, multiplier=1):
#    # global supertrend_up, supertrend_down, supertrend

#     df = DF.copy()
#     df['ATR'] = atr(df, period)
#     df["BasicUpper"] = ((df['High'] + df['Low']) / 2) + multiplier * df['ATR']
#     df["BasicLower"] = ((df['High'] + df['Low']) / 2) - multiplier * df['ATR']
#     df["FinalUpper"] = df["BasicUpper"]
#     df["FinalLower"] = df["BasicLower"]

#     ind = df.index
#     for i in range(period, len(df)):
#         if df['Close'][i - 1] <= df['FinalUpper'][i - 1]:
#             df.loc[ind[i], 'FinalUpper'] = min(df['BasicUpper'][i], df['FinalUpper'][i - 1])
#         else:
#             df.loc[ind[i], 'FinalUpper'] = df['BasicUpper'][i]

#     for i in range(period, len(df)):
#         if df['Close'][i - 1] >= df['FinalLower'][i - 1]:
#             df.loc[ind[i], 'FinalLower'] = max(df['BasicLower'][i], df['FinalLower'][i - 1])
#         else:
#             df.loc[ind[i], 'FinalLower'] = df['BasicLower'][i]

#     df['Strend'] = np.nan
#     for test in range(period, len(df)):
#         if df['Close'][test - 1] <= df['FinalUpper'][test - 1] and df['Close'][test] > df['FinalUpper'][test]:
#             df.loc[ind[test], 'Strend'] = df['FinalLower'][test]
#             break
#         if df['Close'][test - 1] >= df['FinalLower'][test - 1] and df['Close'][test] < df['FinalLower'][test]:
#             df.loc[ind[test], 'Strend'] = df['FinalUpper'][test]
#             break

#     for i in range(test + 1, len(df)):
#         if df['Strend'][i - 1] == df['FinalUpper'][i - 1] and df['Close'][i] <= df['FinalUpper'][i]:
#             df.loc[ind[i], 'Strend'] = df['FinalUpper'][i]
#         elif df['Strend'][i - 1] == df['FinalUpper'][i - 1] and df['Close'][i] >= df['FinalUpper'][i]:
#             df.loc[ind[i], 'Strend'] = df['FinalLower'][i]
#         elif df['Strend'][i - 1] == df['FinalLower'][i - 1] and df['Close'][i] >= df['FinalLower'][i]:
#             df.loc[ind[i], 'Strend'] = df['FinalLower'][i]
#         elif df['Strend'][i - 1] == df['FinalLower'][i - 1] and df['Close'][i] <= df['FinalLower'][i]:
#             df.loc[ind[i], 'Strend'] = df['FinalUpper'][i]

#     #supertrend_up = df['FinalUpper'].iloc[-1]
#     #supertrend_down = df['FinalLower'].iloc[-1]
#     #supertrend = df['Strend'].iloc[-1]
#     supertrend_data = df['Strend']
#     supertrend_data = supertrend_data.fillna(0)


    # return supertrend_data



def supertrend(DF, period=21, multiplier=1):
    df = DF.copy()
    df['ATR'] = atr(df, period)
    df["BasicUpper"] = ((df['High'] + df['Low']) / 2) + multiplier * df['ATR']
    df["BasicLower"] = ((df['High'] + df['Low']) / 2) - multiplier * df['ATR']
    df["FinalUpper"] = df["BasicUpper"]
    df["FinalLower"] = df["BasicLower"]

    ind = df.index
    for i in range(period, len(df)):
        if df['Close'][i - 1] <= df['FinalUpper'][i - 1]:
            df.loc[ind[i], 'FinalUpper'] = min(df['BasicUpper'][i], df['FinalUpper'][i - 1])
        else:
            df.loc[ind[i], 'FinalUpper'] = df['BasicUpper'][i]

    for i in range(period, len(df)):
        if df['Close'][i - 1] >= df['FinalLower'][i - 1]:
            df.loc[ind[i], 'FinalLower'] = max(df['BasicLower'][i], df['FinalLower'][i - 1])
        else:
            df.loc[ind[i], 'FinalLower'] = df['BasicLower'][i]

    df['Strend'] = np.nan
    df['st21UP'] = np.nan  # Initialize st21UP
    df['st21DN'] = np.nan  # Initialize st21DN

    for test in range(period, len(df)):
        if df['Close'][test - 1] <= df['FinalUpper'][test - 1] and df['Close'][test] > df['FinalUpper'][test]:
            df.loc[ind[test], 'Strend'] = df['FinalLower'][test]
            df.loc[ind[test], 'st21UP'] = df['FinalLower'][test]  # Assign st21UP
            break
        if df['Close'][test - 1] >= df['FinalLower'][test - 1] and df['Close'][test] < df['FinalLower'][test]:
            df.loc[ind[test], 'Strend'] = df['FinalUpper'][test]
            df.loc[ind[test], 'st21DN'] = df['FinalUpper'][test]  # Assign st21DN
            break

    for i in range(test + 1, len(df)):
        if df['Strend'][i - 1] == df['FinalUpper'][i - 1] and df['Close'][i] <= df['FinalUpper'][i]:
            df.loc[ind[i], 'Strend'] = df['FinalUpper'][i]
            df.loc[ind[i], 'st21UP'] = np.nan  # st21UP remains NaN if not updated
            df.loc[ind[i], 'st21DN'] = np.nan  # st21DN remains NaN if not updated
        elif df['Strend'][i - 1] == df['FinalUpper'][i - 1] and df['Close'][i] >= df['FinalUpper'][i]:
            df.loc[ind[i], 'Strend'] = df['FinalLower'][i]
            df.loc[ind[i], 'st21UP'] = df['FinalLower'][i]  # Update st21UP on trend change
        elif df['Strend'][i - 1] == df['FinalLower'][i - 1] and df['Close'][i] >= df['FinalLower'][i]:
            df.loc[ind[i], 'Strend'] = df['FinalLower'][i]
            df.loc[ind[i], 'st21DN'] = np.nan  # st21DN remains NaN if not updated
        elif df['Strend'][i - 1] == df['FinalLower'][i - 1] and df['Close'][i] <= df['FinalLower'][i]:
            df.loc[ind[i], 'Strend'] = df['FinalUpper'][i]
            df.loc[ind[i], 'st21DN'] = df['FinalUpper'][i]  # Update st21DN on trend change

    # Replace NaN with 0 for consistent results
    df['Strend'] = df['Strend'].fillna(0)
    df['st21UP'] = df['st21UP'].fillna(0)
    df['st21DN'] = df['st21DN'].fillna(0)

    return df[['Strend', 'st21UP', 'st21DN']]



def calculate_heikin_ashi(df):
    """
    Calculate Heikin-Ashi candles from a given OHLC DataFrame.
    
    Parameters:
    df (pd.DataFrame): A DataFrame with columns ['Open', 'High', 'Low', 'Close']
    
    Returns:
    pd.DataFrame: A DataFrame with additional columns for Heikin-Ashi Open, High, Low, Close, and Trend (green/red).
    """
    
    # Initialize the Heikin-Ashi DataFrame
    ha_df = df.copy()

    # Calculate HA Close as the average of Open, High, Low, and Close
    ha_df['HA_Close'] = (df['Open'] + df['High'] + df['Low'] + df['Close']) / 4

    # Initialize HA Open with the first Open price
    ha_df['HA_Open'] = (df['Open'].shift(1) + df['Close'].shift(1)) / 2

    # Fix for the FutureWarning: Assign fillna result back to the column without inplace modification
    ha_df['HA_Open'] = ha_df['HA_Open'].fillna((df['Open'] + df['Close']) / 2)  # For the first row
    
    # Calculate HA High and HA Low
    ha_df['HA_High'] = ha_df[['High', 'HA_Open', 'HA_Close']].max(axis=1)
    ha_df['HA_Low'] = ha_df[['Low', 'HA_Open', 'HA_Close']].min(axis=1)
    
    # Determine the color of the Heikin-Ashi candle: 'green' if HA_Open < HA_Close, 'red' otherwise
    ha_df['ha_trend'] = np.where(ha_df['HA_Open'] < ha_df['HA_Close'], 'green', 'red')
    
    return ha_df[['HA_Open', 'HA_High', 'HA_Low', 'HA_Close', 'ha_trend']]


# def calculate_atr(df, n=14):
#     """
#     Calculate the Average True Range (ATR) over a specified period.
#     """
#     df['High-Low'] = abs(df['High'] - df['Low'])
#     df['High-PrevClose'] = abs(df['High'] - df['Close'].shift(1))
#     df['Low-PrevClose'] = abs(df['Low'] - df['Close'].shift(1))
#     df['TR'] = df[['High-Low', 'High-PrevClose', 'Low-PrevClose']].max(axis=1)
#     df['ATR'] = df['TR'].rolling(window=n).mean()
#     return df['ATR']

def calculate_support_resistance(df, period=20):
    """
    Calculate support and resistance levels based on the lowest low and highest high over a specified period.
    """
    df['Support'] = df['Low'].rolling(window=period).min()
    df['Resistance'] = df['High'].rolling(window=period).max()
    return df

# def apply_trading_logic(df, atr_multiple=1.5):
#     """
#     Apply trading logic using ATR with support and resistance levels.
#     """
#     df['Signal'] = None
#     df['Stop_Loss'] = None
#     df['Position_Size'] = None

#     for i in range(1, len(df)):
#         if df['Close'].iloc[i] > df['Resistance'].iloc[i-1] and df['ATR'].iloc[i] > df['ATR'].mean():
#             df.loc[i, 'Signal'] = 'Buy'
#             df.loc[i, 'Stop_Loss'] = df.loc[i-1, 'Resistance'] - atr_multiple * df.loc[i, 'ATR']
#             df.loc[i, 'Position_Size'] = 1 / df.loc[i, 'ATR']
#         elif df['Close'].iloc[i] < df['Support'].iloc[i-1] and df['ATR'].iloc[i] < df['ATR'].mean():
#             df.loc[i, 'Signal'] = 'Sell'
#             df.loc[i, 'Stop_Loss'] = df.loc[i-1, 'Support'] + atr_multiple * df.loc[i, 'ATR']
#             df.loc[i, 'Position_Size'] = 1 / df.loc[i, 'ATR']

#     return df


# def calculate_pivot_support_resistance(df):
#     """
#     Calculate support and resistance levels based on daily pivot points.
#     """
#     # Pivot Point (PP), Support (S1, S2) and Resistance (R1, R2)
#     df['PP'] = (df['High'] + df['Low'] + df['Close']) / 3
#     df['R1'] = (2 * df['PP']) - df['Low']
#     df['S1'] = (2 * df['PP']) - df['High']
#     df['R2'] = df['PP'] + (df['High'] - df['Low'])
#     df['S2'] = df['PP'] - (df['High'] - df['Low'])
#     return df


# def calculate_atr_support_resistance(df, period=14):
#     """
#     Calculate dynamic support and resistance using ATR.
#     """
#     # Calculate ATR (Average True Range)
#     df['HL'] = df['High'] - df['Low']
#     df['HC'] = abs(df['High'] - df['Close'].shift(1))
#     df['LC'] = abs(df['Low'] - df['Close'].shift(1))
#     df['TR'] = df[['HL', 'HC', 'LC']].max(axis=1)
#     df['ATR'] = df['TR'].rolling(window=period).mean()

#     # Calculate dynamic support and resistance
#     df['Resistance'] = df['Close'] + (2 * df['ATR'])
#     df['Support'] = df['Close'] - (2 * df['ATR'])
#     df.drop(['HL', 'HC', 'LC', 'TR'], axis=1, inplace=True)
#     return df



# def calculate_peak_trough_support_resistance(df, order=5):
#     """
#     Calculate support and resistance levels using local peaks and troughs.
#     """
#     # Find local maxima (resistance) and minima (support)
#     df['Resistance'] = df['High'][argrelextrema(df['High'].values, np.greater_equal, order=order)[0]]
#     df['Support'] = df['Low'][argrelextrema(df['Low'].values, np.less_equal, order=order)[0]]

#     # Forward-fill NaNs to propagate levels until a new peak or trough appears
#     df['Resistance'].fillna(method='ffill', inplace=True)
#     df['Support'].fillna(method='ffill', inplace=True)
#     return df

 
 

# Method 1: Pivot Points
def calculate_pivot_support_resistance(df):
    df['PP'] = (df['High'] + df['Low'] + df['Close']) / 3
    df['R1'] = (2 * df['PP']) - df['Low']
    df['S1'] = (2 * df['PP']) - df['High']
    df['R2'] = df['PP'] + (df['High'] - df['Low'])
    df['S2'] = df['PP'] - (df['High'] - df['Low'])
    return df[['High', 'Low', 'Close', 'PP', 'R1', 'S1', 'R2', 'S2']]

# Method 2: ATR-Based Dynamic Support and Resistance
def calculate_atr_support_resistance(df, period=14):
    df['HL'] = df['High'] - df['Low']
    df['HC'] = abs(df['High'] - df['Close'].shift(1))
    df['LC'] = abs(df['Low'] - df['Close'].shift(1))
    df['TR'] = df[['HL', 'HC', 'LC']].max(axis=1)
    df['ATR'] = df['TR'].rolling(window=period).mean()
    df['Resistance'] = df['Close'] + (2 * df['ATR'])
    df['Support'] = df['Close'] - (2 * df['ATR'])
    df.drop(['HL', 'HC', 'LC', 'TR'], axis=1, inplace=True)
    return df[['High', 'Low', 'Close', 'ATR', 'Resistance', 'Support']]

# Method 3: Local Maxima and Minima
def calculate_peak_trough_support_resistance(df, order=5):
    df['Resistance'] = df['High'][argrelextrema(df['High'].values, np.greater_equal, order=order)[0]]
    df['Support'] = df['Low'][argrelextrema(df['Low'].values, np.less_equal, order=order)[0]]
    # For example:
    df['Resistance'] = df['Resistance'].ffill()  # Forward fills NaN values in 'Resistance'
    df['Support'] = df['Support'].ffill() 
    return df[['High', 'Low', 'Close', 'Resistance', 'Support']]



# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, haGreen, haRed, close, 
#     upperBB, lowerBB, st21UP, st21DN, support, resistance
# ):
#     # Initialize all signals
#     buy_signal = st21Buy
#     sell_signal = st21Sell
    
#     best_buy_signal = ema5 > ema21 and st21Trend == 1
#     best_sell_signal = ema5 < ema21 and st21Trend == -1
    
#     strong_buy_signal = ema5 > st21UP and close > upperBB
#     strong_sell_signal = ema5 < st21DN and close < lowerBB

#     # Initialize all exit signals to False
#     exit_buy_signal = False
#     exit_sell_signal = False
#     exit_best_buy_signal = False
#     exit_best_sell_signal = False
#     exit_strong_buy_signal = False
#     exit_strong_sell_signal = False

#     # Exit Regular Buy Signal
#     if buy_signal:
#         exit_buy_signal = st21Trend == -1 or (close < resistance and haRed)

#     # Exit Regular Sell Signal
#     if sell_signal:
#         exit_sell_signal = st21Trend == 1 or (close > support and haGreen)

#     # Exit Best Buy Signal
#     if best_buy_signal:
#         exit_best_buy_signal = ema5 < ema21 or st21Trend == -1

#     # Exit Best Sell Signal
#     if best_sell_signal:
#         exit_best_sell_signal = ema5 > ema21 or st21Trend == 1

#     # Exit Strong Buy Signal
#     if strong_buy_signal:
#         exit_strong_buy_signal = ema21 > close or st21Trend == -1

#     # Exit Strong Sell Signal
#     if strong_sell_signal:
#         exit_strong_sell_signal = ema21 < close or st21Trend == 1

#     # Return all signals
#     return {
#         'buy_signal': buy_signal,
#         'sell_signal': sell_signal,
#         'best_buy_signal': best_buy_signal,
#         'best_sell_signal': best_sell_signal,
#         'strong_buy_signal': strong_buy_signal,
#         'strong_sell_signal': strong_sell_signal,
#         'exit_buy_signal': exit_buy_signal,
#         'exit_sell_signal': exit_sell_signal,
#         'exit_best_buy_signal': exit_best_buy_signal,
#         'exit_best_sell_signal': exit_best_sell_signal,
#         'exit_strong_buy_signal': exit_strong_buy_signal,
#         'exit_strong_sell_signal': exit_strong_sell_signal
#     }

def signal(
    ema5, ema21, st21Buy, st21Sell, st21Trend, hatrend, close, 
    upperBB, lowerBB, st21UP, st21DN, support, resistance
):
    # Helper function to determine exit conditions
    def exit_signal(condition, trend_condition, support_condition, hatrend_condition):
        return condition and (trend_condition or (close < resistance and hatrend_condition == 'red'))

    # Define signal conditions
    buy_signal = st21Buy
    sell_signal = st21Sell
    
    best_buy_signal = ema5 > ema21 and st21Trend == 1
    best_sell_signal = ema5 < ema21 and st21Trend == -1
    
    strong_buy_signal = ema5 > st21UP and close > upperBB
    strong_sell_signal = ema5 < st21DN and close < lowerBB

    # Define exit signals using the helper function
    exit_buy_signal = exit_signal(buy_signal, st21Trend == -1, close < resistance, hatrend)
    exit_sell_signal = exit_signal(sell_signal, st21Trend == 1, close > support, hatrend)
    
    # Exit conditions for best signals
    exit_best_buy_signal = best_buy_signal and (ema5 < ema21 or st21Trend == -1)
    exit_best_sell_signal = best_sell_signal and (ema5 > ema21 or st21Trend == 1)
    
    # Exit conditions for strong signals
    exit_strong_buy_signal = strong_buy_signal and (ema21 > close or st21Trend == -1)
    exit_strong_sell_signal = strong_sell_signal and (ema21 < close or st21Trend == 1)

    # Return all signals
    return {
        'buy_signal': buy_signal,
        'sell_signal': sell_signal,
        'best_buy_signal': best_buy_signal,
        'best_sell_signal': best_sell_signal,
        'strong_buy_signal': strong_buy_signal,
        'strong_sell_signal': strong_sell_signal,
        'exit_buy_signal': exit_buy_signal,
        'exit_sell_signal': exit_sell_signal,
        'exit_best_buy_signal': exit_best_buy_signal,
        'exit_best_sell_signal': exit_best_sell_signal,
        'exit_strong_buy_signal': exit_strong_buy_signal,
        'exit_strong_sell_signal': exit_strong_sell_signal
    }
