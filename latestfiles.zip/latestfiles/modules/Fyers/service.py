import pandas as pd
from fyers_apiv3 import fyersModel
import datetime as dt
import pytz
import numpy as np
import time
import json
import os
from scipy.signal import argrelextrema
from modules.Fyers.signal.service import signal

# Read credentials
client_id = open("client_id.txt", 'r').read().strip()
access_token = open("access_token.txt", 'r').read().strip()

# Initialize Fyers client
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")

# ------------------------- Utility Functions -------------------------

def save_to_json(data, filename):
    def default_serializer(o):
        if isinstance(o, np.bool_):
            return bool(o)
        elif isinstance(o, bool):
            return o
        raise TypeError(f"Type {type(o)} not serializable")
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4, default=default_serializer)

def load_from_json(filename='indicator_values.json'):
    if os.path.exists(filename):
        with open(filename, 'r') as f:
            return json.load(f)
    return {}

# ------------------------- OHLC Fetch -------------------------

def fetchOHLC2(ticker, interval, duration):
    range_from = dt.date.today() - dt.timedelta(duration)
    range_to = dt.date.today()

    from_date_string = range_from.strftime("%Y-%m-%d")
    to_date_string = range_to.strftime("%Y-%m-%d")
    data = {
        "symbol": ticker,
        "resolution": interval,
        "date_format": "1",
        "range_from": from_date_string,
        "range_to": to_date_string,
        "cont_flag": "1"
    }

    response = fyers.history(data=data)
    
    # Debug print full response
    if 'candles' not in response:
        print("❌ Error fetching OHLC:")
        print(json.dumps(response, indent=2))
        return pd.DataFrame()  # return empty dataframe to avoid errors

    # Create DataFrame
    columns = ['Timestamp', 'Open', 'High', 'Low', 'Close', 'Volume']
    df = pd.DataFrame(response['candles'], columns=columns)
    
    # Convert Timestamp to IST
    df['Timestamp2'] = pd.to_datetime(df['Timestamp'], unit='s').dt.tz_localize(pytz.utc)
    ist = pytz.timezone('Asia/Kolkata')
    df['Timestamp2'] = df['Timestamp2'].dt.tz_convert(ist)
    df.drop(columns=['Timestamp'], inplace=True)

    return df

# ------------------------- Indicators -------------------------

def bollinger_bands(df, window=20, width=2):
    rolling_mean = df['Close'].rolling(window=window).mean()
    rolling_std = df['Close'].rolling(window=window).std()
    df['BB_upper'] = rolling_mean + (rolling_std * width)
    df['BB_lower'] = rolling_mean - (rolling_std * width)
    df['BB_mid'] = rolling_mean
    return df

def ema(df, window=21):
    df[f"EMA{window}"] = df['Close'].ewm(span=window, adjust=False).mean()
    return df

def atr(DF, n):
    df = DF.copy()
    df['High-Low'] = abs(df['High'] - df['Low'])
    df['High-PrevClose'] = abs(df['High'] - df['Close'].shift(1))
    df['Low-PrevClose'] = abs(df['Low'] - df['Close'].shift(1))
    df['TR'] = df[['High-Low', 'High-PrevClose', 'Low-PrevClose']].max(axis=1, skipna=False)
    df['ATR'] = df['TR'].ewm(com=n, min_periods=n).mean()
    return df['ATR']

def supertrend(DF, period=21, multiplier=1):
    df = DF.copy()
    df['ATR'] = atr(df, period)
    df["BasicUpper"] = ((df['High'] + df['Low']) / 2) + multiplier * df['ATR']
    df["BasicLower"] = ((df['High'] + df['Low']) / 2) - multiplier * df['ATR']
    df["FinalUpper"] = df["BasicUpper"]
    df["FinalLower"] = df["BasicLower"]

    ind = df.index
    for i in range(period, len(df)):
        if df['Close'][i - 1] <= df['FinalUpper'][i - 1]:
            df.loc[ind[i], 'FinalUpper'] = min(df['BasicUpper'][i], df['FinalUpper'][i - 1])
        else:
            df.loc[ind[i], 'FinalUpper'] = df['BasicUpper'][i]

    for i in range(period, len(df)):
        if df['Close'][i - 1] >= df['FinalLower'][i - 1]:
            df.loc[ind[i], 'FinalLower'] = max(df['BasicLower'][i], df['FinalLower'][i - 1])
        else:
            df.loc[ind[i], 'FinalLower'] = df['BasicLower'][i]

    df['Strend'] = np.nan
    for test in range(period, len(df)):
        if df['Close'][test - 1] <= df['FinalUpper'][test - 1] and df['Close'][test] > df['FinalUpper'][test]:
            df.loc[ind[test], 'Strend'] = df['FinalLower'][test]
            break
        if df['Close'][test - 1] >= df['FinalLower'][test - 1] and df['Close'][test] < df['FinalLower'][test]:
            df.loc[ind[test], 'Strend'] = df['FinalUpper'][test]
            break

    for i in range(test + 1, len(df)):
        if df['Strend'][i - 1] == df['FinalUpper'][i - 1] and df['Close'][i] <= df['FinalUpper'][i]:
            df.loc[ind[i], 'Strend'] = df['FinalUpper'][i]
        elif df['Strend'][i - 1] == df['FinalUpper'][i - 1] and df['Close'][i] >= df['FinalUpper'][i]:
            df.loc[ind[i], 'Strend'] = df['FinalLower'][i]
        elif df['Strend'][i - 1] == df['FinalLower'][i - 1] and df['Close'][i] >= df['FinalLower'][i]:
            df.loc[ind[i], 'Strend'] = df['FinalLower'][i]
        elif df['Strend'][i - 1] == df['FinalLower'][i - 1] and df['Close'][i] <= df['FinalLower'][i]:
            df.loc[ind[i], 'Strend'] = df['FinalUpper'][i]

    supertrend_data = df['Strend'].fillna(0)
    supertrend_up_data = df['FinalUpper'].fillna(0)
    supertrend_down_data = df['FinalLower'].fillna(0)

    return supertrend_data, supertrend_up_data, supertrend_down_data



def calculate_support_resistance(df, period=20):
    """
    Calculate support and resistance levels based on the lowest low and highest high over a specified period.
    """
    df['Support'] = df['Low'].rolling(window=period).min()
    df['Resistance'] = df['High'].rolling(window=period).max()
    return df





# Function to process tickers and save pivot points and true signals in CSV
def process_and_save_pivots(symbol):
    result_data = []

    for ticker in symbol:
        # Fetch OHLC data
        stock_df = fetchOHLC2(ticker, "15", 1)
        if stock_df.empty:
            continue  # Skip if no data is returned

        # Ensure 'Timestamp2' is set as the index
        stock_df['Timestamp2'] = pd.to_datetime(stock_df['Timestamp2'])
        stock_df.set_index('Timestamp2', inplace=True)

        # Resample to daily OHLC
        daily_df = stock_df.resample('D').agg({
            'Open': 'first',
            'High': 'max',
            'Low': 'min',
            'Close': 'last',
            'Volume': 'sum'
        })
        daily_df.dropna(inplace=True)

        # Calculate pivot points
        pivot, r1, r2, r3, s1, s2, s3 = pivotpoints_today(daily_df)

        # Get dynamic signals from market data
        st21Buy, st21Sell, haGreen, haRed = get_dynamic_signals(daily_df)

        # Use the signal function from the imported module
        signals = signal(
            ema5=daily_df["Close"].ewm(span=5).mean().iloc[-1],
            ema21=daily_df["Close"].ewm(span=21).mean().iloc[-1],
            st21Buy=st21Buy,  # Use dynamic conditions
            st21Sell=st21Sell,  # Use dynamic conditions
            st21Trend=1 if st21Buy else -1,  # Example: 1 for Buy, -1 for Sell
            haGreen=haGreen,  # Use dynamic conditions
            haRed=haRed,  # Use dynamic conditions
            close=daily_df['Close'].iloc[-1],
            upperBB=1883.67,  # Replace with actual upper BB
            lowerBB=1875.31,  # Replace with actual lower BB
            st21UP=1880.0,  # Replace with actual st21UP value
            st21DN=1870.0,  # Replace with actual st21DN value
            support=s1,
            resistance=r1
        )

        # Filter out signals that are true
        true_signals = {k: v for k, v in signals.items() if v}

        # Prepare data for CSV
        result_data.append({
            'Ticker': ticker,
            'Pivot': pivot,
            'R1': r1,
            'R2': r2,
            'R3': r3,
            'S1': s1,
            'S2': s2,
            'S3': s3,
            'True_Signals': true_signals
        })

        # Display data
        print(f"Ticker: {ticker}, Pivot: {pivot}, R1: {r1}, R2: {r2}, R3: {r3}, S1: {s1}, S2: {s2},S3: {s3},  Signals: {true_signals}")

    # Save to CSV
    df_result = pd.DataFrame(result_data)
    df_result.to_csv('top_symbols_pivot.csv', index=False)



# # Add this class above your existing functions
# class GuppyIndicator:
#     def __init__(self, df, params):
#         self.df = df.copy()
#         self.params = params
#         self.original_index = df.index
#         self._validate_parameters()
        
#     def _validate_parameters(self):
#         required_params = ['use_current_res', 'res_custom', 'len', 'factorT3', 'atype',
#                           'smoothe', 'doma2', 'len2', 'sfactorT3', 'atype2']
#         for param in required_params:
#             if param not in self.params:
#                 raise ValueError(f"Missing required parameter: {param}")

#     def _calculate_ma(self, series, ma_type, length, volume=None, factor=0.7):
#         if ma_type == 1:  # SMA
#             return series.rolling(window=length).mean()
#         elif ma_type == 2:  # EMA
#             return series.ewm(span=length, adjust=False).mean()
#         elif ma_type == 3:  # WMA:
#             weights = np.arange(1, length + 1)
#             return series.rolling(window=length).apply(
#                 lambda x: np.dot(x, weights) / weights.sum(), raw=True)
#         elif ma_type == 4:  # Hull MA
#             wma_half = self._calculate_ma(series, 3, length//2)
#             wma_full = self._calculate_ma(series, 3, length)
#             hull_series = 2 * wma_half - wma_full
#             return self._calculate_ma(hull_series, 3, int(np.sqrt(length)))
#         elif ma_type == 5:  # VWMA
#             return (series * volume).rolling(length).sum() / volume.rolling(length).sum()
#         elif ma_type == 6:  # RMA
#             return series.ewm(alpha=1/length, adjust=False).mean()
#         elif ma_type == 7:  # TEMA
#             ema1 = series.ewm(span=length, adjust=False).mean()
#             ema2 = ema1.ewm(span=length, adjust=False).mean()
#             ema3 = ema2.ewm(span=length, adjust=False).mean()
#             return 3 * (ema1 - ema2) + ema3
#         elif ma_type == 8:  # Tilson T3
#             def gd(src, length, factor):
#                 e1 = src.ewm(span=length, adjust=False).mean()
#                 e2 = e1.ewm(span=length, adjust=False).mean()
#                 return e1 * (1 + factor) - e2 * factor
#             t3 = gd(series, length, factor)
#             t3 = gd(t3, length, factor)
#             t3 = gd(t3, length, factor)
#             return t3
#         else:
#             raise ValueError("Invalid MA type")

#     def calculate(self):
#         resampled_df = self.df.resample(self.params['res_custom']).agg({
#             'Open': 'first', 'High': 'max', 'Low': 'min', 
#             'Close': 'last', 'Volume': 'sum'}).dropna() if not self.params['use_current_res'] else self.df
        
#         # Calculate MAs
#         resampled_df['ma1'] = self._calculate_ma(
#             resampled_df['Close'], self.params['atype'], self.params['len'],
#             resampled_df['Volume'] if self.params['atype'] == 5 else None,
#             self.params['factorT3'])
        
#         if self.params['doma2']:
#             resampled_df['ma2'] = self._calculate_ma(
#                 resampled_df['Close'], self.params['atype2'], self.params['len2'],
#                 resampled_df['Volume'] if self.params['atype2'] == 5 else None,
#                 self.params['sfactorT3'])
        
#         if not self.params['use_current_res']:
#             self.df = self.df.join(resampled_df[['ma1'] + (['ma2'] if self.params['doma2'] else [])])
#             self.df[['ma1', 'ma2']] = self.df[['ma1', 'ma2']].ffill()
#         else:
#             self.df = resampled_df
            
#         return self.df

# # Add this function above your existing indicators
# def super_guppy(df, params=None):
#     """Calculate Super Guppy indicator status and cross signals"""
#     if params is None:
#         params = {
#             'use_current_res': True,
#             'res_custom': 'D',
#             'len': 20,
#             'factorT3': 0.7,
#             'atype': 1,
#             'smoothe': 2,
#             'doma2': True,
#             'len2': 50,
#             'sfactorT3': 0.7,
#             'atype2': 1,
#         }
    
#     guppy = GuppyIndicator(df, params)
#     df = guppy.calculate()
    
#     # Calculate statuses
#     df['ma_up'] = df['ma1'] >= df['ma1'].shift(params['smoothe'])
#     df['ma_down'] = df['ma1'] < df['ma1'].shift(params['smoothe'])
    
#     # Cross signals
#     df['cross_up'] = (df['ma1'] > df['ma2']) & (df['ma1'].shift(1) <= df['ma2'].shift(1))
#     df['cross_down'] = (df['ma1'] < df['ma2']) & (df['ma1'].shift(1) >= df['ma2'].shift(1))
    
#     # Get latest values
#     last_row = df.iloc[-1]
#     return {
#         'green': bool(last_row['ma_up']),
#         'red': bool(last_row['ma_down']),
#         'cross_up': bool(last_row['cross_up']),
#         'cross_down': bool(last_row['cross_down'])
#     }

# # Modified main function (example usage)
# def main():
#     # Fetch data
#     ticker = "NSE:SBIN-EQ"
#     df = fetchOHLC2(ticker, "15", 5)
    
#     # Calculate indicators
#     df = bollinger_bands(df)
#     df = ema(df)
#     df['ATR'] = atr(df, 14)
    
#     # Get Super Guppy status
#     guppy_status = super_guppy(df)
    
#     # Prepare final output
#     return {
#         'bollinger': df[['BB_upper', 'BB_lower']].iloc[-1].to_dict(),
#         'ema': df['EMA21'].iloc[-1],
#         'atr': df['ATR'].iloc[-1],
#         'super_guppy': guppy_status
#     }

# Rest of your existing functions remain unchanged below...

# def apply_trading_logic(df, atr_multiple=1.5):
#     """
#     Apply trading logic using ATR with support and resistance levels.
#     """
#     df['Signal'] = None
#     df['Stop_Loss'] = None
#     df['Position_Size'] = None

#     for i in range(1, len(df)):
#         if df['Close'].iloc[i] > df['Resistance'].iloc[i-1] and df['ATR'].iloc[i] > df['ATR'].mean():
#             df.loc[i, 'Signal'] = 'Buy'
#             df.loc[i, 'Stop_Loss'] = df.loc[i-1, 'Resistance'] - atr_multiple * df.loc[i, 'ATR']
#             df.loc[i, 'Position_Size'] = 1 / df.loc[i, 'ATR']
#         elif df['Close'].iloc[i] < df['Support'].iloc[i-1] and df['ATR'].iloc[i] < df['ATR'].mean():
#             df.loc[i, 'Signal'] = 'Sell'
#             df.loc[i, 'Stop_Loss'] = df.loc[i-1, 'Support'] + atr_multiple * df.loc[i, 'ATR']
#             df.loc[i, 'Position_Size'] = 1 / df.loc[i, 'ATR']

#     return df


# def calculate_pivot_support_resistance(df):
#     """
#     Calculate support and resistance levels based on daily pivot points.
#     """
#     # Pivot Point (PP), Support (S1, S2) and Resistance (R1, R2)
#     df['PP'] = (df['High'] + df['Low'] + df['Close']) / 3
#     df['R1'] = (2 * df['PP']) - df['Low']
#     df['S1'] = (2 * df['PP']) - df['High']
#     df['R2'] = df['PP'] + (df['High'] - df['Low'])
#     df['S2'] = df['PP'] - (df['High'] - df['Low'])
#     return df


# def calculate_atr_support_resistance(df, period=14):
#     """
#     Calculate dynamic support and resistance using ATR.
#     """
#     # Calculate ATR (Average True Range)
#     df['HL'] = df['High'] - df['Low']
#     df['HC'] = abs(df['High'] - df['Close'].shift(1))
#     df['LC'] = abs(df['Low'] - df['Close'].shift(1))
#     df['TR'] = df[['HL', 'HC', 'LC']].max(axis=1)
#     df['ATR'] = df['TR'].rolling(window=period).mean()

#     # Calculate dynamic support and resistance
#     df['Resistance'] = df['Close'] + (2 * df['ATR'])
#     df['Support'] = df['Close'] - (2 * df['ATR'])
#     df.drop(['HL', 'HC', 'LC', 'TR'], axis=1, inplace=True)
#     return df



# def calculate_peak_trough_support_resistance(df, order=5):
#     """
#     Calculate support and resistance levels using local peaks and troughs.
#     """
#     # Find local maxima (resistance) and minima (support)
#     df['Resistance'] = df['High'][argrelextrema(df['High'].values, np.greater_equal, order=order)[0]]
#     df['Support'] = df['Low'][argrelextrema(df['Low'].values, np.less_equal, order=order)[0]]

#     # Forward-fill NaNs to propagate levels until a new peak or trough appears
#     df['Resistance'].fillna(method='ffill', inplace=True)
#     df['Support'].fillna(method='ffill', inplace=True)
#     return df

 

# Method 1: Pivot Points
def calculate_pivot_support_resistance(df):
    df['PP'] = (df['High'] + df['Low'] + df['Close']) / 3
    df['R1'] = (2 * df['PP']) - df['Low']
    df['S1'] = (2 * df['PP']) - df['High']
    df['R2'] = df['PP'] + (df['High'] - df['Low'])
    df['S2'] = df['PP'] - (df['High'] - df['Low'])
    return df[['High', 'Low', 'Close', 'PP', 'R1', 'S1', 'R2', 'S2']]

# Method 2: ATR-Based Dynamic Support and Resistance
def calculate_atr_support_resistance(df, period=14):
    df['HL'] = df['High'] - df['Low']
    df['HC'] = abs(df['High'] - df['Close'].shift(1))
    df['LC'] = abs(df['Low'] - df['Close'].shift(1))
    df['TR'] = df[['HL', 'HC', 'LC']].max(axis=1)
    df['ATR'] = df['TR'].rolling(window=period).mean()
    df['Resistance'] = df['Close'] + (2 * df['ATR'])
    df['Support'] = df['Close'] - (2 * df['ATR'])
    df.drop(['HL', 'HC', 'LC', 'TR'], axis=1, inplace=True)
    return df[['High', 'Low', 'Close', 'ATR', 'Resistance', 'Support']]

# Method 3: Local Maxima and Minima
def calculate_peak_trough_support_resistance(df, order=5):
    df['Resistance'] = df['High'][argrelextrema(df['High'].values, np.greater_equal, order=order)[0]]
    df['Support'] = df['Low'][argrelextrema(df['Low'].values, np.less_equal, order=order)[0]]
    # For example:
    df['Resistance'] = df['Resistance'].ffill()  # Forward fills NaN values in 'Resistance'
    df['Support'] = df['Support'].ffill() 
    return df[['High', 'Low', 'Close', 'Resistance', 'Support']]


# Function to calculate pivot points and supports/resistances
def pivotpoints_today(ohlc_day):
    """Returns pivot point and support/resistance levels."""
    high = round(ohlc_day["High"].iloc[-1], 2)
    low = round(ohlc_day["Low"].iloc[-1], 2)
    close = round(ohlc_day["Close"].iloc[-1], 2)
    
    pivot = round((high + low + close) / 3, 2)
    r1 = round((2 * pivot - low), 2)
    r2 = round((pivot + (high - low)), 2)
    r3 = round((high + 2 * (pivot - low)), 2)
    s1 = round((2 * pivot - high), 2)
    s2 = round((pivot - (high - low)), 2)
    s3 = round((low - 2 * (high - pivot)), 2)

    return pivot, r1, r2, r3, s1, s2, s3

# Function to dynamically set buy/sell/hold signals
def get_dynamic_signals(df):
    ema5 = df["Close"].ewm(span=5).mean().iloc[-1]
    ema21 = df["Close"].ewm(span=21).mean().iloc[-1]
    close = df['Close'].iloc[-1]

    # Define actual conditions based on indicators
    st21Buy = close > ema21  # Buy condition if the close is above EMA 21
    st21Sell = close < ema21  # Sell condition if the close is below EMA 21
    haGreen = st21Buy  # Replace with actual Heikin-Ashi Green logic
    haRed = st21Sell   # Replace with actual Heikin-Ashi Red logic

    return st21Buy, st21Sell, haGreen, haRed

# Function to process tickers and save pivot points and true signals in CSV
def process_and_save_pivots(symbol):
    result_data = []

    for ticker in symbol:
        # Fetch OHLC data
        stock_df = fetchOHLC2(ticker, "15", 1)
        if stock_df.empty:
            continue  # Skip if no data is returned

        # Ensure 'Timestamp2' is set as the index
        stock_df['Timestamp2'] = pd.to_datetime(stock_df['Timestamp2'])
        stock_df.set_index('Timestamp2', inplace=True)

        # Resample to daily OHLC
        daily_df = stock_df.resample('D').agg({
            'Open': 'first', 
            'High': 'max', 
            'Low': 'min', 
            'Close': 'last', 
            'Volume': 'sum'
        })
        daily_df.dropna(inplace=True)

        # Calculate pivot points
        pivot, r1, r2, r3, s1, s2, s3 = pivotpoints_today(daily_df)

        # Get dynamic signals from market data
        st21Buy, st21Sell, haGreen, haRed = get_dynamic_signals(daily_df)

        # Use the signal function from the imported module
        signals = signal(
            ema5=daily_df["Close"].ewm(span=5).mean().iloc[-1],
            ema21=daily_df["Close"].ewm(span=21).mean().iloc[-1],
            st21Buy=st21Buy,  # Use dynamic conditions
            st21Sell=st21Sell,  # Use dynamic conditions
            st21Trend=1 if st21Buy else -1,  # Example: 1 for Buy, -1 for Sell
            haGreen=haGreen,  # Use dynamic conditions
            haRed=haRed,  # Use dynamic conditions
            close=daily_df['Close'].iloc[-1],
            upperBB=1883.67,  # Replace with actual upper BB
            lowerBB=1875.31,  # Replace with actual lower BB
            st21UP=1880.0,  # Replace with actual st21UP value
            st21DN=1870.0,  # Replace with actual st21DN value
            support=s1,
            resistance=r1
        )

        # Filter out signals that are true
        true_signals = {k: v for k, v in signals.items() if v}

        # Prepare data for CSV
        result_data.append({
            'Ticker': ticker,
            'Pivot': pivot,
            'R1': r1,
            'R2': r2,
            'R3': r3,
            'S1': s1,
            'S2': s2,
            'S3': s3,
            'True_Signals': true_signals
        })

        # Display data
        print(f"Ticker: {ticker}, Pivot: {pivot}, R1: {r1}, R2: {r2}, R3: {r3}, S1: {s1}, S2: {s2},S3: {s3},  Signals: {true_signals}")

    # Save to CSV
    df_result = pd.DataFrame(result_data)
    df_result.to_csv('top_symbols_pivot.csv', index=False)
