
import pandas as pd
from fyers_apiv3 import fyersModel
import datetime as dt
import pytz
import numpy as np
import time

import json
import os

#generate trading session
client_id = open("client_id.txt",'r').read()
access_token = open("access_token.txt",'r').read()
# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")


# # Place order function
# def placeOrder(inst, t_type, qty, order_type):
#     exch = inst[:3]
#     symb = inst[4:]
#     if order_type == "MARKET":
#         type1 = 2
#         price = 0
#         price_stop = 0
#     elif order_type == "LIMIT":
#         type1 = 1
#         price_stop = 0
#     elif order_type == "SL-LIMIT":
#         type1 = 4

#     if t_type == "BUY":
#         side1 = 1
#     elif t_type == "SELL":
#         side1 = -1

#     # Data structure for AMO (After Market Order)
#     data = {
#         "symbol": inst,
#         "qty": qty,
#         "type": type1,
#         "side": side1,
#         "productType": "INTRADAY",
#         "limitPrice": price,       # Price for LIMIT orders, 0 for MARKET orders
#         "stopPrice": price_stop,   # Stop price for SL-LIMIT orders
#         "validity": "DAY",         # Order validity (valid for the trading day)
#       #  "offlineorder": "true",    # Set to true for AMO scheduling
#       #  "amo": "true"              # Explicitly mark as an AMO order (if required)
#     }

#     try:
#         orderid = fyers.place_order(data)
#         print(f"{symb} Order ID: {orderid}")
#         return orderid
#     except Exception as e:
#         print(f"{symb} Failed to place order: {e}")
#         return None


# def cancelOrder(order_id):
#     #convert id into dictionary
#     order_id_dict = {"id": str(order_id)}
#     response = fyers.cancel_order(order_id_dict)
#     print(response)


# def modifyOrder(orderId,order_type,qty,price=0, price_stop=0):
#     if(order_type=="MARKET"):
#         type1 = 2
#         price = 0
#         price_stop = 0
#     elif(order_type=="LIMIT"):
#         type1 = 1
#         price_stop = 0
#     elif(order_type=="SL-LIMIT"):
#         type1 = 4

#     data = {
#         "id":str(orderId),
#         "type":type1,
#         "limitPrice": price,
#         "qty":qty
#     }
#     print(data)
#     response = fyers.modify_order(data=data)
#     print(response)

import datetime

# def placeOrder(inst ,t_type,qty,order_type, price=0, price_stop=0):
#     exch = inst[:3]
#     symb = inst[4:]
#     dt = datetime.datetime.now()
#     print(dt.hour,":",dt.minute,":",dt.second ," => ",t_type," ",symb," ",qty," ",order_type," @ price =  ",price)
#     if(order_type=="MARKET"):
#         type1 = 2
#         price = 0
#         price_stop = 0
#     elif(order_type=="LIMIT"):
#         type1 = 1
#         price_stop = 0
#     elif(order_type=="SL-LIMIT"):
#         type1 = 4

#     if(t_type=="BUY"):
#         side1=1
#     elif(t_type=="SELL"):
#         side1=-1

#     data =  {
#         "symbol":inst,
#         "qty":qty,
#         "type":type1,
#         "side":side1,
#         "productType":"INTRADAY",
#         "limitPrice":price,
#         "stopPrice":price_stop,
#         "validity":"DAY",
#     }

#     try:
#         orderid = fyers.place_order(data)
#         print(dt.hour,":",dt.minute,":",dt.second ," => ", symb , orderid)
#         return orderid
#     except Exception as e:
#         print(dt.hour,":",dt.minute,":",dt.second ," => ", symb , "Failed : {} ".format(e))



def placeOrder(inst, t_type, qty, order_type, price=0, price_stop=0):
    """
    Places an order with the Fyers API.
    """
    exch = inst[:3]  # Extract exchange
    symb = inst[4:]  # Extract symbol
    dt = datetime.datetime.now()

    print(dt.hour, ":", dt.minute, ":", dt.second, " => ", t_type, " ", symb, " ", qty, " ", order_type, " @ price = ", price)

    # Determine order type
    if order_type == "MARKET":
        type1 = 2
        price = 0  # Ensure price is 0 for MARKET orders
        price_stop = 0
    elif order_type == "LIMIT":
        type1 = 1
        if price <= 0:  # Validate price for LIMIT orders
            print(f"Error: limitPrice must be greater than or equal to 0.0025 for LIMIT orders. Provided: {price}")
            return {"code": -50, "message": "Invalid limitPrice for LIMIT order", "s": "error"}
        price_stop = 0
    elif order_type == "SL-LIMIT":
        type1 = 4

    # Determine side
    if t_type == "BUY":
        side1 = 1
    elif t_type == "SELL":
        side1 = -1

    # Construct the data payload
    data = {
        "symbol": inst,
        "qty": qty,
        "type": type1,
        "side": side1,
        "productType": "INTRADAY",
        "limitPrice": price,
        "stopPrice": price_stop,
        "validity": "DAY",
    }

    # Log the payload for debugging
    print(f"Order Payload: {data}")

    try:
        # Place the order using Fyers API
        orderid = fyers.place_order(data)
        print(dt.hour, ":", dt.minute, ":", dt.second, " => ", symb, orderid)
        return orderid
    except Exception as e:
        print(dt.hour, ":", dt.minute, ":", dt.second, " => ", symb, f"Failed: {e}")
        return {"code": -50, "message": f"Order failed: {e}", "s": "error"}



def cancelOrder(order_id):
    #convert id into dictionary
    order_id_dict = {"id": str(order_id)}
    response = fyers.cancel_order(order_id_dict)
    print(response)


def modifyOrder(orderId,order_type,qty,price=0, price_stop=0):
    if(order_type=="MARKET"):
        type1 = 2
        price = 0
        price_stop = 0
    elif(order_type=="LIMIT"):
        type1 = 1
        price_stop = 0
    elif(order_type=="SL-LIMIT"):
        type1 = 4

    data = {
        "id":str(orderId),
        "type":type1,
        "limitPrice": price,
        "qty":qty
    }
    print(data)
    response = fyers.modify_order(data=data)
    print(response)

