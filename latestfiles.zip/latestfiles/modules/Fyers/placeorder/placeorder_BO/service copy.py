
import pandas as pd
from fyers_apiv3 import fyersModel
import datetime as dt
import pytz
import numpy as np
import time
from modules.Fyers.service import save_to_json, load_from_json, fetchOHLC2

import json
import os





#generate trading session
client_id = open("client_id.txt",'r').read()
access_token = open("access_token.txt",'r').read()
# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")



# Place order function for Bracket Orders (BO)
def placeOrder(inst, t_type, qty, order_type, target_percentage=0.2, stoploss_percentage=0.05):
    exch = inst[:3]  # Extract exchange (e.g., NSE)
    symb = inst[4:]  # Extract symbol (e.g., INFY-EQ)

    # Define side based on transaction type (BUY or SELL)
    if t_type == "BUY":
        side1 = 1
    elif t_type == "SELL":
        side1 = -1

    # Get the latest market price for the instrument to calculate target and stop-loss
    ohlc_data = fetchOHLC2(inst, '1', 1)  # Fetch latest OHLC data (1-minute interval)
    if ohlc_data is not None and 'Close' in ohlc_data.columns:
        close_price = ohlc_data['Close'].iloc[-1]  # Get the latest close price
    else:
        print(f"Failed to fetch latest price for {inst}")
        return None

    # Calculate the target and stop-loss prices based on the given percentages
    target_price = close_price * (1 + target_percentage)  # Example: 20% target for BUY
    stoploss_price = close_price * (1 - stoploss_percentage)  # Example: 5% stop-loss for BUY

    # Data structure for the Bracket Order
    data = {
        "symbol": inst,
        "qty": qty,
        "type": 2,  # Type 2 for MARKET orders in a bracket order
        "side": side1,
        "productType": "BO",  # Bracket Order
        "limitPrice": 0,  # For MARKET orders, limit price is 0
        "stopPrice": stoploss_price,  # Set the stop-loss price
        "validity": "DAY",  # Valid for the trading day
        "takeProfit": target_price,  # Target price for profit booking
        "stopLoss": stoploss_price,  # Stop-loss price
    }

    try:
        orderid = fyers.place_order(data)  # Place the order via Fyers API
        print(f"{symb} Bracket Order ID: {orderid}")
        return orderid
    except Exception as e:
        print(f"{symb} Failed to place Bracket Order: {e}")
        return None
