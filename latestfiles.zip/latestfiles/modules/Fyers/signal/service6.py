

import pandas as pd
from fyers_apiv3 import fyersModel
import datetime as dt
import pytz
import numpy as np
import time

import json
import os

#generate trading session
client_id = open("client_id.txt",'r').read()
access_token = open("access_token.txt",'r').read()
# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")



def signal(
    ema5, ema21, st21Buy, st21Sell, st21Trend, close,
    upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value
) -> dict:
    MARGIN_MULTIPLIER = 0.3  # 30% ATR margin

    # Basic buy/sell signals
    buy_signal = bool(st21Buy)
    sell_signal = bool(st21Sell)

    # Best buy/sell based on EMA and trend
    best_buy_signal = ema5 > ema21 and st21Trend == 1
    best_sell_signal = ema5 < ema21 and st21Trend == -1

    # Strong buy/sell based on Bollinger Bands and margin
    strong_buy_signal = (close >= upperBB - (atr_value * MARGIN_MULTIPLIER)) and (st21Trend == 1)
    strong_sell_signal = (close <= lowerBB + (atr_value * MARGIN_MULTIPLIER)) and (st21Trend == -1)

    # Exit Signals (corrected now)
    exit_sell_signal = (st21Trend == 1 or close > support) and not sell_signal
    exit_buy_signal = (st21Trend == -1 or close < resistance) and not buy_signal

    exit_best_buy_signal = (ema5 < ema21 or st21Trend == -1) and not best_buy_signal
    exit_best_sell_signal = (ema5 > ema21 or st21Trend == 1) and not best_sell_signal

    exit_strong_buy_signal = (close < ema21 and st21Trend == -1) and not strong_buy_signal
    exit_strong_sell_signal = (close > ema21 and st21Trend == 1) and not strong_sell_signal

    # Mutual Exclusion: avoid conflicting exits
    if exit_sell_signal and exit_best_buy_signal:
        exit_best_buy_signal = False
    if exit_buy_signal and exit_best_sell_signal:
        exit_best_sell_signal = False

    return {
        "buy_signal": buy_signal,
        "sell_signal": sell_signal,
        "best_buy_signal": best_buy_signal,
        "best_sell_signal": best_sell_signal,
        "strong_buy_signal": strong_buy_signal,
        "strong_sell_signal": strong_sell_signal,
        "exit_buy_signal": exit_buy_signal,
        "exit_sell_signal": exit_sell_signal,
        "exit_best_buy_signal": exit_best_buy_signal,
        "exit_best_sell_signal": exit_best_sell_signal,
        "exit_strong_buy_signal": exit_strong_buy_signal,
        "exit_strong_sell_signal": exit_strong_sell_signal,
    }


# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, close,
#     upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value
# ) -> dict:
#     # Basic buy/sell
#     buy_signal = bool(st21Buy)
#     sell_signal = bool(st21Sell)

#     # Best buy/sell (trend following)
#     best_buy_signal = ema5 > ema21 and st21Trend == 1
#     best_sell_signal = ema5 < ema21 and st21Trend == -1

#     # Strong buy/sell: allow small margin (ATR * 0.2)
#     strong_buy_signal = (close >= upperBB - (atr_value * 0.2)) and (st21Trend == 1)
#     strong_sell_signal = (close <= lowerBB + (atr_value * 0.2)) and (st21Trend == -1)

#     # Exit signals
#     exit_buy_signal = (st21Trend == -1 or close < resistance) and not sell_signal
#     exit_sell_signal = (st21Trend == 1 or close > support) and not buy_signal

#     exit_best_buy_signal = (ema5 < ema21 or st21Trend == -1) and not best_sell_signal
#     exit_best_sell_signal = (ema5 > ema21 or st21Trend == 1) and not best_buy_signal

#     exit_strong_buy_signal = (close < ema21 and st21Trend == -1) and not strong_sell_signal
#     exit_strong_sell_signal = (close > ema21 and st21Trend == 1) and not strong_buy_signal

#     # Mutual exclusion
#     if exit_sell_signal and exit_best_buy_signal:
#         exit_best_buy_signal = False
#     if exit_buy_signal and exit_best_sell_signal:
#         exit_best_sell_signal = False

#     return {
#         "buy_signal": buy_signal,
#         "sell_signal": sell_signal,
#         "best_buy_signal": best_buy_signal,
#         "best_sell_signal": best_sell_signal,
#         "strong_buy_signal": strong_buy_signal,
#         "strong_sell_signal": strong_sell_signal,
#         "exit_buy_signal": exit_buy_signal,
#         "exit_sell_signal": exit_sell_signal,
#         "exit_best_buy_signal": exit_best_buy_signal,
#         "exit_best_sell_signal": exit_best_sell_signal,
#         "exit_strong_buy_signal": exit_strong_buy_signal,
#         "exit_strong_sell_signal": exit_strong_sell_signal,
#     }




# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, close,
#     upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value
# ) -> dict:
#     # 1. Buy signal (basic st21Buy signal)
#     buy_signal = bool(st21Buy)

#     # 2. Sell signal (basic st21Sell signal)
#     sell_signal = bool(st21Sell)

#     # 3. Best Buy signal
#     best_buy_signal = ema5 > ema21 and st21Trend == 1

#     # 4. Best Sell signal
#     best_sell_signal = ema5 < ema21 and st21Trend == -1

#     # 5. Strong Buy signal
#     strong_buy_signal = ema5 > st21UP and close > upperBB

#     # 6. Strong Sell signal
#     strong_sell_signal = ema5 < st21DN and close < lowerBB

#     # --- Exit Conditions ---

#     # 7. Exit Buy signal
#     exit_buy_signal = (st21Trend == -1 or close < resistance) and not sell_signal

#     # 8. Exit Sell signal
#     exit_sell_signal = (st21Trend == 1 or close > support) and not buy_signal

#     # 9. Exit Best Buy signal
#     exit_best_buy_signal = (ema5 < ema21 or st21Trend == -1) and not best_sell_signal

#     # 10. Exit Best Sell signal
#     exit_best_sell_signal = (ema5 > ema21 or st21Trend == 1) and not best_buy_signal

#     # 11. Exit Strong Buy signal
#     exit_strong_buy_signal = (ema21 > close and st21Trend == -1) and not strong_sell_signal

#     # 12. Exit Strong Sell signal
#     exit_strong_sell_signal = (ema21 < close and st21Trend == 1) and not strong_buy_signal

#     # --- Ensure mutual exclusion ---
#     if exit_sell_signal and exit_best_buy_signal:
#         # Give priority: sell exit dominates, cancel best buy exit
#         exit_best_buy_signal = False
#     if exit_buy_signal and exit_best_sell_signal:
#         exit_best_sell_signal = False

#     return {
#         "buy_signal": buy_signal,
#         "sell_signal": sell_signal,
#         "best_buy_signal": best_buy_signal,
#         "best_sell_signal": best_sell_signal,
#         "strong_buy_signal": strong_buy_signal,
#         "strong_sell_signal": strong_sell_signal,
#         "exit_buy_signal": exit_buy_signal,
#         "exit_sell_signal": exit_sell_signal,
#         "exit_best_buy_signal": exit_best_buy_signal,
#         "exit_best_sell_signal": exit_best_sell_signal,
#         "exit_strong_buy_signal": exit_strong_buy_signal,
#         "exit_strong_sell_signal": exit_strong_sell_signal,
#     }




# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, close,
#     upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value
# ) -> dict:
#     # 1. Buy signal (basic st21Buy signal)
#     buy_signal = bool(st21Buy)

#     # 2. Sell signal (basic st21Sell signal)
#     sell_signal = bool(st21Sell)

#     # 3. Best Buy signal (ema5 > ema21 and st21Trend is up)
#     best_buy_signal = ema5 > ema21 and st21Trend == 1

#     # 4. Best Sell signal (ema5 < ema21 and st21Trend is down)
#     best_sell_signal = ema5 < ema21 and st21Trend == -1

#     # 5. Strong Buy signal (ema5 > supertrend upper band and close > upper Bollinger Band)
#     strong_buy_signal = ema5 > st21UP and close > upperBB

#     # 6. Strong Sell signal (ema5 < supertrend lower band and close < lowerBB)
#     strong_sell_signal = ema5 < st21DN and close < lowerBB

#     # 7. Exit Buy signal (trend reversal or close below resistance)
#     exit_buy_signal = st21Trend == -1 or close < resistance

#     # 8. Exit Sell signal (trend reversal or close above support)
#     exit_sell_signal = st21Trend == 1 or close > support

#     # 9. Exit Best Buy signal (ema5 crosses below ema21 or trend reverses)
#     exit_best_buy_signal = ema5 < ema21 or st21Trend == -1

#     # 10. Exit Best Sell signal (ema5 crosses above ema21 or trend reverses)
#     exit_best_sell_signal = ema5 > ema21 or st21Trend == 1

#     # 11. Exit Strong Buy signal (ema21 crosses above close and trend reversal)
#     exit_strong_buy_signal = ema21 > close and st21Trend == -1

#     # 12. Exit Strong Sell signal (ema21 crosses below close and trend reversal)
#     exit_strong_sell_signal = ema21 < close and st21Trend == 1

#     return {
#         "buy_signal": buy_signal,
#         "sell_signal": sell_signal,
#         "best_buy_signal": best_buy_signal,
#         "best_sell_signal": best_sell_signal,
#         "strong_buy_signal": strong_buy_signal,
#         "strong_sell_signal": strong_sell_signal,
#         "exit_buy_signal": exit_buy_signal,
#         "exit_sell_signal": exit_sell_signal,
#         "exit_best_buy_signal": exit_best_buy_signal,
#         "exit_best_sell_signal": exit_best_sell_signal,
#         "exit_strong_buy_signal": exit_strong_buy_signal,
#         "exit_strong_sell_signal": exit_strong_sell_signal,
#     }




# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, close,
#     upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value
# ):
#     # 1. Buy signal (basic st21Buy signal)
#     buy_signal = st21Buy

#     # 2. Sell signal (basic st21Sell signal)
#     sell_signal = st21Sell

#     # 3. Best Buy signal (ema5 > ema21 and st21Trend is up)
#     best_buy_signal = ema5 > ema21 and st21Trend == 1

#     # 4. Best Sell signal (ema5 < ema21 and st21Trend is down)
#     best_sell_signal = ema5 < ema21 and st21Trend == -1

#     # 5. Strong Buy signal (ema5 > supertrend upper band and close > upper Bollinger Band)
#     strong_buy_signal = ema5 > st21UP and close > upperBB

#     # 6. Strong Sell signal (ema5 < supertrend lower band and close < lower Bollinger Band)
#     strong_sell_signal = ema5 < st21DN and close < lowerBB

#     # 7. Exit Buy signal (trend reversal or close below resistance)
#     exit_buy_signal = st21Trend == -1 or close < resistance

#     # 8. Exit Sell signal (trend reversal or close above support)
#     exit_sell_signal = st21Trend == 1 or close > support

#     # 9. Exit Best Buy signal (ema5 crosses below ema21 or trend reverses)
#     exit_best_buy_signal = ema5 < ema21 or st21Trend == -1

#     # 10. Exit Best Sell signal (ema5 crosses above ema21 or trend reverses)
#     exit_best_sell_signal = ema5 > ema21 or st21Trend == 1

#     # 11. Exit Strong Buy signal (ema21 crosses above close and trend reversal)
#     exit_strong_buy_signal = ema21 > close and st21Trend == -1

#     # 12. Exit Strong Sell signal (ema21 crosses below close and trend reversal)
#     exit_strong_sell_signal = ema21 < close and st21Trend == 1

#     return {
#         "buy_signal": buy_signal,
#         "sell_signal": sell_signal,
#         "best_buy_signal": best_buy_signal,
#         "best_sell_signal": best_sell_signal,
#         "strong_buy_signal": strong_buy_signal,
#         "strong_sell_signal": strong_sell_signal,
#         "exit_buy_signal": exit_buy_signal,
#         "exit_sell_signal": exit_sell_signal,
#         "exit_best_buy_signal": exit_best_buy_signal,
#         "exit_best_sell_signal": exit_best_sell_signal,
#         "exit_strong_buy_signal": exit_strong_buy_signal,
#         "exit_strong_sell_signal": exit_strong_sell_signal,
#     }


# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, close,
#     upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value,
#     inBuy=False, inSell=False, inBestBuy=False, inBestSell=False, inStrongBuy=False, inStrongSell=False
# ):
#     signals = {
#         'buy_signal': False,
#         'sell_signal': False,
#         'best_buy_signal': False,
#         'best_sell_signal': False,
#         'strong_buy_signal': False,
#         'strong_sell_signal': False,
#         'buy_begins': False,
#         'sell_begins': False,
#         'exit_buy': False,
#         'exit_sell': False,
#         'exit_best_buy': False,
#         'exit_best_sell': False,
#         'exit_strong_buy': False,
#         'exit_strong_sell': False
#     }

#     # Thresholds
#     upper_bb_tolerance = 1.03
#     lower_bb_tolerance = 0.97
#     atr_threshold = 0.5 * atr_value

#     # --- Main Entry Signals ---
#     if st21Buy and st21Trend == 1:
#         signals['buy_signal'] = True

#     if st21Sell and st21Trend == -1:
#         signals['sell_signal'] = True

#     if ema5 > ema21 and st21Trend == 1 and close > support:
#         signals['best_buy_signal'] = True

#     if ema5 < ema21 and st21Trend == -1 and close < resistance:
#         signals['best_sell_signal'] = True

#     if (ema5 > st21UP and close > upperBB) or (st21Buy and close >= upperBB * 0.99):
#         signals['strong_buy_signal'] = True

#     if (ema5 < st21DN and close < lowerBB) or (st21Sell and close <= lowerBB * 1.01):
#         signals['strong_sell_signal'] = True

#     # --- Buy/Sell Begin signals ---
#     if (signals['buy_signal'] and ema5 > ema21 and close > st21UP and close > prev_close and
#         close < upperBB * upper_bb_tolerance and (close - st21UP) > atr_threshold):
#         signals['buy_begins'] = True

#     if (signals['sell_signal'] and ema5 < ema21 and close < st21DN and close < prev_close and
#         close > lowerBB * lower_bb_tolerance and (st21DN - close) > atr_threshold):
#         signals['sell_begins'] = True

#     # --- Exit signals (only if already inside a position!) ---

#     if inBuy:
#         if st21Trend == -1 or close < resistance:
#             signals['exit_buy'] = True

#     if inSell:
#         if st21Trend == 1 or close > support:
#             signals['exit_sell'] = True

#     if inBestBuy:
#         if ema5 < ema21 or close < support:
#             signals['exit_best_buy'] = True

#     if inBestSell:
#         if ema5 > ema21 or close > resistance:
#             signals['exit_best_sell'] = True

#     if inStrongBuy:
#         if close < upperBB or st21Trend == -1:
#             signals['exit_strong_buy'] = True

#     if inStrongSell:
#         if close > lowerBB or st21Trend == 1:
#             signals['exit_strong_sell'] = True

#     # --- Ensuring Exit Logic based on Opposite Signals ---
#     if signals['buy_signal'] or signals['strong_buy_signal']:
#         signals['exit_sell'] = True  # Exit sell if buy signal occurs
#     if signals['sell_signal'] or signals['strong_sell_signal']:
#         signals['exit_buy'] = True  # Exit buy if sell signal occurs

#     return signals




# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, close,
#     upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value,
#     inBuy=False, inSell=False, inBestBuy=False, inBestSell=False, inStrongBuy=False, inStrongSell=False
# ):
#     signals = {
#         'buy_signal': False,
#         'sell_signal': False,
#         'best_buy_signal': False,
#         'best_sell_signal': False,
#         'strong_buy_signal': False,
#         'strong_sell_signal': False,
#         'buy_begins': False,
#         'sell_begins': False,
#         'exit_buy': False,
#         'exit_sell': False,
#         'exit_best_buy': False,
#         'exit_best_sell': False,
#         'exit_strong_buy': False,
#         'exit_strong_sell': False
#     }

#     # Thresholds
#     upper_bb_tolerance = 1.03
#     lower_bb_tolerance = 0.97
#     atr_threshold = 0.5 * atr_value

#     # --- Main Entry Signals ---
#     if st21Buy and st21Trend == 1:
#         signals['buy_signal'] = True

#     if st21Sell and st21Trend == -1:
#         signals['sell_signal'] = True

#     if ema5 > ema21 and st21Trend == 1 and close > support:
#         signals['best_buy_signal'] = True

#     if ema5 < ema21 and st21Trend == -1 and close < resistance:
#         signals['best_sell_signal'] = True

#     if (ema5 > st21UP and close > upperBB) or (st21Buy and close >= upperBB * 0.99):
#         signals['strong_buy_signal'] = True

#     if (ema5 < st21DN and close < lowerBB) or (st21Sell and close <= lowerBB * 1.01):
#         signals['strong_sell_signal'] = True

#     # --- Buy/Sell Begin signals ---
#     if (signals['buy_signal'] and ema5 > ema21 and close > st21UP and close > prev_close and
#         close < upperBB * upper_bb_tolerance and (close - st21UP) > atr_threshold):
#         signals['buy_begins'] = True

#     if (signals['sell_signal'] and ema5 < ema21 and close < st21DN and close < prev_close and
#         close > lowerBB * lower_bb_tolerance and (st21DN - close) > atr_threshold):
#         signals['sell_begins'] = True

#     # --- Exit signals (only if already inside a position!) ---

#     if inBuy:
#         if st21Trend == -1 or close < resistance:
#             signals['exit_buy'] = True

#     if inSell:
#         if st21Trend == 1 or close > support:
#             signals['exit_sell'] = True

#     if inBestBuy:
#         if ema5 < ema21 or close < support:
#             signals['exit_best_buy'] = True

#     if inBestSell:
#         if ema5 > ema21 or close > resistance:
#             signals['exit_best_sell'] = True

#     if inStrongBuy:
#         if close < upperBB or st21Trend == -1:
#             signals['exit_strong_buy'] = True

#     if inStrongSell:
#         if close > lowerBB or st21Trend == 1:
#             signals['exit_strong_sell'] = True

#     return signals
# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, close,
#     upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value,
#     inBuy=False, inSell=False, inBestBuy=False, inBestSell=False, inStrongBuy=False, inStrongSell=False
# ):
#     signals = {
#         'buy_signal': False,
#         'sell_signal': False,
#         'best_buy_signal': False,
#         'best_sell_signal': False,
#         'strong_buy_signal': False,
#         'strong_sell_signal': False,
#         'buy_begins': False,
#         'sell_begins': False,
#         'exit_buy': False,
#         'exit_sell': False,
#         'exit_best_buy': False,
#         'exit_best_sell': False,
#         'exit_strong_buy': False,
#         'exit_strong_sell': False
#     }

#     # Thresholds
#     upper_bb_tolerance = 1.03
#     lower_bb_tolerance = 0.97
#     atr_threshold = 0.5 * atr_value

#     # --- Main Entry Signals ---
#     if st21Buy and st21Trend == 1:
#         signals['buy_signal'] = True

#     if st21Sell and st21Trend == -1:
#         signals['sell_signal'] = True

#     if ema5 > ema21 and st21Trend == 1 and close > support:
#         signals['best_buy_signal'] = True

#     if ema5 < ema21 and st21Trend == -1 and close < resistance:
#         signals['best_sell_signal'] = True

#     if (ema5 > st21UP and close > upperBB) or (st21Buy and close >= upperBB * 0.99):
#         signals['strong_buy_signal'] = True

#     if (ema5 < st21DN and close < lowerBB) or (st21Sell and close <= lowerBB * 1.01):
#         signals['strong_sell_signal'] = True

#     # --- Buy/Sell Begin signals ---
#     if (signals['buy_signal'] and ema5 > ema21 and close > st21UP and close > prev_close and
#         close < upperBB * upper_bb_tolerance and (close - st21UP) > atr_threshold):
#         signals['buy_begins'] = True

#     if (signals['sell_signal'] and ema5 < ema21 and close < st21DN and close < prev_close and
#         close > lowerBB * lower_bb_tolerance and (st21DN - close) > atr_threshold):
#         signals['sell_begins'] = True

#     # --- Exit signals (only if already inside a position!) ---

#     if inBuy:
#         if st21Trend == -1 or close < resistance:
#             signals['exit_buy'] = True

#     if inSell:
#         if st21Trend == 1 or close > support:
#             signals['exit_sell'] = True

#     if inBestBuy:
#         if ema5 < ema21 or close < support:
#             signals['exit_best_buy'] = True

#     if inBestSell:
#         if ema5 > ema21 or close > resistance:
#             signals['exit_best_sell'] = True

#     if inStrongBuy:
#         if close < upperBB or st21Trend == -1:
#             signals['exit_strong_buy'] = True

#     if inStrongSell:
#         if close > lowerBB or st21Trend == 1:
#             signals['exit_strong_sell'] = True

#     return signals




# # Refactored generate_signals function using signal() function
# def generate_signals(df, plot_distance=1):
#     inBuy = False
#     inSell = False
#     buyCounter = None
#     sellCounter = None

#     # Lists to store signals
#     signals = []

#     # Create empty columns in DataFrame
#     df['inBuy'] = False
#     df['inSell'] = False
#     df['bestBuysignal'] = False
#     df['bestSellsignal'] = False
#     df['strongBuysignal'] = False
#     df['strongSellsignal'] = False
#     df['exitStrongBuysignal'] = False
#     df['exitStrongSellsignal'] = False
#     df['exitBestBuysignal'] = False
#     df['exitBestSellsignal'] = False

#     for i in range(len(df)):
#         row = df.iloc[i]

#         # --- Get necessary data for the signal() function ---
#         ema5 = row['ema5']
#         ema21 = row['ema21']
#         st21Buy = row['st21Buy']
#         st21Sell = row['st21Sell']
#         st21Trend = row['st21Trend']
#         close = row['close']
#         upperBB = row['upperBB']
#         lowerBB = row['lowerBB']
#         st21UP = row['st21UP']
#         st21DN = row['st21DN']
#         support = row['support']
#         resistance = row['resistance']
#         prev_close = row['prev_close']
#         atr_value = row['atr_value']

#         # --- Call signal function ---
#         signal_result = signal(
#             ema5, ema21, st21Buy, st21Sell, st21Trend, close,
#             upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value
#         )

#         # --- Apply Logic based on the signal results ---
#         if signal_result['buy_begins'] and not inBuy:
#             inBuy = True
#             inSell = False
#             buyCounter = 0
#             signals.append((i, "Buy Signal"))

#         if signal_result['sell_begins'] and not inSell:
#             inSell = True
#             inBuy = False
#             sellCounter = 0
#             signals.append((i, "Sell Signal"))

#         # Exit signals for Buy/Sell
#         exitBuysignal = inBuy and (st21Trend == -1 or close < resistance)
#         exitSellsignal = inSell and (st21Trend == 1 or close > support)

#         if exitBuysignal:
#             inBuy = False
#             signals.append((i, "Exit Buy Signal"))
#         if exitSellsignal:
#             inSell = False
#             signals.append((i, "Exit Sell Signal"))

#         # Update counters
#         if buyCounter is not None:
#             buyCounter += 1
#         if sellCounter is not None:
#             sellCounter += 1

#         # Update flags to DataFrame for tracking
#         df.at[i, 'inBuy'] = inBuy
#         df.at[i, 'inSell'] = inSell
#         df.at[i, 'bestBuysignal'] = signal_result['best_buy_signal']
#         df.at[i, 'bestSellsignal'] = signal_result['best_sell_signal']
#         df.at[i, 'strongBuysignal'] = signal_result['strong_buy_signal']
#         df.at[i, 'strongSellsignal'] = signal_result['strong_sell_signal']
#         df.at[i, 'exitStrongBuysignal'] = signal_result['buy_begins']
#         df.at[i, 'exitStrongSellsignal'] = signal_result['sell_begins']

#     return signals, df


#old script working fine restore above script not working
# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, close,
#     upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value
# ):
#     """
#     Final refined signal function for generating trading signals with robust signals.
#     """

#     # Initialize signals
#     signals = {
#         'buy_signal': False,
#         'sell_signal': False,
#         'best_buy_signal': False,
#         'best_sell_signal': False,
#         'strong_buy_signal': False,
#         'strong_sell_signal': False,
#         'buy_begins': False,
#         'sell_begins': False
#     }

#     # Thresholds
#     upper_bb_tolerance = 1.03  # Tolerance for proximity to upper Bollinger Band
#     lower_bb_tolerance = 0.97  # Tolerance for proximity to lower Bollinger Band
#     atr_threshold = 0.5  # Proportion of ATR for significant price movement

#     # 1. Basic Buy/Sell Signals
#     if st21Buy and st21Trend == 1:
#         signals['buy_signal'] = True
#     if st21Sell and st21Trend == -1:
#         signals['sell_signal'] = True

#     # 2. Best Buy/Sell Signals (EMA alignment with trend and support/resistance)
#     if ema5 > ema21 and st21Trend == 1 and close > support:
#         signals['best_buy_signal'] = True
#     if ema5 < ema21 and st21Trend == -1 and close < resistance:
#         signals['best_sell_signal'] = True

#     # 3. Strong Buy/Sell Signals (Price action around Bollinger Bands and SuperTrend)
#     if (
#         (ema5 > st21UP and close > upperBB) or
#         (st21Buy and close >= upperBB * 0.99) or
#         (ema5 > ema21 and close > st21UP and close > upperBB * 0.97)
#     ):
#         signals['strong_buy_signal'] = True
#     if (
#         (ema5 < st21DN and close < lowerBB) or
#         (st21Sell and close <= lowerBB * 1.01) or
#         (ema5 < ema21 and close < st21DN and close < lowerBB * 1.03)
#     ):
#         signals['strong_sell_signal'] = True

#     # 4. Refined Buy Begins Signal
#     if (
#         signals['buy_signal'] and 
#         ema5 > ema21 and  # Confirm bullish EMA crossover
#         st21Trend == 1 and  # Confirm uptrend
#         close > st21UP and  # Price above SuperTrend UP
#         close > prev_close and  # Positive momentum (close > previous close)
#         close < upperBB * upper_bb_tolerance and  # Close near but below overbought region
#         (close - st21UP) > atr_threshold * atr_value  # Significant price movement above SuperTrend
#     ):
#         signals['buy_begins'] = True

#     # 5. Refined Sell Begins Signal
#     if (
#         signals['sell_signal'] and 
#         ema5 < ema21 and  # Confirm bearish EMA crossover
#         st21Trend == -1 and  # Confirm downtrend
#         close < st21DN and  # Price below SuperTrend DN
#         close < prev_close and  # Negative momentum (close < previous close)
#         close > lowerBB * lower_bb_tolerance and  # Close near but above oversold region
#         (st21DN - close) > atr_threshold * atr_value  # Significant price movement below SuperTrend
#     ):
#         signals['sell_begins'] = True

#     return signals




# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, close,
#     upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value
# ):
#     """
#     Final refined signal function for generating trading signals with robust signals.
#     """

#     # Initialize signals
#     signals = {
#         'buy_signal': False,
#         'sell_signal': False,
#         'best_buy_signal': False,
#         'best_sell_signal': False,
#         'strong_buy_signal': False,
#         'strong_sell_signal': False,
#         'buy_begins': False,
#         'sell_begins': False
#     }

#     # Thresholds
#     upper_bb_tolerance = 1.03  # Tolerance for proximity to upper Bollinger Band
#     lower_bb_tolerance = 0.97  # Tolerance for proximity to lower Bollinger Band
#     atr_threshold = 0.5  # Proportion of ATR for significant price movement

#     # 1. Basic Buy/Sell Signals
#     if st21Buy and st21Trend == 1:
#         signals['buy_signal'] = True
#     if st21Sell and st21Trend == -1:
#         signals['sell_signal'] = True

#     # 2. Best Buy/Sell Signals (EMA alignment with trend and support/resistance)
#     if ema5 > ema21 and st21Trend == 1 and close > support:
#         signals['best_buy_signal'] = True
#     if ema5 < ema21 and st21Trend == -1 and close < resistance:
#         signals['best_sell_signal'] = True

#     # 3. Strong Buy/Sell Signals (Price action around Bollinger Bands and SuperTrend)
#     if (
#         (ema5 > st21UP and close > upperBB) or
#         (st21Buy and close >= upperBB * 0.99) or
#         (ema5 > ema21 and close > st21UP and close > upperBB * 0.97)
#     ):
#         signals['strong_buy_signal'] = True
#     if (
#         (ema5 < st21DN and close < lowerBB) or
#         (st21Sell and close <= lowerBB * 1.01) or
#         (ema5 < ema21 and close < st21DN and close < lowerBB * 1.03)
#     ):
#         signals['strong_sell_signal'] = True

#     # 4. Refined Buy Begins Signal
#     if (
#         signals['buy_signal'] and 
#         ema5 > ema21 and  # Confirm bullish EMA crossover
#         st21Trend == 1 and  # Confirm uptrend
#         close > st21UP and  # Price above SuperTrend UP
#         close > prev_close  # Positive momentum (close > previous close)
#     ):
#         # Relaxed signal for ATR-based price movement
#         if (close - st21UP) > atr_threshold * atr_value:
#             signals['buy_begins'] = True
#         elif close > st21UP and close > prev_close:  # Fallback signal
#             signals['buy_begins'] = True

#     # 5. Refined Sell Begins Signal
#     if (
#         signals['sell_signal'] and 
#         ema5 < ema21 and  # Confirm bearish EMA crossover
#         st21Trend == -1 and  # Confirm downtrend
#         close < st21DN and  # Price below SuperTrend DN
#         close < prev_close  # Negative momentum (close < previous close)
#     ):
#         # Relaxed signal for ATR-based price movement
#         if (st21DN - close) > atr_threshold * atr_value:
#             signals['sell_begins'] = True
#         elif close < st21DN and close < prev_close:  # Fallback signal
#             signals['sell_begins'] = True

#     return signals





# #old function as below
# def signal(ema_5, ema_21, st21Buy, st21Sell, st21Trend, close, upper_bb, lower_bb, st21UP, st21DN, support, resistance, atr_value):
#     """
#     Calculate trading signals based on various indicators.
#     """
#     signals = {
#         "buy_signal": False,
#         "sell_signal": False,
#         "buy_begins": False,
#         "sell_begins": False,
#         "best_buy_signal": False,
#         "best_sell_signal": False,
#         "strong_buy_signal": False,
#         "strong_sell_signal": False,
#         "confirmed_buy": False,
#         "confirmed_sell": False,
#         "exit_buy": False,
#         "exit_sell": False
#     }

#     # Buy signal logic when st21Buy is True
#     if st21Buy:
#         if close > ema_5 and close < upper_bb:
#             signals["buy_signal"] = True
    
#     # Sell signal logic when st21Sell is True
#     if st21Sell:
#         if close < ema_5 and close > lower_bb:
#             signals["sell_signal"] = True

#     # Best signal logic based on trend strength
#     if st21Buy and close < upper_bb:
#         signals["best_buy_signal"] = True
#     if st21Sell and close > lower_bb:
#         signals["best_sell_signal"] = True

#     # Strong buy/sell signals based on supertrend levels
#     if st21Buy and close > st21UP:
#         signals["strong_buy_signal"] = True
#     if st21Sell and close < st21DN:
#         signals["strong_sell_signal"] = True

#     # Confirmed buy/sell based on resistance/support
#     if signals["strong_buy_signal"] and close < resistance:
#         signals["confirmed_buy"] = True
#     if signals["strong_sell_signal"] and close > support:
#         signals["confirmed_sell"] = True

#     # Exit signals (based on mutual exclusivity)
#     if signals["confirmed_buy"] and close < ema_5:
#         signals["exit_buy"] = True
#         signals["exit_sell"] = False  # Ensure mutual exclusivity
#     elif signals["confirmed_sell"] and close > ema_5:
#         signals["exit_sell"] = True
#         signals["exit_buy"] = False  # Ensure mutual exclusivity
#     else:
#         signals["exit_buy"] = False
#         signals["exit_sell"] = False

#     return signals
