

import pandas as pd
from fyers_apiv3 import fyersModel
import datetime as dt
import pytz
import numpy as np
import time

import json
import os

#generate trading session
client_id = open("client_id.txt",'r').read()
access_token = open("access_token.txt",'r').read()
# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")


import datetime as dt

def signal(
    ema5, ema21, st21Buy, st21Sell, st21Trend, close,
    upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value
):
    """
    Generate trading signals based on technical indicators.
    Prevents conflicting exit signals and ensures logical consistency.
    """
    signals = {
        "buy": False,
        "sell": False,
        "exit_buy": False,
        "exit_sell": False,
        "best_buy": False,
        "best_sell": False,
        "strong_buy": False,
        "strong_sell": False,
        "exit_strong_buy": False,
        "exit_strong_sell": False,
        "exit_best_buy": False,
        "exit_best_sell": False,
    }

    # Standard Buy and Sell Signals
    if st21Buy and close > ema5 and close > ema21:
        signals["buy"] = True
    if st21Sell and close < ema5 and close < ema21:
        signals["sell"] = True

    # Best Buy/Sell based on trend and key levels
    if st21Buy and st21Trend == 1 and close > support:
        signals["best_buy"] = True
    if st21Sell and st21Trend == -1 and close < resistance:
        signals["best_sell"] = True

    # Strong Buy/Sell based on Bollinger Bands
    if signals["buy"] and close < lowerBB:
        signals["strong_buy"] = True
    if signals["sell"] and close > upperBB:
        signals["strong_sell"] = True

    # Exit conditions based on trend direction
    if st21Trend == 1:
        signals["exit_sell"] = True
        signals["exit_buy"] = False  # Ensuring no conflicts
    elif st21Trend == -1:
        signals["exit_buy"] = True
        signals["exit_sell"] = False  # Ensuring no conflicts

    # ATR-based additional exit conditions (Ensuring exit_best_* do not conflict)
    if prev_close - close > atr_value and not signals["best_sell"]:
        signals["exit_best_buy"] = True
    if close - prev_close > atr_value and not signals["best_buy"]:
        signals["exit_best_sell"] = True

    return signals



# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, close,
#     upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value
# ):
#     """
#     Generate trading signals based on technical indicators.
#     Ensures `exit_buy` and `exit_sell` are logically correct.
#     """
#     signals = {
#         "buy": False,
#         "sell": False,
#         "exit_buy": False,
#         "exit_sell": False,
#         "best_buy": False,
#         "best_sell": False,
#         "strong_buy": False,
#         "strong_sell": False,
#         "exit_strong_buy": False,
#         "exit_strong_sell": False,
#         "exit_best_buy": False,
#         "exit_best_sell": False,
#     }

#     # Buy and Sell signals based on SuperTrend and EMA
#     if st21Buy and close > ema5 and close > ema21:
#         signals["buy"] = True
#     if st21Sell and close < ema5 and close < ema21:
#         signals["sell"] = True

#     # Best Buy/Sell logic considering trend direction
#     if st21Buy and st21Trend == 1 and close > support:
#         signals["best_buy"] = True
#     if st21Sell and st21Trend == -1 and close < resistance:
#         signals["best_sell"] = True  # <-- FIXED

#     # Strong Buy/Sell based on Bollinger Bands
#     if signals["buy"] and close < lowerBB:
#         signals["strong_buy"] = True
#     if signals["sell"] and close > upperBB:
#         signals["strong_sell"] = True

#     # Exit conditions based on trend
#     if st21Trend == 1:
#         signals["exit_sell"] = True
#         signals["exit_buy"] = False
#     elif st21Trend == -1:
#         signals["exit_buy"] = True
#         signals["exit_sell"] = False

#     # ATR-based additional exit conditions
#     if prev_close - close > atr_value:
#         signals["exit_best_buy"] = True
#     if close - prev_close > atr_value:
#         signals["exit_best_sell"] = True

#     return signals

 #buy_signal working for 30 and 60 min
# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, close,
#     upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value
# ):
#     """
#     Final refined signal function for generating trading signals with robust conditions.
#     """

#     # Initialize signals
#     signals = {
#         'buy_signal': False,
#         'sell_signal': False,
#         'best_buy_signal': False,
#         'best_sell_signal': False,
#         'strong_buy_signal': False,
#         'strong_sell_signal': False,
#         'buy_begins': False,
#         'sell_begins': False
#     }

#     # Thresholds
#     upper_bb_tolerance = 1.03  # Tolerance for proximity to upper Bollinger Band
#     lower_bb_tolerance = 0.97  # Tolerance for proximity to lower Bollinger Band
#     atr_threshold = 0.5  # Proportion of ATR for significant price movement
#     st21UP_tolerance = 0.995  # Allow close to be slightly below st21UP (0.5% tolerance)

#     # 1. Basic Buy/Sell Signals
#     if st21Buy and st21Trend == 1:
#         signals['buy_signal'] = True
#     if st21Sell and st21Trend == -1:
#         signals['sell_signal'] = True

#     # 2. Best Buy/Sell Signals (EMA alignment with trend and support/resistance)
#     if ema5 > ema21 and st21Trend == 1 and close > support:
#         signals['best_buy_signal'] = True
#     if ema5 < ema21 and st21Trend == -1 and close < resistance:
#         signals['best_sell_signal'] = True

#     # 3. Strong Buy/Sell Signals (Price action around Bollinger Bands and SuperTrend)
#     if (
#         (ema5 > st21UP and close > upperBB) or
#         (st21Buy and close >= upperBB * 0.99) or
#         (ema5 > ema21 and close > st21UP and close > upperBB * 0.97)
#     ):
#         signals['strong_buy_signal'] = True
#     if (
#         (ema5 < st21DN and close < lowerBB) or
#         (st21Sell and close <= lowerBB * 1.01) or
#         (ema5 < ema21 and close < st21DN and close < lowerBB * 1.03)
#     ):
#         signals['strong_sell_signal'] = True

#     # 4. Refined Buy Begins Signal
#     if (
#         signals['buy_signal'] and 
#         ema5 > ema21 and  # Confirm bullish EMA crossover
#         st21Trend == 1 and  # Confirm uptrend
#         close > st21UP * st21UP_tolerance and  # Price above or near SuperTrend UP
#         close > prev_close  # Positive momentum (close > previous close)
#     ):
#         # Relaxed condition for ATR-based price movement
#         if (close - st21UP) > atr_threshold * atr_value:
#             signals['buy_begins'] = True
#         elif close > st21UP * st21UP_tolerance and close > prev_close:  # Fallback condition
#             signals['buy_begins'] = True

#     # 5. Refined Sell Begins Signal
#     if (
#         signals['sell_signal'] and 
#         ema5 < ema21 and  # Confirm bearish EMA crossover
#         st21Trend == -1 and  # Confirm downtrend
#         close < st21DN * (2 - st21UP_tolerance) and  # Price below or near SuperTrend DN
#         close < prev_close  # Negative momentum (close < previous close)
#     ):
#         # Relaxed condition for ATR-based price movement
#         if (st21DN - close) > atr_threshold * atr_value:
#             signals['sell_begins'] = True
#         elif close < st21DN * (2 - st21UP_tolerance) and close < prev_close:  # Fallback condition
#             signals['sell_begins'] = True

#     return signals

# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, close,
#     upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value
# ):
#     """
#     Final refined signal function for generating trading signals with robust conditions.
#     """

#     # Initialize signals
#     signals = {
#         'buy_signal': False,
#         'sell_signal': False,
#         'best_buy_signal': False,
#         'best_sell_signal': False,
#         'strong_buy_signal': False,
#         'strong_sell_signal': False,
#         'buy_begins': False,
#         'sell_begins': False
#     }

#     # Thresholds
#     upper_bb_tolerance = 1.03  # Tolerance for proximity to upper Bollinger Band
#     lower_bb_tolerance = 0.97  # Tolerance for proximity to lower Bollinger Band
#     atr_threshold = 0.5  # Proportion of ATR for significant price movement

#     # 1. Basic Buy/Sell Signals
#     if st21Buy and st21Trend == 1:
#         signals['buy_signal'] = True
#     if st21Sell and st21Trend == -1:
#         signals['sell_signal'] = True

#     # 2. Best Buy/Sell Signals (EMA alignment with trend and support/resistance)
#     if ema5 > ema21 and st21Trend == 1 and close > support:
#         signals['best_buy_signal'] = True
#     if ema5 < ema21 and st21Trend == -1 and close < resistance:
#         signals['best_sell_signal'] = True

#     # 3. Strong Buy/Sell Signals (Price action around Bollinger Bands and SuperTrend)
#     if (
#         (ema5 > st21UP and close > upperBB) or
#         (st21Buy and close >= upperBB * 0.99) or
#         (ema5 > ema21 and close > st21UP and close > upperBB * 0.97)
#     ):
#         signals['strong_buy_signal'] = True
#     if (
#         (ema5 < st21DN and close < lowerBB) or
#         (st21Sell and close <= lowerBB * 1.01) or
#         (ema5 < ema21 and close < st21DN and close < lowerBB * 1.03)
#     ):
#         signals['strong_sell_signal'] = True

#     # 4. Refined Buy Begins Signal
#     if (
#         signals['buy_signal'] and 
#         ema5 > ema21 and  # Confirm bullish EMA crossover
#         st21Trend == 1 and  # Confirm uptrend
#         close > st21UP and  # Price above SuperTrend UP
#         close > prev_close  # Positive momentum (close > previous close)
#     ):
#         # Relaxed condition for ATR-based price movement
#         if (close - st21UP) > atr_threshold * atr_value:
#             signals['buy_begins'] = True
#         elif close > st21UP and close > prev_close:  # Fallback condition
#             signals['buy_begins'] = True

#     # 5. Refined Sell Begins Signal
#     if (
#         signals['sell_signal'] and 
#         ema5 < ema21 and  # Confirm bearish EMA crossover
#         st21Trend == -1 and  # Confirm downtrend
#         close < st21DN and  # Price below SuperTrend DN
#         close < prev_close  # Negative momentum (close < previous close)
#     ):
#         # Relaxed condition for ATR-based price movement
#         if (st21DN - close) > atr_threshold * atr_value:
#             signals['sell_begins'] = True
#         elif close < st21DN and close < prev_close:  # Fallback condition
#             signals['sell_begins'] = True

#     return signals



 
# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, close,
#     upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value
# ):
#     """
#     Final refined signal function for generating trading signals with robust conditions.
#     """

#     # Initialize signals
#     signals = {
#         'buy_signal': False,
#         'sell_signal': False,
#         'best_buy_signal': False,
#         'best_sell_signal': False,
#         'strong_buy_signal': False,
#         'strong_sell_signal': False,
#         'buy_begins': False,
#         'sell_begins': False
#     }

#     # Thresholds
#     upper_bb_tolerance = 1.03  # Tolerance for proximity to upper Bollinger Band
#     lower_bb_tolerance = 0.97  # Tolerance for proximity to lower Bollinger Band
#     atr_threshold = 0.5  # Proportion of ATR for significant price movement

#     # 1. Basic Buy/Sell Signals
#     if st21Buy and st21Trend == 1:
#         signals['buy_signal'] = True
#     if st21Sell and st21Trend == -1:
#         signals['sell_signal'] = True

#     # 2. Best Buy/Sell Signals (EMA alignment with trend and support/resistance)
#     if ema5 > ema21 and st21Trend == 1 and close > support:
#         signals['best_buy_signal'] = True
#     if ema5 < ema21 and st21Trend == -1 and close < resistance:
#         signals['best_sell_signal'] = True

#     # 3. Strong Buy/Sell Signals (Price action around Bollinger Bands and SuperTrend)
#     if (
#         (ema5 > st21UP and close > upperBB) or
#         (st21Buy and close >= upperBB * 0.99) or
#         (ema5 > ema21 and close > st21UP and close > upperBB * 0.97)
#     ):
#         signals['strong_buy_signal'] = True
#     if (
#         (ema5 < st21DN and close < lowerBB) or
#         (st21Sell and close <= lowerBB * 1.01) or
#         (ema5 < ema21 and close < st21DN and close < lowerBB * 1.03)
#     ):
#         signals['strong_sell_signal'] = True

#     # 4. Refined Buy Begins Signal
#     if (
#         signals['buy_signal'] and 
#         ema5 > ema21 and  # Confirm bullish EMA crossover
#         st21Trend == 1 and  # Confirm uptrend
#         close > st21UP and  # Price above SuperTrend UP
#         close > prev_close and  # Positive momentum (close > previous close)
#         close < upperBB * upper_bb_tolerance and  # Close near but below overbought region
#         (close - st21UP) > atr_threshold * atr_value  # Significant price movement above SuperTrend
#     ):
#         signals['buy_begins'] = True

#     # 5. Refined Sell Begins Signal
#     if (
#         signals['sell_signal'] and 
#         ema5 < ema21 and  # Confirm bearish EMA crossover
#         st21Trend == -1 and  # Confirm downtrend
#         close < st21DN and  # Price below SuperTrend DN
#         close < prev_close and  # Negative momentum (close < previous close)
#         close > lowerBB * lower_bb_tolerance and  # Close near but above oversold region
#         (st21DN - close) > atr_threshold * atr_value  # Significant price movement below SuperTrend
#     ):
#         signals['sell_begins'] = True

#     return signals
