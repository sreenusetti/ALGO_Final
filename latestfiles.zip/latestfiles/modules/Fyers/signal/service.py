

import pandas as pd
from fyers_apiv3 import fyersModel
import datetime as dt
import pytz
import numpy as np
import time

import json
import os

#generate trading session
client_id = open("client_id.txt",'r').read()
access_token = open("access_token.txt",'r').read()
# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")
 


def signal(
    ema5, ema21, st21Buy, st21Sell, st21Trend,  close, 
    upperBB, lowerBB, st21UP, st21DN, support, resistance, atr_value
):
    # Initialize signals
    buy_signal = st21Buy
    sell_signal = st21Sell

    # Best Buy and Sell Signal Logic
    best_buy_signal = ema5 > ema21 and st21Trend == 1 and close > support
    best_sell_signal = ema5 < ema21 and st21Trend == -1 and close < resistance

    # Strong Buy and Sell Signal Logic
    strong_buy_signal = (
        (ema5 > st21UP and close > upperBB) or  # Original condition
        (st21Buy and ema5 > st21UP and close > support) or  # Added flexibility
        (st21Buy and close >= upperBB * 0.99)  # Allow 1% tolerance for upperBB
    )
    strong_sell_signal = (
        (ema5 < st21DN and close < lowerBB) or  # Original condition
        (st21Sell and ema5 < st21DN and close < resistance) or  # Added flexibility
        (st21Sell and close <= lowerBB * 1.01)  # Allow 1% tolerance for lowerBB
    )

    # # Buy Begins and Sell Begins Logic
    # buy_begins = buy_signal and ema5 > ema21 and close > st21UP
    # sell_begins = sell_signal and ema5 < ema21 and close < st21DN

    # buy_begins = (
    #     buy_signal and 
    #     (ema5 > ema21) and 
    #     (close > st21UP) and  # Price above SuperTrend UP level
    #     (close > resistance)  # Close above resistance level
    # )


    # sell_begins = (
    #     sell_signal and 
    #     (ema5 < ema21) and 
    #     (close < st21DN) and  # Price below SuperTrend DOWN level
    #     (close < support)  # Close below support level
    # )
        
    buy_begins = (
        buy_signal and 
        (ema5 > ema21) and 
        (st21Trend == 1) and  # Confirm uptrend
        (close > st21UP) and  # Price above SuperTrend UP level
        (close < upperBB * 1.05)  # Price near but below an overbought region
    )



    sell_begins = (
        sell_signal and 
        (ema5 < ema21) and 
        (st21Trend == -1) and  # Confirm downtrend
        (close < st21DN) and  # Price below SuperTrend DOWN level
        (close > lowerBB * 0.95)  # Price near but above an oversold region
    )

    # Return all signals
    return {
        'buy_signal': buy_signal,
        'sell_signal': sell_signal,
        'buy_begins': buy_begins,
        'sell_begins': sell_begins,
        'best_buy_signal': best_buy_signal,
        'best_sell_signal': best_sell_signal,
        'strong_buy_signal': strong_buy_signal,
        'strong_sell_signal': strong_sell_signal
    }


# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, haGreen, haRed, close, 
#     upperBB, lowerBB, st21UP, st21DN, support, resistance
# ):
#     # Initialize all signals
#     buy_signal = st21Buy
#     sell_signal = st21Sell

#     # Best Buy and Sell Signal Logic
#     best_buy_signal = ema5 > ema21 and st21Trend == 1 and close > support
#     best_sell_signal = ema5 < ema21 and st21Trend == -1 and close < resistance

#     strong_buy_signal = ema5 > st21UP and close > upperBB

#     # Adjusted Strong Sell Signal Logic
#     strong_sell_signal = (
#         (ema5 < st21DN and close < lowerBB) or  # Original condition
#         (st21Sell and ema5 < st21DN and close < resistance) or  # Added flexibility
#         (st21Sell and close <= lowerBB * 1.01)  # Allow 1% tolerance for lowerBB
#     )

#     # Initialize all exit signals to False
#     exit_buy_signal = False
#     exit_sell_signal = False
#     exit_best_buy_signal = False
#     exit_best_sell_signal = False
#     exit_strong_buy_signal = False
#     exit_strong_sell_signal = False

#     # # Exit Regular Buy Signal
#     # if buy_signal:
#     #     exit_buy_signal = st21Trend == -1 or (close < resistance and haRed)

#     # # Exit Regular Sell Signal
#     # if sell_signal:
#     #     exit_sell_signal = st21Trend == 1 or (close > support and haGreen)

#     # # Exit Best Buy Signal
#     # if best_buy_signal:
#     #     exit_best_buy_signal = ema5 < ema21 or st21Trend == 1

#     # # Exit Best Sell Signal
#     # if best_sell_signal:
#     #     exit_best_sell_signal = ema5 > ema21 or st21Trend == -1

#     # # Exit Strong Buy Signal
#     # if strong_buy_signal:
#     #     exit_strong_buy_signal = ema21 > close or st21Trend == -1

#     # # Exit Strong Sell Signal
#     # if strong_sell_signal:
#     #     exit_strong_sell_signal = ema21 < close or st21Trend == 1

#     # Return all signals
#     return {
#         'buy_signal': buy_signal,
#         'sell_signal': sell_signal,
#         'best_buy_signal': best_buy_signal,
#         'best_sell_signal': best_sell_signal,
#         'strong_buy_signal': strong_buy_signal,
#         'strong_sell_signal': strong_sell_signal
#         # 'exit_buy_signal': exit_buy_signal,
#         # 'exit_sell_signal': exit_sell_signal,
#         # 'exit_best_buy_signal': exit_best_buy_signal,
#         # 'exit_best_sell_signal': exit_best_sell_signal,
#         # 'exit_strong_buy_signal': exit_strong_buy_signal,
#         # 'exit_strong_sell_signal': exit_strong_sell_signal
#     }
