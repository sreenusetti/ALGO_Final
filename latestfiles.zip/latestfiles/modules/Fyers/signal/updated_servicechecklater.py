import pandas as pd
from fyers_apiv3 import fyersModel
import datetime as dt
import pytz
import numpy as np
import time

import json
import os

#generate trading session
client_id = open("client_id.txt",'r').read()
access_token = open("access_token.txt",'r').read()
# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")



def signal(ema_5, ema_21, st21Buy, st21Sell, st21Trend, close, upper_bb, lower_bb, st21UP, st21DN, support, resistance, prev_close, atr_value):
    """
    Generate comprehensive trading signals based on multiple technical indicators.
    
    Args:
        ema_5 (float): 5-period EMA value
        ema_21 (float): 21-period EMA value
        st21Buy (bool): Supertrend buy signal
        st21Sell (bool): Supertrend sell signal
        st21Trend (int): Supertrend trend direction (1: bullish, -1: bearish, 0: neutral)
        close (float): Current closing price
        upper_bb (float): Upper Bollinger Band
        lower_bb (float): Lower Bollinger Band
        st21UP (float): Supertrend upper band
        st21DN (float): Supertrend lower band
        support (float): Support level
        resistance (float): Resistance level
        prev_close (float): Previous closing price
        atr_value (float): Average True Range value
    
    Returns:
        dict: Dictionary containing various trading signals and conditions
    """
    try:
        # Initialize signals dictionary
        signals = {
            'buy': False,
            'sell': False,
            'best_buy': False,
            'best_sell': False,
            'strong_buy': False,
            'strong_sell': False,
            'buy_begins': False,
            'sell_begins': False
        }

        # Price action analysis
        price_change = close - prev_close
        price_change_percent = (price_change / prev_close) * 100
        momentum = abs(price_change_percent)
        
        # Trend analysis
        trend_strength = abs(ema_5 - ema_21) / atr_value
        strong_trend = trend_strength > 1.5
        weak_trend = trend_strength < 0.5
        
        # Volatility analysis
        volatility = atr_value / close * 100
        high_volatility = volatility > 2.0
        low_volatility = volatility < 0.5
        
        # Support/Resistance proximity
        near_support = abs(close - support) <= atr_value
        near_resistance = abs(close - resistance) <= atr_value
        
        # Bollinger Bands analysis
        bb_width = (upper_bb - lower_bb) / close * 100
        bb_squeeze = bb_width < 1.0
        bb_expansion = bb_width > 3.0
        
        # EMA analysis
        ema_bullish = ema_5 > ema_21
        ema_bearish = ema_5 < ema_21
        price_above_emas = close > ema_5 > ema_21
        price_below_emas = close < ema_5 < ema_21

        # Buy Begins Signal
        if (st21Buy and 
            ema_bullish and 
            st21Trend == 1 and 
            close > st21UP and 
            close > prev_close and 
            (close - st21UP) > 0.3 * atr_value and
            not near_resistance and
            not high_volatility):
            signals['buy_begins'] = True
        
        # Sell Begins Signal
        if (st21Sell and 
            ema_bearish and 
            st21Trend == -1 and 
            close < st21DN and 
            close < prev_close and 
            (st21DN - close) > 0.3 * atr_value and
            not near_support and
            not high_volatility):
            signals['sell_begins'] = True
        
        # Basic Buy Signal Conditions
        if (st21Buy and 
            price_above_emas and 
            close > st21UP and 
            not near_resistance and 
            not high_volatility):
            signals['buy'] = True
            
            # Strong Buy Signal
            if (near_support and 
                momentum > 0.5 and 
                not bb_squeeze):
                signals['strong_buy'] = True
                
                # Best Buy Signal
                if (strong_trend and 
                    price_change > 0 and 
                    not bb_expansion and 
                    low_volatility):
                    signals['best_buy'] = True
        
        # Basic Sell Signal Conditions
        if (st21Sell and 
            price_below_emas and 
            close < st21DN and 
            not near_support and 
            not high_volatility):
            signals['sell'] = True
            
            # Strong Sell Signal
            if (near_resistance and 
                momentum > 0.5 and 
                not bb_squeeze):
                signals['strong_sell'] = True
                
                # Best Sell Signal
                if (strong_trend and 
                    price_change < 0 and 
                    not bb_expansion and 
                    low_volatility):
                    signals['best_sell'] = True
        
        # Additional market analysis
        market_analysis = {
            'trend': {
                'strength': trend_strength,
                'strong': strong_trend,
                'weak': weak_trend,
                'direction': 'bullish' if ema_bullish else 'bearish' if ema_bearish else 'neutral'
            },
            'volatility': {
                'value': volatility,
                'high': high_volatility,
                'low': low_volatility,
                'bb_squeeze': bb_squeeze,
                'bb_expansion': bb_expansion
            },
            'price_action': {
                'momentum': momentum,
                'change_percent': price_change_percent,
                'above_emas': price_above_emas,
                'below_emas': price_below_emas
            },
            'levels': {
                'near_support': near_support,
                'near_resistance': near_resistance,
                'support': support,
                'resistance': resistance
            }
        }
        
        # Combine signals with market analysis
        return {
            **signals,
            'market_analysis': market_analysis,
            'supertrend': {
                'trend': st21Trend,
                'buy_signal': st21Buy,
                'sell_signal': st21Sell,
                'upper_band': st21UP,
                'lower_band': st21DN
            }
        }

    except Exception as e:
        print(f"Error generating signals: {str(e)}")
        return {
            'buy': False,
            'sell': False,
            'best_buy': False,
            'best_sell': False,
            'strong_buy': False,
            'strong_sell': False,
            'buy_begins': False,
            'sell_begins': False,
            'error': str(e)
        }

def _validate_inputs(ema5, ema21, st21Buy, st21Sell, st21Trend, close, 
                   upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value):
    """Validates all input parameters"""
    numeric_inputs = [ema5, ema21, close, upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value]
    
    return (
        all(x is not None for x in numeric_inputs) and
        all(isinstance(x, (int, float)) for x in numeric_inputs) and
        isinstance(st21Buy, bool) and
        isinstance(st21Sell, bool) and
        st21Trend in [-1, 0, 1] and
        upperBB > lowerBB and
        support < resistance and
        atr_value > 0
    )

def _calculate_metrics(close, prev_close, ema5, ema21, atr_value, upperBB, lowerBB):
    """Calculates key trading metrics"""
    return {
        'price_change': abs(close - prev_close),
        'price_volatility': abs(close - prev_close) / atr_value,
        'ema_spread': abs(ema5 - ema21) / atr_value,
        'bb_width': (upperBB - lowerBB) / close
    }

def _analyze_trends(st21Trend, ema5, ema21, close, metrics):
    """Analyzes market trends"""
    return {
        "ema_aligned": (ema5 > ema21) if st21Trend == 1 else (ema5 < ema21) if st21Trend == -1 else False,
        "price_momentum": metrics['price_change'] > (metrics['price_volatility'] * 0.3),
        "controlled_volatility": 0.2 <= metrics['price_volatility'] <= 2.0,
        "healthy_spread": 0.2 <= metrics['ema_spread'] <= 2.0,
        "reasonable_bb_width": 0.002 <= metrics['bb_width'] <= 0.05
    }

def _check_safety_conditions(close, ema21, upperBB, lowerBB, st21DN, st21UP, atr_value):
    """Checks safety conditions for trading"""
    return {
        "price_not_extended": abs(close - ema21) < (atr_value * 2),
        "not_overbought": close < (upperBB * 1.01),
        "not_oversold": close > (lowerBB * 0.99),
        "trend_confirmed": (close > st21DN) or (close < st21UP)
    }

def _create_response(signal, reason, trend_analysis=None, safety_conditions=None):
    """Creates standardized response dictionary"""
    response = {
        "trade_signal": signal,
        "reason": reason
    }
    
    if trend_analysis is not None and safety_conditions is not None:
        response["analysis"] = {
            "trend": trend_analysis,
            "safety": safety_conditions
        }
        
    return response

def calculate_begins_signals(close, prev_close, ema5, ema21, st21Trend, st21UP, st21DN, 
                           upperBB, lowerBB, support, resistance, atr_value):
    """Calculates buy/sell begin signals"""
    
    # Calculate thresholds
    price_change = abs(close - prev_close)
    bb_width = upperBB - lowerBB
    
    # Define conditions
    conditions = {
        'significant_move': price_change > (atr_value * 0.3),
        'strong_uptrend': (ema5 > ema21) and (close > ema5) and (st21Trend == 1),
        'strong_downtrend': (ema5 < ema21) and (close < ema5) and (st21Trend == -1),
        'near_support': abs(close - support) < (support * 0.01),
        'near_resistance': abs(close - resistance) < (resistance * 0.01),
        'normal_volatility': bb_width > (close * 0.002)
    }
    
    # Determine signals
    buy_begins = (
        close > prev_close and
        conditions['significant_move'] and
        (conditions['strong_uptrend'] or conditions['near_support']) and
        close > st21UP and
        conditions['normal_volatility'] and
        close > lowerBB * 1.01
    )
    
    sell_begins = (
        close < prev_close and
        conditions['significant_move'] and
        (conditions['strong_downtrend'] or conditions['near_resistance']) and
        close < st21DN and
        conditions['normal_volatility'] and
        close < upperBB * 0.99
    )
    
    return {'buy_begins': buy_begins, 'sell_begins': sell_begins}


# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, close,
#     upperBB, lowerBB, st21UP, st21DN, support, resistance, prev_close, atr_value
# ):
#     """
#     Final refined signal function for generating trading signals with robust conditions.
#     """

#     # Initialize signals
#     signals = {
#         'buy_signal': False,
#         'sell_signal': False,
#         'best_buy_signal': False,
#         'best_sell_signal': False,
#         'strong_buy_signal': False,
#         'strong_sell_signal': False,
#         'buy_begins': False,
#         'sell_begins': False
#     }

#     # Thresholds
#     upper_bb_tolerance = 1.03  # Tolerance for proximity to upper Bollinger Band
#     lower_bb_tolerance = 0.97  # Tolerance for proximity to lower Bollinger Band
#     atr_threshold = 0.5  # Proportion of ATR for significant price movement

#     # 1. Basic Buy/Sell Signals
#     if st21Buy and st21Trend == 1:
#         signals['buy_signal'] = True
#     if st21Sell and st21Trend == -1:
#         signals['sell_signal'] = True

#     # 2. Best Buy/Sell Signals (EMA alignment with trend and support/resistance)
#     if ema5 > ema21 and st21Trend == 1 and close > support:
#         signals['best_buy_signal'] = True
#     if ema5 < ema21 and st21Trend == -1 and close < resistance:
#         signals['best_sell_signal'] = True

#     # 3. Strong Buy/Sell Signals (Price action around Bollinger Bands and SuperTrend)
#     if (
#         (ema5 > st21UP and close > upperBB) or
#         (st21Buy and close >= upperBB * 0.99) or
#         (ema5 > ema21 and close > st21UP and close > upperBB * 0.97)
#     ):
#         signals['strong_buy_signal'] = True
#     if (
#         (ema5 < st21DN and close < lowerBB) or
#         (st21Sell and close <= lowerBB * 1.01) or
#         (ema5 < ema21 and close < st21DN and close < lowerBB * 1.03)
#     ):
#         signals['strong_sell_signal'] = True

#     # 4. Refined Buy Begins Signal
#     if (
#         signals['buy_signal'] and 
#         ema5 > ema21 and  # Confirm bullish EMA crossover
#         st21Trend == 1 and  # Confirm uptrend
#         close > st21UP and  # Price above SuperTrend UP
#         close > prev_close  # Positive momentum (close > previous close)
#     ):
#         # Relaxed condition for ATR-based price movement
#         if (close - st21UP) > atr_threshold * atr_value:
#             signals['buy_begins'] = True
#         elif close > st21UP and close > prev_close:  # Fallback condition
#             signals['buy_begins'] = True

#     # 5. Refined Sell Begins Signal
#     if (
#         signals['sell_signal'] and 
#         ema5 < ema21 and  # Confirm bearish EMA crossover
#         st21Trend == -1 and  # Confirm downtrend
#         close < st21DN and  # Price below SuperTrend DN
#         close < prev_close  # Negative momentum (close < previous close)
#     ):
#         # Relaxed condition for ATR-based price movement
#         if (st21DN - close) > atr_threshold * atr_value:
#             signals['sell_begins'] = True
#         elif close < st21DN and close < prev_close:  # Fallback condition
#             signals['sell_begins'] = True

#     return signals





# #old function as below
# def signal(ema_5, ema_21, st21Buy, st21Sell, st21Trend, close, upper_bb, lower_bb, st21UP, st21DN, support, resistance, atr_value):
#     """
#     Calculate trading signals based on various indicators.
#     """
#     signals = {
#         "buy_signal": False,
#         "sell_signal": False,
#         "buy_begins": False,
#         "sell_begins": False,
#         "best_buy_signal": False,
#         "best_sell_signal": False,
#         "strong_buy_signal": False,
#         "strong_sell_signal": False,
#         "confirmed_buy": False,
#         "confirmed_sell": False,
#         "exit_buy": False,
#         "exit_sell": False
#     }

#     # Buy signal logic when st21Buy is True
#     if st21Buy:
#         if close > ema_5 and close < upper_bb:
#             signals["buy_signal"] = True
    
#     # Sell signal logic when st21Sell is True
#     if st21Sell:
#         if close < ema_5 and close > lower_bb:
#             signals["sell_signal"] = True

#     # Best signal logic based on trend strength
#     if st21Buy and close < upper_bb:
#         signals["best_buy_signal"] = True
#     if st21Sell and close > lower_bb:
#         signals["best_sell_signal"] = True

#     # Strong buy/sell signals based on supertrend levels
#     if st21Buy and close > st21UP:
#         signals["strong_buy_signal"] = True
#     if st21Sell and close < st21DN:
#         signals["strong_sell_signal"] = True

#     # Confirmed buy/sell based on resistance/support
#     if signals["strong_buy_signal"] and close < resistance:
#         signals["confirmed_buy"] = True
#     if signals["strong_sell_signal"] and close > support:
#         signals["confirmed_sell"] = True

#     # Exit conditions (based on mutual exclusivity)
#     if signals["confirmed_buy"] and close < ema_5:
#         signals["exit_buy"] = True
#         signals["exit_sell"] = False  # Ensure mutual exclusivity
#     elif signals["confirmed_sell"] and close > ema_5:
#         signals["exit_sell"] = True
#         signals["exit_buy"] = False  # Ensure mutual exclusivity
#     else:
#         signals["exit_buy"] = False
#         signals["exit_sell"] = False

#     return signals
