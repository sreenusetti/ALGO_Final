import pandas as pd
from fyers_apiv3 import fyersModel
import datetime as dt
import pytz
import numpy as np
import time

import json
import os

#generate trading session
client_id = open("client_id.txt",'r').read()
access_token = open("access_token.txt",'r').read()
# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")
symbol = "MCX:NATGASMINI25FEBFUT"
symbol_clean = symbol.replace(":", "_").replace("-", "_")
indicator_json_path = f'indicator_values_{symbol_clean}.json'
updated_json_path = f'updated_indicator_values_{symbol_clean}.json'
output_terminal_path = f'output_terminal_{symbol_clean}.txt'

def log_message(message):
    """Logs a message to the console and the terminal output file."""
    timestamp = dt.datetime.now()
    print(f"{timestamp} - {message}")
    with open(output_terminal_path, 'a') as file:
        file.write(f"{timestamp} - {message}\n")

def signal(
    ema5, ema21, st21Buy, st21Sell, st21Trend, close,
    upperBB, lowerBB, st21UP, st21DN, support, resistance,
    prev_close, atr_value
):
    """
    Optimized Trading Signal Function without previous_trend.
    """

    # Initialize signals
    signals = {
        'buy_signal': False,
        'sell_signal': False,
        'best_buy_signal': False,
        'best_sell_signal': False,
        'strong_buy_signal': False,
        'strong_sell_signal': False,
        'buy_begins': False,
        'sell_begins': False,
        'stop_loss': None,
        'take_profit': None
    }

    # ATR Multipliers
    atr_sl_multiplier = 1.5
    atr_tp_multiplier = 2.5  

    # Debugging Log
    log_message(f"EMA5: {ema5}, EMA21: {ema21}, Close: {close}, st21UP: {st21UP}, ATR: {atr_value}")

    # **Basic Buy/Sell Signals**
    if st21Buy and st21Trend == 1:
        signals['buy_signal'] = True
    if st21Sell and st21Trend == -1:
        signals['sell_signal'] = True

    # **Best Buy/Sell Signal: EMA & Trend Confirmation**
    if ema5 > ema21 and st21Trend == 1 and close > support:
        signals['best_buy_signal'] = True
    if ema5 < ema21 and st21Trend == -1 and close < resistance:
        signals['best_sell_signal'] = True

    # **Strong Buy/Sell: Bollinger Band & SuperTrend Confirmation**
    if ema5 > st21UP * 0.98 and close > upperBB * 0.97:
        signals['strong_buy_signal'] = True
    if ema5 < st21DN * 1.02 and close < lowerBB * 1.03:
        signals['strong_sell_signal'] = True

    # **Buy Begins: More Flexible Momentum Condition**
    if (
        signals['buy_signal'] and 
        ema5 > ema21 and 
        st21Trend == 1 and 
        (close > prev_close if prev_close else True) and  
        (abs(close - st21UP) < (0.2 * atr_value))  # Increased buffer from 0.1 to 0.2
    ):
        signals['buy_begins'] = True
        signals['stop_loss'] = close - (atr_sl_multiplier * atr_value)
        signals['take_profit'] = close + (atr_tp_multiplier * atr_value)

    # **Additional Check to Avoid Invalid Trade Setup**
    if not (signals['buy_signal'] or signals['best_buy_signal'] or signals['strong_buy_signal']):
        log_message(f"No valid buy setup for MCX:NATGASMINI25FEBFUT: {close}")
        signals['buy_begins'] = False

    # Debugging Log
    log_message(f"Buy Begins: {signals['buy_begins']}, Sell Begins: {signals['sell_begins']}")

    return signals

# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, close,
#     upperBB, lowerBB, st21UP, st21DN, support, resistance,
#     prev_close, atr_value
# ):
#     """
#     Optimized Trading Signal Function.
#     """

#     # Initialize signals
#     signals = {
#         'buy_signal': False,
#         'sell_signal': False,
#         'best_buy_signal': False,
#         'best_sell_signal': False,
#         'strong_buy_signal': False,
#         'strong_sell_signal': False,
#         'buy_begins': False,
#         'sell_begins': False,
#         'stop_loss': None,
#         'take_profit': None
#     }

#     # ATR Multipliers
#     atr_sl_multiplier = 1.5
#     atr_tp_multiplier = 2.5  

#     # Debugging Log
#     log_message(f"st21Buy: {st21Buy}, st21Trend: {st21Trend}, Close: {close}, st21UP: {st21UP}")

#     # **Basic Buy/Sell Signals**
#     if st21Buy and st21Trend == 1:
#         signals['buy_signal'] = True
#     if st21Sell and st21Trend == -1:
#         signals['sell_signal'] = True

#     # **Best Buy/Sell Signal: EMA & Trend Confirmation**
#     if ema5 > ema21 and st21Trend == 1 and close > support:
#         signals['best_buy_signal'] = True
#     if ema5 < ema21 and st21Trend == -1 and close < resistance:
#         signals['best_sell_signal'] = True

#     # **Strong Buy/Sell: Bollinger Band & SuperTrend Confirmation**
#     if ema5 > st21UP * 0.98 and close > upperBB * 0.97:
#         signals['strong_buy_signal'] = True
#     if ema5 < st21DN * 1.02 and close < lowerBB * 1.03:
#         signals['strong_sell_signal'] = True

#     # **Buy Begins: More Flexible Momentum Condition**
#     if (
#         signals['buy_signal'] and 
#         ema5 > ema21 and 
#         st21Trend == 1 and 
#         (close > prev_close if prev_close else True) and  # Check prev_close if available
#         (abs(close - st21UP) < (0.1 * atr_value))  # Allow close to be slightly below st21UP
#     ):
#         signals['buy_begins'] = True
#         signals['stop_loss'] = close - (atr_sl_multiplier * atr_value)
#         signals['take_profit'] = close + (atr_tp_multiplier * atr_value)

#     # **Sell Begins: More Flexible Condition**
#     if (
#         signals['sell_signal'] and 
#         ema5 < ema21 and 
#         st21Trend == -1 and 
#         (close < prev_close if prev_close else True) and
#         (abs(st21DN - close) < (0.1 * atr_value))
#     ):
#         signals['sell_begins'] = True
#         signals['stop_loss'] = close + (atr_sl_multiplier * atr_value)
#         signals['take_profit'] = close - (atr_tp_multiplier * atr_value)

#     # Debugging Log
#     log_message(f"Buy Begins: {signals['buy_begins']}, Sell Begins: {signals['sell_begins']}")

#     return signals


# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, close,
#     upperBB, lowerBB, st21UP, st21DN, support, resistance,
#     prev_close, atr_value
# ):
#     """
#     Improved Trading Signal Function with ATR-based Exits and Risk Management.
#     """

#     # Initialize signals
#     signals = {
#         'buy_signal': False,
#         'sell_signal': False,
#         'best_buy_signal': False,
#         'best_sell_signal': False,
#         'strong_buy_signal': False,
#         'strong_sell_signal': False,
#         'buy_begins': False,
#         'sell_begins': False,
#         'stop_loss': None,
#         'take_profit': None
#     }

#     # ATR Stop-Loss & Take-Profit Multipliers
#     atr_sl_multiplier = 1.5
#     atr_tp_multiplier = 2.5  

#     # Log values for debugging
#     log_message(f"st21Buy: {st21Buy}, st21Trend: {st21Trend}")

#     # 1. **Basic Buy/Sell Signals**
#     if st21Buy and st21Trend == 1:
#         signals['buy_signal'] = True
#     if st21Sell and st21Trend == -1:
#         signals['sell_signal'] = True

#     # 2. **Best Buy/Sell Signal: EMA & Trend Confirmation**
#     if ema5 > ema21 and st21Trend == 1 and close > support:
#         signals['best_buy_signal'] = True
#     if ema5 < ema21 and st21Trend == -1 and close < resistance:
#         signals['best_sell_signal'] = True

#     # 3. **Strong Buy/Sell: Bollinger Band & SuperTrend Confirmation**
#     if ema5 > st21UP and close > upperBB * 0.97:
#         signals['strong_buy_signal'] = True
#     if ema5 < st21DN and close < lowerBB * 1.03:
#         signals['strong_sell_signal'] = True

#     # 4. **Buy Begins: Momentum Confirmation**
#     if (
#         signals['buy_signal'] and 
#         ema5 > ema21 and 
#         st21Trend == 1 and 
#         close > st21UP * 0.98 and  # Allow small buffer below st21UP
#         close > prev_close and 
#         (close - st21UP) > (0.2 * atr_value)  # Reduced from 0.5 to 0.2 ATR
#     ):
#         signals['buy_begins'] = True
#         signals['stop_loss'] = close - (atr_sl_multiplier * atr_value)
#         signals['take_profit'] = close + (atr_tp_multiplier * atr_value)

#     # 5. **Sell Begins: Momentum Confirmation**
#     if (
#         signals['sell_signal'] and 
#         ema5 < ema21 and 
#         st21Trend == -1 and 
#         close < st21DN * 1.02 and  # Allow small buffer above st21DN
#         close < prev_close and 
#         (st21DN - close) > (0.2 * atr_value)  # Reduced from 0.5 to 0.2 ATR
#     ):
#         signals['sell_begins'] = True
#         signals['stop_loss'] = close + (atr_sl_multiplier * atr_value)
#         signals['take_profit'] = close - (atr_tp_multiplier * atr_value)

#     # Debugging Log
#     # log_message(f"Buy Begins: {signals['buy_begins']}, Sell Begins: {signals['sell_begins']}")

#     return signals




# def signal(
#     ema5, ema21, st21Buy, st21Sell, st21Trend, close,
#     upperBB, lowerBB, st21UP, st21DN, support, resistance,
#     prev_close, atr_value
# ):
#     """
#     Improved Trading Signal Function with ATR-based Exits and Risk Management.
#     """

#     # Initialize signals
#     signals = {
#         'buy_signal': False,
#         'sell_signal': False,
#         'best_buy_signal': False,
#         'best_sell_signal': False,
#         'strong_buy_signal': False,
#         'strong_sell_signal': False,
#         'buy_begins': False,
#         'sell_begins': False,
#         'stop_loss': None,
#         'take_profit': None
#     }

#     # ATR Stop-Loss Multiplier
#     atr_sl_multiplier = 1.5
#     atr_tp_multiplier = 2.5  # Take profit at 2.5x ATR

#     # 1. **Basic Buy/Sell Signals**
#     if st21Buy and st21Trend == 1:
#         signals['buy_signal'] = True
#     if st21Sell and st21Trend == -1:
#         signals['sell_signal'] = True

#     # 2. **Best Buy/Sell Signal: EMA & Trend Confirmation**
#     if ema5 > ema21 and st21Trend == 1 and close > support:
#         signals['best_buy_signal'] = True
#     if ema5 < ema21 and st21Trend == -1 and close < resistance:
#         signals['best_sell_signal'] = True

#     # 3. **Strong Buy/Sell: Bollinger Band & SuperTrend Confirmation**
#     if ema5 > st21UP and close > upperBB * 0.97:
#         signals['strong_buy_signal'] = True
#     if ema5 < st21DN and close < lowerBB * 1.03:
#         signals['strong_sell_signal'] = True

#     # 4. **Buy Begins: Momentum Confirmation**
#     if (
#         signals['buy_signal'] and 
#         ema5 > ema21 and 
#         st21Trend == 1 and 
#         close > st21UP and 
#         close > prev_close and 
#         (close - st21UP) > (0.5 * atr_value)
#     ):
#         signals['buy_begins'] = True
#         signals['stop_loss'] = close - (atr_sl_multiplier * atr_value)
#         signals['take_profit'] = close + (atr_tp_multiplier * atr_value)

#     # 5. **Sell Begins: Momentum Confirmation**
#     if (
#         signals['sell_signal'] and 
#         ema5 < ema21 and 
#         st21Trend == -1 and 
#         close < st21DN and 
#         close < prev_close and 
#         (st21DN - close) > (0.5 * atr_value)
#     ):
#         signals['sell_begins'] = True
#         signals['stop_loss'] = close + (atr_sl_multiplier * atr_value)
#         signals['take_profit'] = close - (atr_tp_multiplier * atr_value)

#     return signals
