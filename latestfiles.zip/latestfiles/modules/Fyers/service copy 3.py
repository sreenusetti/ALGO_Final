import pandas as pd
from fyers_apiv3 import fyersModel
import datetime as dt
import pytz
import numpy as np
import time

import json
import os

from scipy.signal import argrelextrema
import numpy as np


#generate trading session
client_id = open("client_id.txt",'r').read()
access_token = open("access_token.txt",'r').read()
# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")



def save_to_json(data, filename):
    # Custom handler for non-serializable objects
    def default_serializer(o):
        if isinstance(o, np.bool_):  # Convert numpy bool to Python bool
            return bool(o)
        elif isinstance(o, bool):
            return o  # Python bools are serializable by default
        raise TypeError(f"Type {type(o)} not serializable")

    with open(filename, 'w') as f:
        json.dump(data, f, indent=4, default=default_serializer)


def load_from_json(filename='indicator_values.json'):
    if os.path.exists(filename):
        with open(filename, 'r') as f:
            return json.load(f)
    return {}



def fetchOHLC2(ticker, interval, duration):
    range_from = dt.date.today() - dt.timedelta(duration)
    range_to = dt.date.today()

    from_date_string = range_from.strftime("%Y-%m-%d")
    to_date_string = range_to.strftime("%Y-%m-%d")
    data = {
        "symbol": ticker,
        "resolution": interval,
        "date_format": "1",
        "range_from": from_date_string,
        "range_to": to_date_string,
        "cont_flag": "1"
    }

    response = fyers.history(data=data)['candles']

    # Create a DataFrame
    columns = ['Timestamp', 'Open', 'High', 'Low', 'Close', 'Volume']
    df = pd.DataFrame(response, columns=columns)

    # Convert Timestamp to datetime in UTC
    df['Timestamp2'] = pd.to_datetime(df['Timestamp'], unit='s').dt.tz_localize(pytz.utc)

    # Convert Timestamp to IST
    ist = pytz.timezone('Asia/Kolkata')
    df['Timestamp2'] = df['Timestamp2'].dt.tz_convert(ist)
    df.drop(columns=['Timestamp'], inplace=True)

    return df


def bollinger_bands(df, window=20, width=2):
    """Calculate Bollinger Bands."""
    rolling_mean = df['Close'].rolling(window=window).mean()
    rolling_std = df['Close'].rolling(window=window).std()
    df['BB_upper'] = rolling_mean + (rolling_std * width)
    df['BB_lower'] = rolling_mean - (rolling_std * width)
    return df


def ema(df, window=21):
    df[f"EMA{window}"] = df['Close'].ewm(span=window, adjust=False).mean()
    return df


def atr(DF, n):
    df = DF.copy()
    df['High-Low'] = abs(df['High'] - df['Low'])
    df['High-PrevClose'] = abs(df['High'] - df['Close'].shift(1))
    df['Low-PrevClose'] = abs(df['Low'] - df['Close'].shift(1))
    df['TR'] = df[['High-Low', 'High-PrevClose', 'Low-PrevClose']].max(axis=1, skipna=False)
    df['ATR'] = df['TR'].ewm(com=n, min_periods=n).mean()
    return df['ATR']


def supertrend(DF, period=21, multiplier=1):
   # global supertrend_up, supertrend_down, supertrend

    df = DF.copy()
    df['ATR'] = atr(df, period)
    df["BasicUpper"] = ((df['High'] + df['Low']) / 2) + multiplier * df['ATR']
    df["BasicLower"] = ((df['High'] + df['Low']) / 2) - multiplier * df['ATR']
    df["FinalUpper"] = df["BasicUpper"]
    df["FinalLower"] = df["BasicLower"]

    ind = df.index
    for i in range(period, len(df)):
        if df['Close'][i - 1] <= df['FinalUpper'][i - 1]:
            df.loc[ind[i], 'FinalUpper'] = min(df['BasicUpper'][i], df['FinalUpper'][i - 1])
        else:
            df.loc[ind[i], 'FinalUpper'] = df['BasicUpper'][i]

    for i in range(period, len(df)):
        if df['Close'][i - 1] >= df['FinalLower'][i - 1]:
            df.loc[ind[i], 'FinalLower'] = max(df['BasicLower'][i], df['FinalLower'][i - 1])
        else:
            df.loc[ind[i], 'FinalLower'] = df['BasicLower'][i]

    df['Strend'] = np.nan
    for test in range(period, len(df)):
        if df['Close'][test - 1] <= df['FinalUpper'][test - 1] and df['Close'][test] > df['FinalUpper'][test]:
            df.loc[ind[test], 'Strend'] = df['FinalLower'][test]
            break
        if df['Close'][test - 1] >= df['FinalLower'][test - 1] and df['Close'][test] < df['FinalLower'][test]:
            df.loc[ind[test], 'Strend'] = df['FinalUpper'][test]
            break

    for i in range(test + 1, len(df)):
        if df['Strend'][i - 1] == df['FinalUpper'][i - 1] and df['Close'][i] <= df['FinalUpper'][i]:
            df.loc[ind[i], 'Strend'] = df['FinalUpper'][i]
        elif df['Strend'][i - 1] == df['FinalUpper'][i - 1] and df['Close'][i] >= df['FinalUpper'][i]:
            df.loc[ind[i], 'Strend'] = df['FinalLower'][i]
        elif df['Strend'][i - 1] == df['FinalLower'][i - 1] and df['Close'][i] >= df['FinalLower'][i]:
            df.loc[ind[i], 'Strend'] = df['FinalLower'][i]
        elif df['Strend'][i - 1] == df['FinalLower'][i - 1] and df['Close'][i] <= df['FinalLower'][i]:
            df.loc[ind[i], 'Strend'] = df['FinalUpper'][i]

    #supertrend_up = df['FinalUpper'].iloc[-1]
    #supertrend_down = df['FinalLower'].iloc[-1]
    #supertrend = df['Strend'].iloc[-1]
    supertrend_data = df['Strend']
    supertrend_data = supertrend_data.fillna(0)


    return supertrend_data



# def calculate_atr(df, n=14):
#     """
#     Calculate the Average True Range (ATR) over a specified period.
#     """
#     df['High-Low'] = abs(df['High'] - df['Low'])
#     df['High-PrevClose'] = abs(df['High'] - df['Close'].shift(1))
#     df['Low-PrevClose'] = abs(df['Low'] - df['Close'].shift(1))
#     df['TR'] = df[['High-Low', 'High-PrevClose', 'Low-PrevClose']].max(axis=1)
#     df['ATR'] = df['TR'].rolling(window=n).mean()
#     return df['ATR']

def calculate_support_resistance(df, period=20):
    """
    Calculate support and resistance levels based on the lowest low and highest high over a specified period.
    """
    df['Support'] = df['Low'].rolling(window=period).min()
    df['Resistance'] = df['High'].rolling(window=period).max()
    return df

# def apply_trading_logic(df, atr_multiple=1.5):
#     """
#     Apply trading logic using ATR with support and resistance levels.
#     """
#     df['Signal'] = None
#     df['Stop_Loss'] = None
#     df['Position_Size'] = None

#     for i in range(1, len(df)):
#         if df['Close'].iloc[i] > df['Resistance'].iloc[i-1] and df['ATR'].iloc[i] > df['ATR'].mean():
#             df.loc[i, 'Signal'] = 'Buy'
#             df.loc[i, 'Stop_Loss'] = df.loc[i-1, 'Resistance'] - atr_multiple * df.loc[i, 'ATR']
#             df.loc[i, 'Position_Size'] = 1 / df.loc[i, 'ATR']
#         elif df['Close'].iloc[i] < df['Support'].iloc[i-1] and df['ATR'].iloc[i] < df['ATR'].mean():
#             df.loc[i, 'Signal'] = 'Sell'
#             df.loc[i, 'Stop_Loss'] = df.loc[i-1, 'Support'] + atr_multiple * df.loc[i, 'ATR']
#             df.loc[i, 'Position_Size'] = 1 / df.loc[i, 'ATR']

#     return df


# def calculate_pivot_support_resistance(df):
#     """
#     Calculate support and resistance levels based on daily pivot points.
#     """
#     # Pivot Point (PP), Support (S1, S2) and Resistance (R1, R2)
#     df['PP'] = (df['High'] + df['Low'] + df['Close']) / 3
#     df['R1'] = (2 * df['PP']) - df['Low']
#     df['S1'] = (2 * df['PP']) - df['High']
#     df['R2'] = df['PP'] + (df['High'] - df['Low'])
#     df['S2'] = df['PP'] - (df['High'] - df['Low'])
#     return df


# def calculate_atr_support_resistance(df, period=14):
#     """
#     Calculate dynamic support and resistance using ATR.
#     """
#     # Calculate ATR (Average True Range)
#     df['HL'] = df['High'] - df['Low']
#     df['HC'] = abs(df['High'] - df['Close'].shift(1))
#     df['LC'] = abs(df['Low'] - df['Close'].shift(1))
#     df['TR'] = df[['HL', 'HC', 'LC']].max(axis=1)
#     df['ATR'] = df['TR'].rolling(window=period).mean()

#     # Calculate dynamic support and resistance
#     df['Resistance'] = df['Close'] + (2 * df['ATR'])
#     df['Support'] = df['Close'] - (2 * df['ATR'])
#     df.drop(['HL', 'HC', 'LC', 'TR'], axis=1, inplace=True)
#     return df



# def calculate_peak_trough_support_resistance(df, order=5):
#     """
#     Calculate support and resistance levels using local peaks and troughs.
#     """
#     # Find local maxima (resistance) and minima (support)
#     df['Resistance'] = df['High'][argrelextrema(df['High'].values, np.greater_equal, order=order)[0]]
#     df['Support'] = df['Low'][argrelextrema(df['Low'].values, np.less_equal, order=order)[0]]

#     # Forward-fill NaNs to propagate levels until a new peak or trough appears
#     df['Resistance'].fillna(method='ffill', inplace=True)
#     df['Support'].fillna(method='ffill', inplace=True)
#     return df

 

# Method 1: Pivot Points
def calculate_pivot_support_resistance(df):
    df['PP'] = (df['High'] + df['Low'] + df['Close']) / 3
    df['R1'] = (2 * df['PP']) - df['Low']
    df['S1'] = (2 * df['PP']) - df['High']
    df['R2'] = df['PP'] + (df['High'] - df['Low'])
    df['S2'] = df['PP'] - (df['High'] - df['Low'])
    return df[['High', 'Low', 'Close', 'PP', 'R1', 'S1', 'R2', 'S2']]

# Method 2: ATR-Based Dynamic Support and Resistance
def calculate_atr_support_resistance(df, period=14):
    df['HL'] = df['High'] - df['Low']
    df['HC'] = abs(df['High'] - df['Close'].shift(1))
    df['LC'] = abs(df['Low'] - df['Close'].shift(1))
    df['TR'] = df[['HL', 'HC', 'LC']].max(axis=1)
    df['ATR'] = df['TR'].rolling(window=period).mean()
    df['Resistance'] = df['Close'] + (2 * df['ATR'])
    df['Support'] = df['Close'] - (2 * df['ATR'])
    df.drop(['HL', 'HC', 'LC', 'TR'], axis=1, inplace=True)
    return df[['High', 'Low', 'Close', 'ATR', 'Resistance', 'Support']]

# Method 3: Local Maxima and Minima
def calculate_peak_trough_support_resistance(df, order=5):
    df['Resistance'] = df['High'][argrelextrema(df['High'].values, np.greater_equal, order=order)[0]]
    df['Support'] = df['Low'][argrelextrema(df['Low'].values, np.less_equal, order=order)[0]]
    # For example:
    df['Resistance'] = df['Resistance'].ffill()  # Forward fills NaN values in 'Resistance'
    df['Support'] = df['Support'].ffill() 
    return df[['High', 'Low', 'Close', 'Resistance', 'Support']]
