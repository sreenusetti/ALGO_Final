import pandas as pd
import numpy as np

# ATR Calculation
def calculate_atr(df, n=14):
    df['High-Low'] = abs(df['High'] - df['Low'])
    df['High-PrevClose'] = abs(df['High'] - df['Close'].shift(1))
    df['Low-PrevClose'] = abs(df['Low'] - df['Close'].shift(1))
    df['TR'] = df[['High-Low', 'High-PrevClose', 'Low-PrevClose']].max(axis=1)
    df['ATR'] = df['TR'].rolling(window=n).mean()
    return df['ATR']

# Support and Resistance Calculation
def calculate_support_resistance(df, period=20):
    df['Support'] = df['Low'].rolling(window=period).min()
    df['Resistance'] = df['High'].rolling(window=period).max()
    return df

# Trading Logic with Breakout, Stop-Loss, and Position Sizing
def apply_trading_logic(df, atr_multiple=1.5):
    df['Signal'] = None
    df['Stop_Loss'] = np.nan
    df['Position_Size'] = np.nan

    for i in range(1, len(df)):
        if df['Close'].iloc[i] > df['Resistance'].iloc[i-1] and df['ATR'].iloc[i] > df['ATR'].mean():
            df['Signal'].iloc[i] = 'Buy'
            df['Stop_Loss'].iloc[i] = df['Resistance'].iloc[i-1] - atr_multiple * df['ATR'].iloc[i]
            df['Position_Size'].iloc[i] = 1 / df['ATR'].iloc[i]
        elif df['Close'].iloc[i] < df['Support'].iloc[i-1] and df['ATR'].iloc[i] < df['ATR'].mean():
            df['Signal'].iloc[i] = 'Sell'
            df['Stop_Loss'].iloc[i] = df['Support'].iloc[i-1] + atr_multiple * df['ATR'].iloc[i]
            df['Position_Size'].iloc[i] = 1 / df['ATR'].iloc[i]

    return df


# def main(df, atr_period=14, support_resistance_period=20, atr_multiple=1.5):
#     """
#     Main function to calculate ATR, support, resistance, breakout signals, stop-loss, and position sizing.
#     This function orchestrates all calculations and returns the final DataFrame with trading signals.
#     """
#     # Calculate ATR
#     df['ATR'] = calculate_atr(df, n=atr_period)

#     # Calculate Support and Resistance levels
#     df['Support'], df['Resistance'] = calculate_support_resistance(df, period=support_resistance_period)

#     # Apply trading logic to generate signals, stop-loss, and position size
#     df = apply_trading_logic(df, atr_multiple=atr_multiple)

#     return df
