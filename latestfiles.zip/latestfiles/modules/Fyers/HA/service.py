
import pandas as pd
import numpy as np

def calculate_heikin_ashi(df):
    """
    Calculate Heikin-Ashi candles from a given OHLC DataFrame.
    
    Parameters:
    df (pd.DataFrame): A DataFrame with columns ['Open', 'High', 'Low', 'Close']
    
    Returns:
    pd.DataFrame: A DataFrame with additional columns for Heikin-Ashi Open, High, Low, Close, and Trend (green/red).
    """
    
    # Initialize the Heikin-Ashi DataFrame
    ha_df = df.copy()

    # Calculate HA Close as the average of Open, High, Low, and Close
    ha_df['HA_Close'] = (df['Open'] + df['High'] + df['Low'] + df['Close']) / 4

    # Initialize HA Open with the first Open price
    ha_df['HA_Open'] = (df['Open'].shift(1) + df['Close'].shift(1)) / 2

    # Fix for the FutureWarning: Assign fillna result back to the column without inplace modification
    ha_df['HA_Open'] = ha_df['HA_Open'].fillna((df['Open'] + df['Close']) / 2)  # For the first row
    
    # Calculate HA High and HA Low
    ha_df['HA_High'] = ha_df[['High', 'HA_Open', 'HA_Close']].max(axis=1)
    ha_df['HA_Low'] = ha_df[['Low', 'HA_Open', 'HA_Close']].min(axis=1)
    
    # Determine the color of the Heikin-Ashi candle: 'green' if HA_Open < HA_Close, 'red' otherwise
    ha_df['ha_trend'] = np.where(ha_df['HA_Open'] < ha_df['HA_Close'], 'green', 'red')
    
    return ha_df[['HA_Open', 'HA_High', 'HA_Low', 'HA_Close', 'ha_trend']]


