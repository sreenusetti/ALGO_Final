import pandas as pd
from fyers_apiv3 import fyersModel
from modules.Fyers.service import save_to_json, load_from_json, fetchOHLC2, bollinger_bands, ema, atr, supertrend
from modules.Fyers.placeorder.service import placeOrder
from modules.Fyers.signal.service import signal
import datetime as dt
import pytz
import numpy as np
import time

import json
import os

#generate trading session
client_id = open("client_id.txt",'r').read()
access_token = open("access_token.txt",'r').read()
# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")


# Function to load existing order data (if any) from JSON
def load_order_data(json_filename):
    try:
        with open(json_filename, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return {}  # Return an empty dict if no data exists
    


#def save_indicator_data(order_data, json_filename):
#    with open(json_filename, 'w') as file:
 #       json.dump(order_data, file, indent=4)


# Save indicator data for tickers
def save_indicator_data(ohlc, ticker, json_filename):
    print(f"Saving indicator data for {ticker}")

    # Load existing indicator data
    indicator_data = load_order_data(json_filename)

    # Calculate indicators and signals
    close = ohlc['Close'].iloc[-1]
    ema_5 = ema(ohlc, window=5)['EMA5'].iloc[-1]  # Calculate EMA5
    ema_21 = ohlc['EMA21'].iloc[-1]  # Already calculated in OHLC
    upper_bb = ohlc['BB_upper'].iloc[-1]
    lower_bb = ohlc['BB_lower'].iloc[-1]
    st21Buy = ohlc['st1'].iloc[-1] < close
    st21Sell = ohlc['st1'].iloc[-1] > close
    st21Trend = 1 if st21Buy else -1  # Simplified trend logic

    # Call the signal function
    signals = signal(ema_5, ema_21, st21Buy, st21Sell, st21Trend, True, False, close, upper_bb, lower_bb, upper_bb, lower_bb, lower_bb, upper_bb)

    # Store the indicator data for the current ticker
    indicator_data[ticker] = {
        'close': close,
        'ema_5': ema_5,
        'ema_21': ema_21,
        'upper_bb': upper_bb,
        'lower_bb': lower_bb,
        'st21Buy': st21Buy,
        'st21Sell': st21Sell,
        'st21Trend': st21Trend,
        'signals': signals,
    }

    # Save the updated indicator data back to the JSON file
    save_to_json(indicator_data, json_filename)
    print(f"Indicator data saved to {json_filename}")