# fyers_ltp_fetcher.py

from fyers_apiv3.FyersWebsocket import data_ws
import threading
import time

client_id = open("client_id.txt", 'r').read().strip()
access_token = open("access_token.txt", 'r').read().strip()

ltp_data = {}
ltp_event_map = {}
socket_connected = threading.Event()

def onmessage(message):
    if 'symbol' in message and 'ltp' in message:
        sym = message['symbol']
        ltp_data[sym] = message['ltp']
        if sym in ltp_event_map:
            ltp_event_map[sym].set()

def onerror(message): print("[WebSocket Error]:", message)
def onclose(message): print("[WebSocket Closed]:", message)

def onopen():
    print("[WebSocket Connected]")
    socket_connected.set()

# WebSocket setup
fyers_socket = data_ws.FyersDataSocket(
    access_token=access_token,
    log_path="",
    litemode=False,
    write_to_file=False,
    reconnect=True,
    on_connect=onopen,
    on_close=onclose,
    on_error=onerror,
    on_message=onmessage,
)

# Start socket once
def start_socket():
    threading.Thread(target=fyers_socket.connect, daemon=True).start()
    socket_connected.wait(timeout=5)

start_socket()

# Safe LTP fetch function
def get_ltp(symbol, timeout=2):
    if symbol not in ltp_event_map:
        ltp_event_map[symbol] = threading.Event()

    fyers_socket.subscribe([symbol], data_type="SymbolUpdate")

    received = ltp_event_map[symbol].wait(timeout=timeout)

    if received and symbol in ltp_data:
        return ltp_data[symbol]
    else:
        print(f"[ERROR] LTP not received for {symbol} in {timeout} seconds.")
        return None



# # ltp_fetcher.py
# from fyers_apiv3.FyersWebsocket import data_ws
# import threading
# import time

# client_id = open("client_id.txt", 'r').read().strip()
# access_token = open("access_token.txt", 'r').read().strip()

# ltp_data = {}
# ltp_event_map = {}  # Map symbol to threading.Event()

# def get_ltp(symbol, timeout=2):
#     """
#     Get the LTP for a given symbol using Fyers WebSocket.
#     """
#     def onmessage(message):
#         if 'symbol' in message and 'ltp' in message:
#             sym = message['symbol']
#             ltp_data[sym] = message['ltp']
#             if sym in ltp_event_map:
#                 ltp_event_map[sym].set()

#     def onerror(message): print("WebSocket Error:", message)
#     def onclose(message): print("WebSocket Closed:", message)
#     def onopen():
#         fyers.subscribe([symbol], data_type="SymbolUpdate")
#         fyers.keep_running()

#     # Create threading event for the symbol
#     ltp_event_map[symbol] = threading.Event()

#     # WebSocket instance
#     fyers = data_ws.FyersDataSocket(
#         access_token=access_token,
#         log_path="",
#         litemode=False,
#         write_to_file=False,
#         reconnect=False,
#         on_connect=onopen,
#         on_close=onclose,
#         on_error=onerror,
#         on_message=onmessage
#     )

#     # Start WebSocket in a new thread
#     threading.Thread(target=fyers.connect, daemon=True).start()

#     # Wait for LTP or timeout
#     if ltp_event_map[symbol].wait(timeout):
#         return ltp_data.get(symbol)
#     else:
#         print(f"[ERROR] LTP not received for {symbol} in {timeout} seconds.")
#         return None




# from fyers_apiv3.FyersWebsocket import data_ws
# import threading

# client_id = open("client_id.txt", 'r').read()
# access_token = open("access_token.txt", 'r').read()

# # Global dictionary to store symbols and their respective LTPs
# ltp_data = {}
# ltp_flag = False  # Flag to control when to print the LTP

# # Event to synchronize the WebSocket message handling
# ltp_received_event = threading.Event()

# def get_ltp(symbol):
#     """
#     Function to connect to Fyers WebSocket and subscribe to the symbol dynamically.
#     This function waits for the LTP to be received and then returns it.
#     """
#     global ltp_flag  # Use the global flag to control when to print the LTP

#     def onmessage(message):
#         """
#         Callback function to handle incoming messages from the WebSocket.
#         """
#         try:
#             if 'symbol' in message and 'ltp' in message:
#                 symbol_received = message['symbol']
#                 ltp = message['ltp']
#                 if symbol_received == symbol:
#                     ltp_data[symbol_received] = ltp  # Store the LTP data
#                     if ltp_flag:  # Print only when flag is True
#                         print(f"Received LTP for {symbol_received}: {ltp}")
#                     ltp_received_event.set()  # Signal that LTP has been received
#         except Exception as e:
#             print(f"Exception occurred: {e}")

#     def onerror(message):
#         print("Error:", message)

#     def onclose(message):
#         print("Connection closed:", message)

#     def onopen():
#         """
#         Callback function to subscribe to symbols upon WebSocket connection.
#         """
#         data_type = "SymbolUpdate"
#         symbols = [symbol]
#         fyers.subscribe(symbols=symbols, data_type=data_type)
#         fyers.keep_running()  # Keep the socket running

#     # Create a FyersDataSocket instance with the provided parameters
#     fyers = data_ws.FyersDataSocket(
#         access_token=access_token,
#         log_path="",
#         litemode=False,
#         write_to_file=False,
#         reconnect=True,
#         on_connect=onopen,
#         on_close=onclose,
#         on_error=onerror,
#         on_message=onmessage
#     )

#     # Set the flag to True to allow printing of LTP when it's retrieved
#     ltp_flag = True

#     # Start the WebSocket connection
#     fyers.connect()

#     # Wait for LTP to be received (with a timeout of 10 seconds)
#     ltp_received_event.wait(timeout=1)

#     # If LTP is received within the timeout, return the value; otherwise, return None
#     ltp_flag = False  # Reset the flag after receiving the LTP
#     return ltp_data.get(symbol, None)


# #old
# # from fyers_apiv3.FyersWebsocket import data_ws
# # import time
# # import threading

# # client_id = open("client_id.txt", 'r').read()
# # access_token = open("access_token.txt", 'r').read()

# # # Global dictionary to store symbols and their respective LTPs
# # ltp_data = {}

# # # Event to synchronize the WebSocket message handling
# # ltp_received_event = threading.Event()

# # def get_ltp(symbol):
# #     """
# #     Function to connect to Fyers WebSocket and subscribe to the symbol dynamically.
# #     This function waits for the LTP to be received and then returns it.
# #     """
# #     def onmessage(message):
# #         """
# #         Callback function to handle incoming messages from the WebSocket.
# #         """
# #         try:
# #             if 'symbol' in message and 'ltp' in message:
# #                 symbol_received = message['symbol']
# #                 ltp = message['ltp']
# #                 if symbol_received == symbol:
# #                     ltp_data[symbol_received] = ltp  # Store the LTP data
# #                     print(f"Received LTP for {symbol_received}: {ltp}")
# #                     ltp_received_event.set()  # Signal that LTP has been received
# #         except Exception as e:
# #             print(f"Exception occurred: {e}")

# #     def onerror(message):
# #         print("Error:", message)

# #     def onclose(message):
# #         print("Connection closed:", message)

# #     def onopen():
# #         """
# #         Callback function to subscribe to symbols upon WebSocket connection.
# #         """
# #         data_type = "SymbolUpdate"
# #         symbols = [symbol]
# #         fyers.subscribe(symbols=symbols, data_type=data_type)
# #         fyers.keep_running()  # Keep the socket running

# #     # Create a FyersDataSocket instance with the provided parameters
# #     fyers = data_ws.FyersDataSocket(
# #         access_token=access_token,
# #         log_path="",
# #         litemode=False,
# #         write_to_file=False,
# #         reconnect=True,
# #         on_connect=onopen,
# #         on_close=onclose,
# #         on_error=onerror,
# #         on_message=onmessage
# #     )

# #     # Start the WebSocket connection
# #     fyers.connect()

# #     # Wait for LTP to be received (with a timeout of 10 seconds)
# #     ltp_received_event.wait(timeout=1)

# #     # If LTP is received within the timeout, return the value; otherwise, return None
# #     return ltp_data.get(symbol, None)



 