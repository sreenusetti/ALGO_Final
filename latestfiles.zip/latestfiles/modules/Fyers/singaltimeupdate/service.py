import json
import os
from datetime import datetime

# File paths
INPUT_FILE = "updated_indicator_values_MCX_NATGASMINI25FEBFUT.json"
OUTPUT_FILE = "signals_updatetime.json"
PREVIOUS_STATE_FILE = "previous_state.json"

def load_json(file_path):
    """ Load JSON data from a file safely. """
    if os.path.exists(file_path):
        try:
            with open(file_path, "r") as file:
                return json.load(file)
        except (json.JSONDecodeError, ValueError):
            print(f"⚠️ Warning: {file_path} is empty or corrupted. Resetting data.")
            return {}  # Return an empty dictionary if JSON is invalid
    return {}

def save_json(file_path, data):
    """ Save JSON data to a file. """
    with open(file_path, "w") as file:
        json.dump(data, file, indent=4)

def detect_signal_changes(current_data, previous_data):
    """ Detect changes in signals where they turned from False to True. """
    updates = load_json(OUTPUT_FILE)  # Load previous updates safely

    if not isinstance(updates, dict):
        updates = {}  # Ensure it's a dictionary

    for timeframe, details in current_data.items():
        current_signals = details.get("signals", {})
        previous_signals = previous_data.get(timeframe, {}).get("signals", {})

        for signal, current_value in current_signals.items():
            previous_value = previous_signals.get(signal, False)  # Default to False if missing
            
            # Detect change from False -> True
            if not previous_value and current_value:
                if timeframe not in updates:
                    updates[timeframe] = []  # Initialize as a list
                
                updates[timeframe].append({
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3],  
                    "ltp": details.get("close", None),  # Ensure safe access
                    "signal": signal
                })
    
    return updates

def update_signals():
    """ Main function to process signals and update output file. """
    # Load current state from input file
    current_json_data = load_json(INPUT_FILE)

    if not current_json_data:
        print(f"⚠️ Error: {INPUT_FILE} is empty or contains invalid JSON.")
        return

    # Load previous state
    previous_state = load_json(PREVIOUS_STATE_FILE)

    # Detect signal changes
    updates = detect_signal_changes(current_json_data, previous_state)

    # Save updated signals to signals_updatetime.json
    if updates:
        save_json(OUTPUT_FILE, updates)
        print(f"✅ Updates saved to {OUTPUT_FILE}")
    else:
        print("✅ No signal changes detected.")

    # Save current state for future comparison
    save_json(PREVIOUS_STATE_FILE, current_json_data)

# # Run update function
# update_signals()
