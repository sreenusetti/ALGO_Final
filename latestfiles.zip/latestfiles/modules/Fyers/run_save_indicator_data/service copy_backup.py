import pandas as pd
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws
from modules.Fyers.service import save_to_json, load_from_json, fetchOHLC2, bollinger_bands, ema, atr, supertrend
from modules.Fyers.placeorder.service import placeOrder
from modules.Fyers.signal.service import signal
from modules.Fyers.save_indicator_data.service import save_indicator_data
from modules.Fyers.HA.service import calculate_heikin_ashi
from modules.Fyers.trend.service import trend # Import from candels_trend.py
from modules.Fyers.placed_order_data.service import place_order_based_on_trend

import datetime as dt
import pytz
import numpy as np
import time
import json
import os
import contextlib
import datetime

# Paths for JSON files
indicator_json_path = 'indicator_values.json'
updated_json_path = 'updated_indicator_values.json'
output_txt_path = 'output.txt'  # Path for the output data file
output_terminal_path = 'output_terminal.txt'  # Path for the terminal output file

# Initialize the FyersModel instance
client_id = open("client_id.txt", 'r').read().strip()
access_token = open("access_token.txt", 'r').read().strip()
fyers = fyersModel.FyersModel(client_id=client_id, is_async=True, token=access_token, log_path="")

# Function to load JSON data from a file
def load_json_data(json_filename):
    try:
        with open(json_filename, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        log_message(f"File not found: {json_filename}")
        return None
    except json.JSONDecodeError as e:
        log_message(f"Error decoding JSON from {json_filename}: {e}")
        return None

# Function to save indicator data to JSON
def save_indicator_data(data, json_filename):
    with open(json_filename, 'w') as file:
        json.dump(data, file, indent=4)

# Function to save output to a text file
def save_output_to_txt(output, file_path):
    with open(file_path, 'a') as file:  # Open in append mode
        file.write(output + '\n')

# Function to log messages and save to terminal output file
def log_message(message):
    print(message)  # Print to console
    save_output_to_txt(message, output_terminal_path)  # Save to terminal output file

# Function to convert non-serializable objects (e.g., numpy types) to Python types
def convert_to_serializable(obj):
    if isinstance(obj, np.bool_):
        return bool(obj)
    elif isinstance(obj, np.integer):
        return int(obj)
    elif isinstance(obj, np.floating):
        return float(obj)
    else:
        return obj

# Function to convert dictionaries or lists to serializable formats
def convert_dict_to_serializable(data):
    if isinstance(data, dict):
        return {k: convert_dict_to_serializable(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [convert_dict_to_serializable(v) for v in data]
    else:
        return convert_to_serializable(data)


# Function to run and save indicator data, including placing the order
def run_save_indicator_data():
    tickers = ["NSE:INFY-EQ"]
    timeframes = {"1min": "1", "5min": "5", "15min": "15","30min": "30", "ihr": "60","1day": "1"}
    all_timeframe_data = {}

    for ticker in tickers:
        try:
            for timeframe_name, timeframe_value in timeframes.items():
                log_message(f"Processing {ticker} for {timeframe_name} timeframe.")
                ohlc = fetchOHLC2(ticker, timeframe_value, 5)

                if 'Close' not in ohlc.columns:
                    raise KeyError(f"'Close' column not found in OHLC data for {ticker}. Available columns: {ohlc.columns}")

                ohlc = bollinger_bands(ohlc)
                ohlc = ema(ohlc, window=21)
                ohlc["st1"] = supertrend(ohlc, 21, 1)

                close = ohlc['Close'].iloc[-1]
                ema_5 = ema(ohlc, window=5)['EMA5'].iloc[-1]
                ema_21 = ohlc['EMA21'].iloc[-1]
                upper_bb = ohlc['BB_upper'].iloc[-1]
                lower_bb = ohlc['BB_lower'].iloc[-1]
                st21Buy = bool(ohlc['st1'].iloc[-1] < close)  # Convert to boolean
                st21Sell = bool(ohlc['st1'].iloc[-1] > close)  # Convert to boolean
                st21Trend = 1 if st21Buy else -1

                # Heikin-Ashi trend
                ohlc_ha = calculate_heikin_ashi(ohlc)
                ha_trend = 'green' if ohlc_ha['HA_Close'].iloc[-1] > ohlc_ha['HA_Open'].iloc[-1] else 'red'

                log_message(f"Calculated st21Trend and Heikin-Ashi for {timeframe_name}: st21Trend = {st21Trend}, ha_trend = {ha_trend}")

                signals = signal(ema_5, ema_21, st21Buy, st21Sell, st21Trend, True, False, close, upper_bb, lower_bb, upper_bb, lower_bb, lower_bb, upper_bb)

                current_timestamp = datetime.datetime.now().isoformat()

                indicator_data = {
                    'timestamp': current_timestamp,
                    'close': close,
                    'ema_5': ema_5,
                    'ema_21': ema_21,
                    'upper_bb': upper_bb,
                    'lower_bb': lower_bb,
                    'st21Buy': st21Buy,
                    'st21Sell': st21Sell,
                    'st21Trend': st21Trend,
                    'ha_trend': ha_trend,
                    'signals': signals
                }

                all_timeframe_data[timeframe_name] = convert_dict_to_serializable(indicator_data)

            save_indicator_data(all_timeframe_data, updated_json_path)
            log_message(f"Data saved to {updated_json_path}")

            output_message = f"{current_timestamp} - {ticker}: {all_timeframe_data}"
            save_output_to_txt(output_message, output_txt_path)

            place_order_based_on_trend(all_timeframe_data)

        except KeyError as ke:
            log_message(f"KeyError for {ticker}: {ke}")
        except Exception as e:
            log_message(f"Error processing {ticker}: {e}")
