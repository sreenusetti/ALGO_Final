import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression

# ATR Calculation Function
def calculate_atr(data, period=14):
    data['high_low'] = data['High'] - data['Low']
    data['high_close'] = np.abs(data['High'] - data['Close'].shift())
    data['low_close'] = np.abs(data['Low'] - data['Close'].shift())
    data['tr'] = data[['high_low', 'high_close', 'low_close']].max(axis=1)
    data['atr'] = data['tr'].rolling(window=period).mean()
    return data['atr']

# Pivot points calculation for a single day
def calculate_pivot_points(high, low, close):
    pivot = round((high + low + close) / 3, 2)
    r1 = round((2 * pivot - low), 2)
    r2 = round((pivot + (high - low)), 2)
    r3 = round((high + 2 * (pivot - low)), 2)
    s1 = round((2 * pivot - high), 2)
    s2 = round((pivot - (high - low)), 2)
    s3 = round((low - 2 * (high - pivot)), 2)
    return pivot, r1, r2, r3, s1, s2, s3

# Forecasting function for the next 7 days with pivot points
def forecast_next_week(data, period=14, days_ahead=7):
    # Feature engineering for forecasting
    data['Returns'] = np.log(data['Close'] / data['Close'].shift(1))
    data['SMA_5'] = data['Close'].rolling(window=5).mean()
    data['SMA_20'] = data['Close'].rolling(window=20).mean()
    data['ATR'] = calculate_atr(data, period)
    data = data.dropna().reset_index(drop=True)

    # Model setup
    features = ['SMA_5', 'SMA_20', 'ATR', 'Close']
    model = LinearRegression()
    X = data[features].values
    y = data['Close'].values
    model.fit(X, y)

    # Forecast for the next 7 days
    forecasted_prices = []
    last_data = data[features].iloc[-1].values.reshape(1, -1)
    for _ in range(days_ahead):
        next_price = model.predict(last_data)[0]
        forecasted_prices.append(next_price)

        # Update features for the next day prediction
        sma_5 = np.mean([last_data[0][0]] * 4 + [next_price])
        sma_20 = np.mean([last_data[0][1]] * 19 + [next_price])
        atr = np.mean([last_data[0][2]] * (period - 1) + [abs(next_price - last_data[0][3])])
        last_data = np.array([[sma_5, sma_20, atr, next_price]])

    # For each forecasted price, calculate pivot points based on estimated high/low/close
    forecast_data = []
    last_high = data['High'].iloc[-1]
    last_low = data['Low'].iloc[-1]

    for i, close in enumerate(forecasted_prices, start=1):
        pivot, r1, r2, r3, s1, s2, s3 = calculate_pivot_points(last_high, last_low, close)
        forecast_data.append({
            'Day': f'Day {i}',
            'Forecast_Close': round(close, 2),
            'Pivot': pivot,
            'R1': r1, 'R2': r2, 'R3': r3,
            'S1': s1, 'S2': s2, 'S3': s3
        })

    return forecast_data

# Main function to perform forecast and save output
def AI_forecast_next_week(file_path, output_csv='forecast_output.csv'):
    try:
        # Load and preprocess data
        data = preprocess_data(file_path)
        
        # Forecast next week's prices with pivot points and support/resistance levels
        forecasted_data = forecast_next_week(data)
        
        # Save to CSV
        df_forecast = pd.DataFrame(forecasted_data)
        df_forecast.to_csv(output_csv, index=False)
        print(f"Forecast saved to {output_csv}")

        return df_forecast

    except Exception as e:
        print("Error during processing:", str(e))
        return None

# Data Preprocessing Function
def preprocess_data(file_path):
    data = pd.read_csv(file_path, parse_dates=['Date '])
    # Standardize column names
    data.rename(columns={'Date ': 'Date', 'OPEN ': 'Open', 'HIGH ': 'High', 'LOW ': 'Low', 'close ': 'Close'}, inplace=True)
    # Clean numeric data
    for col in ['Open', 'High', 'Low', 'Close']:
        data[col] = data[col].replace({',': ''}, regex=True).astype(float)
    return data
