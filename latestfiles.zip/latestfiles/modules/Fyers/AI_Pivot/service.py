# market_analysis.py
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
import numpy as np

def load_data(file_path):
    # Load the dataset
    data = pd.read_csv(file_path)
    data.columns = [col.strip() for col in data.columns]  # Strip spaces from column names
    data['Date'] = pd.to_datetime(data['Date'], format='%d-%b-%Y')
    
    # Sort data by Date to ensure chronological order and reset index
    data = data.sort_values(by='Date').reset_index(drop=True)
    
    # Convert columns to float
    data['PREV. CLOSE'] = data['PREV. CLOSE'].str.replace(',', '').astype(float)
    data['HIGH'] = data['HIGH'].str.replace(',', '').astype(float)
    data['LOW'] = data['LOW'].str.replace(',', '').astype(float)
    data['close'] = data['close'].str.replace(',', '').astype(float)
    data['OPEN'] = data['OPEN'].str.replace(',', '').astype(float)
    
    return data

def train_model(data):
    # Feature Engineering
    features = data[['OPEN', 'HIGH', 'LOW', 'PREV. CLOSE']]
    target = data['close']
    
    # Split the data into training and test sets
    X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, shuffle=False)
    
    # Train a Linear Regression model
    model = LinearRegression()
    model.fit(X_train, y_train)
    
    # Test the model and calculate MAE
    y_pred = model.predict(X_test)
    mae = mean_absolute_error(y_test, y_pred)
    return model, mae

def predict_next_day_close(model, data):
    # Forecast the next day's close based on the last available data
    last_row = data.iloc[-1][['OPEN', 'HIGH', 'LOW', 'PREV. CLOSE']].to_frame().T  # Use DataFrame to keep feature names
    predicted_close = model.predict(last_row)[0]
    return predicted_close

def calculate_support_resistance(high, low, close):
    # Pivot Point Calculation
    pivot = (high + low + close) / 3

    # Resistance levels
    R1 = float((2 * pivot) - low)
    R2 = float(pivot + (high - low))
    R3 = float(high + 2 * (pivot - low))

    # Support levels
    S1 = float((2 * pivot) - high)
    S2 = float(pivot - (high - low))
    S3 = float(low - 2 * (high - pivot))

    return {'Pivot': pivot, 'R1': R1, 'R2': R2, 'R3': R3, 'S1': S1, 'S2': S2, 'S3': S3}
