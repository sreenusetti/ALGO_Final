
import pandas as pd
from fyers_apiv3 import fyersModel
import datetime as dt
import pytz
import time
import ta

# ✅ Read Fyers API Credentials
client_id = open("client_id.txt", 'r').read().strip()
access_token = open("access_token.txt", 'r').read().strip()

# ✅ Initialize Fyers API
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")

# ✅ Define Trading Symbol
SYMBOL = "MCX:NATGASMINI25MARFUT"

import ta

def fetchOHLC2(ticker, interval, duration):
    """Fetch OHLC data and calculate indicators."""
    range_from = dt.date.today() - dt.timedelta(days=duration)
    range_to = dt.date.today()

    data = {
        "symbol": ticker,
        "resolution": interval,
        "date_format": "1",
        "range_from": range_from.strftime("%Y-%m-%d"),
        "range_to": range_to.strftime("%Y-%m-%d"),
        "cont_flag": "1"
    }

    response = fyers.history(data=data)
    if "candles" not in response:
        print("Error: No candle data found!")
        return None

    df = pd.DataFrame(response["candles"], columns=['Timestamp', 'Open', 'High', 'Low', 'Close', 'Volume'])
    
    # Ensure data is available
    if df.empty:
        print("Error: Empty DataFrame received from Fyers API!")
        return None

    df['Timestamp'] = pd.to_datetime(df['Timestamp'], unit='s').dt.tz_localize(pytz.utc).dt.tz_convert('Asia/Kolkata')

    # ✅ Ensure columns exist before applying indicators
    required_columns = ['High', 'Low', 'Close']
    if not all(col in df.columns for col in required_columns):
        print(f"Error: Missing columns in OHLC data: {df.columns}")
        return None

    # ✅ Calculate ADX indicators
    df["ADX"] = ta.trend.adx(df["High"], df["Low"], df["Close"], window=14)
    df["DI+"] = ta.trend.adx_pos(df["High"], df["Low"], df["Close"], window=14)
    df["DI-"] = ta.trend.adx_neg(df["High"], df["Low"], df["Close"], window=14)

    print("ADX Calculation Successful!")  # Debugging Output
    print(df[["ADX", "DI+", "DI-"]].tail())  # Show last few rows of indicators

    return df


# def fetchOHLC(ticker, interval, duration):
#     """Fetch OHLC data and calculate indicators."""
#     range_from = dt.date.today() - dt.timedelta(days=duration)
#     range_to = dt.date.today()

#     data = {
#         "symbol": ticker,
#         "resolution": interval,
#         "date_format": "1",
#         "range_from": range_from.strftime("%Y-%m-%d"),
#         "range_to": range_to.strftime("%Y-%m-%d"),
#         "cont_flag": "1"
#     }

#     response = fyers.history(data=data)
#     if "candles" not in response:
#         return None

#     df = pd.DataFrame(response["candles"], columns=['Timestamp', 'Open', 'High', 'Low', 'Close', 'Volume'])
#     df['Timestamp'] = pd.to_datetime(df['Timestamp'], unit='s').dt.tz_localize(pytz.utc).dt.tz_convert('Asia/Kolkata')

#     # ✅ Calculate Indicators
#     df["ADX"] = ta.trend.adx(df["High"], df["Low"], df["Close"], window=14)
#     df["DI+"] = ta.trend.adx_pos(df["High"], df["Low"], df["Close"], window=14)
#     df["DI-"] = ta.trend.adx_neg(df["High"], df["Low"], df["Close"], window=14)
#     df["EFI"] = ta.volume.ForceIndexIndicator(df["Close"], df["Volume"], window=13).force_index()
#     df["Momentum"] = ta.momentum.ROCIndicator(df["Close"], window=10).roc()
#     df["ATR"] = ta.volatility.AverageTrueRange(df["High"], df["Low"], df["Close"], window=14).average_true_range()
#     df["VWAP"] = (df["Close"] * df["Volume"]).cumsum() / df["Volume"].cumsum()
    
#     # ✅ Bollinger Bands for Sideways Market Detection
#     df["Bollinger_Upper"] = ta.volatility.bollinger_hband(df["Close"], window=20, window_dev=2)
#     df["Bollinger_Lower"] = ta.volatility.bollinger_lband(df["Close"], window=20, window_dev=2)

#     return df


import json
import pandas as pd

def convert_to_serializable(obj):
    """Converts NumPy and Pandas data types to standard Python types for JSON serialization."""
    if isinstance(obj, (pd.Series, dict)):
        return {k: convert_to_serializable(v) for k, v in obj.items()}
    elif isinstance(obj, (pd.Timestamp, pd.Timedelta)):
        return str(obj)  # Convert timestamps to string
    elif isinstance(obj, (float, int, str, bool, type(None))):
        return obj  # Keep native types unchanged
    else:
        return float(obj)  # Convert NumPy types to float

def adx_efi_mom_trade_signal(df, higher_tf_df=14):
    """Determines the best trade action using multiple confirmations and saves data."""
    if df.shape[0] < 2:
        return "NO TRADE"
    
    latest, previous = df.iloc[-1], df.iloc[-2]
    
    # ✅ ADX Trend Strength Confirmation
    strong_trend = latest["ADX"] > 25
    weak_trend = latest["ADX"] < 20
    higher_trend = higher_tf_df.iloc[-1]["ADX"] > 25
    
    # ✅ Momentum & EFI Confirmation
    bullish_momentum = latest["Momentum"] > 0 and latest["EFI"] > 0
    bearish_momentum = latest["Momentum"] < 0 and latest["EFI"] < 0
    momentum_shift_bullish = latest["Momentum"] > 0 and previous["Momentum"] < 0
    momentum_shift_bearish = latest["Momentum"] < 0 and previous["Momentum"] > 0

    # ✅ DI+/DI- Crossovers
    bullish_crossover = latest["DI+"] > latest["DI-"] and previous["DI+"] < previous["DI-"]
    bearish_crossover = latest["DI-"] > latest["DI+"] and previous["DI-"] < previous["DI+"] 

    # ✅ Higher Timeframe Confirmation
    higher_bullish = higher_tf_df.iloc[-1]["DI+"] > higher_tf_df.iloc[-1]["DI-"]
    higher_bearish = higher_tf_df.iloc[-1]["DI-"] > higher_tf_df.iloc[-1]["DI+"]

    # ✅ VWAP Confirmation
    above_vwap = latest["Close"] > latest["VWAP"]
    below_vwap = latest["Close"] < latest["VWAP"]

    # ✅ Bollinger Bands Filtering
    near_upper_band = latest["Close"] > latest["Bollinger_Upper"]
    near_lower_band = latest["Close"] < latest["Bollinger_Lower"]

    # ✅ ATR-Based Stop-Loss & False Breakout Filtering
    atr_threshold = latest["ATR"] * 1.5  # Dynamic SL
    breakout_move = abs(latest["Close"] - previous["Close"]) > atr_threshold

    # 🚀 **Determine Trade Action**
    trade_action = "NO TRADE"

    if (
        strong_trend and bullish_crossover and bullish_momentum
        and higher_trend and higher_bullish
        and above_vwap and not near_upper_band and breakout_move
    ):
        trade_action = "BUY"

    elif (
        strong_trend and bearish_crossover and bearish_momentum
        and higher_trend and higher_bearish
        and below_vwap and not near_lower_band and breakout_move
    ):
        trade_action = "SELL"

    elif (
        weak_trend or (latest["DI-"] > latest["DI+"] and bearish_momentum)
        or (latest["Close"] < latest["VWAP"] and not breakout_move)
    ):
        trade_action = "EXIT BUY"

    elif (
        weak_trend or (latest["DI+"] > latest["DI-"] and bullish_momentum)
        or (latest["Close"] > latest["VWAP"] and not breakout_move)
    ):
        trade_action = "EXIT SELL"

    # 🌟 **Save values to JSON**
    trade_data = {
        "latest": convert_to_serializable(latest.to_dict()),
        "previous": convert_to_serializable(previous.to_dict()),
        "conditions": convert_to_serializable({
            "strong_trend": strong_trend, "weak_trend": weak_trend, "higher_trend": higher_trend,
            "bullish_momentum": bullish_momentum, "bearish_momentum": bearish_momentum,
            "momentum_shift_bullish": momentum_shift_bullish, "momentum_shift_bearish": momentum_shift_bearish,
            "bullish_crossover": bullish_crossover, "bearish_crossover": bearish_crossover,
            "higher_bullish": higher_bullish, "higher_bearish": higher_bearish,
            "above_vwap": above_vwap, "below_vwap": below_vwap,
            "near_upper_band": near_upper_band, "near_lower_band": near_lower_band,
            "atr_threshold": atr_threshold, "breakout_move": breakout_move
        }),
        "trade_action": trade_action
    }

    with open("adx_efi_mom.json", "w") as file:
        json.dump(trade_data, file, indent=4)

    return trade_action

# ohlc_5m = fetchOHLC(SYMBOL, "5", 10)
# ohlc_15m = fetchOHLC(SYMBOL, "15", 15)
# ohlc_30m = fetchOHLC(SYMBOL, "30", 20)

# if ohlc_5m is not None and ohlc_15m is not None and ohlc_30m is not None:
#     trade_signal = adx_efi_mom_trade_signal(ohlc_5m, ohlc_15m)
#     print(f"🚀 Trade Decision: {trade_signal}")

# # ✅ Live Updates Every 5 Minutes
# while True:
#     ohlc_5m = fetchOHLC(SYMBOL, "5", 1)
#     ohlc_15m = fetchOHLC(SYMBOL, "15", 5)
#     ohlc_30m = fetchOHLC(SYMBOL, "30", 10)

#     if ohlc_5m is not None and ohlc_15m is not None and ohlc_30m is not None:
#         trade_signal = adx_efi_mom_trade_signal(ohlc_5m, ohlc_15m)
#         print(f"\n✅ Real-Time Update: {trade_signal}")
    
time.sleep(10)
