import pandas as pd
from fyers_apiv3 import fyersModel
import datetime as dt
import pytz
import ta
import json
import time

# ✅ Read Fyers API Credentials
client_id = open("client_id.txt", 'r').read().strip()
access_token = open("access_token.txt", 'r').read().strip()

# ✅ Initialize Fyers API
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")

# # ✅ Define Trading Symbol
# SYMBOL = "MCX:NATGASMINI25MARFUT"

def fetchOHLC1(ticker, interval, duration):
    """Fetch OHLC data and calculate indicators safely."""
    range_from = (dt.date.today() - dt.timedelta(days=duration)).strftime("%Y-%m-%d")
    range_to = dt.date.today().strftime("%Y-%m-%d")

    data = {
        "symbol": ticker,
        "resolution": interval,
        "date_format": "1",
        "range_from": range_from,
        "range_to": range_to,
        "cont_flag": "1"
    }

    response = fyers.history(data=data)
    if "candles" not in response or not response["candles"]:
        print(f"⚠️ No candles returned for {ticker}")
        return pd.DataFrame()

    df = pd.DataFrame(response["candles"], columns=['Timestamp', 'Open', 'High', 'Low', 'Close', 'Volume'])
    df['Timestamp'] = pd.to_datetime(df['Timestamp'], unit='s').dt.tz_localize(pytz.utc).dt.tz_convert('Asia/Kolkata')

    # ✅ Ensure we have enough data for indicator calculation
    if len(df) < 14:
        print(f"⚠️ Not enough candles ({len(df)}) for ADX calculation for {ticker}. Filling zeros.")
        df["ADX"] = df["DI+"] = df["DI-"] = 0
        df["Momentum"] = df["EFI"] = df["RSI"] = 0
        df["VWAP"] = df["Top VWAP"] = df["Bottom VWAP"] = 0
        return df

    try:
        # ✅ ADX and related indicators
        df["ADX"] = ta.trend.adx(df["High"], df["Low"], df["Close"], window=14)
        df["DI+"] = ta.trend.adx_pos(df["High"], df["Low"], df["Close"], window=14)
        df["DI-"] = ta.trend.adx_neg(df["High"], df["Low"], df["Close"], window=14)

        # ✅ Momentum, EFI, RSI
        df["Momentum"] = ta.momentum.ROCIndicator(df["Close"], window=10).roc()
        df["EFI"] = ta.volume.ForceIndexIndicator(df["Close"], df["Volume"], window=13).force_index()
        df["RSI"] = ta.momentum.RSIIndicator(df["Close"], window=14).rsi()

        # ✅ VWAP & Bands
        df["Typical Price"] = (df["High"] + df["Low"] + df["Close"]) / 3
        df["VWAP"] = df["Typical Price"].rolling(window=20).apply(
            lambda x: (x * df["Volume"].iloc[x.index]).sum() / df["Volume"].iloc[x.index].sum(), raw=False
        )
        df["Top VWAP"] = df["VWAP"] + (df["High"] - df["Low"])
        df["Bottom VWAP"] = df["VWAP"] - (df["High"] - df["Low"])
        df.drop(columns=["Typical Price"], inplace=True)

        print(f"✅ {ticker}: ADX={df['ADX'].iloc[-1]:.2f}, RSI={df['RSI'].iloc[-1]:.2f}")
    except Exception as e:
        print(f"⚠️ Indicator calc failed for {ticker}: {e}")
        for col in ["ADX", "DI+", "DI-", "Momentum", "EFI", "RSI", "VWAP", "Top VWAP", "Bottom VWAP"]:
            df[col] = 0

    return df


#def fetchOHLC1(ticker, interval, duration):
#    """Fetch OHLC data and calculate indicators."""
#    range_from = (dt.date.today() - dt.timedelta(days=duration)).strftime("%Y-%m-%d")
#    range_to = dt.date.today().strftime("%Y-%m-%d")

#    data = {
#        "symbol": ticker,
#        "resolution": interval,
#        "date_format": "1",
#        "range_from": range_from,
#        "range_to": range_to,
#        "cont_flag": "1"
#    }
    
#    response = fyers.history(data=data)
#    if "candles" not in response:
#        print("Error fetching data from Fyers API")
#        return None

#    df = pd.DataFrame(response["candles"], columns=['Timestamp', 'Open', 'High', 'Low', 'Close', 'Volume'])
#    df['Timestamp'] = pd.to_datetime(df['Timestamp'], unit='s').dt.tz_localize(pytz.utc).dt.tz_convert('Asia/Kolkata')

    # ✅ Calculate Indicators
#    df["ADX"] = ta.trend.adx(df["High"], df["Low"], df["Close"], window=14)
#    df["DI+"] = ta.trend.adx_pos(df["High"], df["Low"], df["Close"], window=14)
#    df["DI-"] = ta.trend.adx_neg(df["High"], df["Low"], df["Close"], window=14)
#    df["Momentum"] = ta.momentum.ROCIndicator(df["Close"], window=10).roc()
#    df["EFI"] = ta.volume.ForceIndexIndicator(df["Close"], df["Volume"], window=13).force_index()
#    df["RSI"] = ta.momentum.RSIIndicator(df["Close"], window=14).rsi()
    
    # ✅ Corrected Rolling VWAP Calculation
#    df["Typical Price"] = (df["High"] + df["Low"] + df["Close"]) / 3
#    df["VWAP"] = df["Typical Price"].rolling(window=20).apply(lambda x: (x * df["Volume"][x.index]).sum() / df["Volume"][x.index].sum(), raw=False)
    
    # ✅ Calculate Top VWAP and Bottom VWAP
#    df["Top VWAP"] = df["VWAP"] + (df["High"] - df["Low"])
#    df["Bottom VWAP"] = df["VWAP"] - (df["High"] - df["Low"])
    
#    df.drop(columns=["Typical Price"], inplace=True)
    
#    print("Latest ADX:", df["ADX"].iloc[-1])
#    print("Latest DI+:", df["DI+"].iloc[-1])
#    print("Latest DI-:", df["DI-"].iloc[-1])
#    print("Latest Momentum:", df["Momentum"].iloc[-1])
#    print("Latest Elder Force Index:", df["EFI"].iloc[-1])
#    print("Latest RSI:", df["RSI"].iloc[-1])
    # print("Latest VWAP:", df["VWAP"].iloc[-1])
    # print("Latest Top VWAP:", df["Top VWAP"].iloc[-1])
    # print("Latest Bottom VWAP:", df["Bottom VWAP"].iloc[-1])
    
#    return df

def adx_efi_mom_trade_signal(df, symbol):
    """Determines the best trade action using ADX, EFI, Momentum, RSI, and VWAP."""
    if df is None or df.shape[0] < 20:
        print("Insufficient data for trade decision")
        return "NO TRADE", None, None, None, None, None, None, None, None, None
    
    latest, previous = df.iloc[-1], df.iloc[-2]
    
    strong_trend = latest["ADX"] > 25
    bullish_crossover = latest["DI+"] > latest["DI-"] and previous["DI+"] < previous["DI-"]
    bearish_crossover = latest["DI-"] > latest["DI+"] and previous["DI-"] < previous["DI+"]
    bullish_momentum = latest["Momentum"] > 0 and latest["EFI"] > 0
    bearish_momentum = latest["Momentum"] < 0 and latest["EFI"] < 0
    
    bullish_rsi = latest["RSI"] > 50
    bearish_rsi = latest["RSI"] < 50
    # bullish_vwap = latest["Close"] > latest["VWAP"]
    # bearish_vwap = latest["Close"] < latest["VWAP"]
    
    trade_action = "NO TRADE"
    if strong_trend and bullish_crossover and bullish_momentum and bullish_rsi:
        trade_action = "BUY"
    elif strong_trend and bearish_crossover and bearish_momentum and bearish_rsi:
        trade_action = "SELL"
    
    print(f"Trade Signal: {trade_action}")
    
    trade_data = {
        "trade_action": trade_action,
        "ADX": latest["ADX"],
        "DI+": latest["DI+"],
        "DI-": latest["DI-"],
        "Momentum": latest["Momentum"],
        "EFI": latest["EFI"],
        "RSI": latest["RSI"]
        # "VWAP": latest["VWAP"],
        # "Top VWAP": latest["Top VWAP"],
        # "Bottom VWAP": latest["Bottom VWAP"]
    }
    
    # with open("adx_efi_mom.json", "w") as file:
    #     json.dump(trade_data, file, indent=4)
    
    with open(symbol.replace(":", "_") + "_adx_efi_mom.json", "w") as file:
         json.dump(trade_data, file, indent=4)



    
    return trade_action, latest["ADX"], latest["DI+"], latest["DI-"], latest["Momentum"], latest["EFI"], latest["RSI"] 
time.sleep(1)

 