import pandas as pd
from fyers_apiv3 import fyersModel
import datetime as dt
import pytz
import numpy as np
import statsmodels.api as sm    #pip install statsmodels
from modules.Fyers.service import save_to_json, load_from_json, fetchOHLC2

# Generate trading session
client_id = open("client_id.txt",'r').read()
access_token = open("access_token.txt",'r').read()

# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")

# Function to fetch OHLC data
def fetchOHLC2(ticker, interval, duration):
    range_from = dt.date.today() - dt.timedelta(duration)
    range_to = dt.date.today()

    from_date_string = range_from.strftime("%Y-%m-%d")
    to_date_string = range_to.strftime("%Y-%m-%d")
    
    data = {
        "symbol": ticker,
        "resolution": interval,
        "date_format": "1",
        "range_from": from_date_string,
        "range_to": to_date_string,
        "cont_flag": "1"
    }

    response = fyers.history(data=data)['candles']
    
    # Create DataFrame
    columns = ['Timestamp', 'Open', 'High', 'Low', 'Close', 'Volume']
    df = pd.DataFrame(response, columns=columns)

    # Convert Timestamp to datetime in UTC
    df['Timestamp2'] = pd.to_datetime(df['Timestamp'], unit='s').dt.tz_localize(pytz.utc)

    # Convert Timestamp to IST
    ist = pytz.timezone('Asia/Kolkata')
    df['Timestamp2'] = df['Timestamp2'].dt.tz_convert(ist)
    df.drop(columns=['Timestamp'], inplace=True)

    return df

# Function to determine trend
def trend(df):
    trend = None
    i = len(df) - 1

    # Uptrend condition
    if (df['Close'][i] > df['Open'][i] and df['Close'][i-1] > df['Open'][i-1] and 
        df['Close'][i-2] > df['Open'][i-2] and df['High'][i] > df['High'][i-1] and 
        df['High'][i-1] > df['High'][i-2] and df['Low'][i] > df['Low'][i-1] and 
        df['Low'][i-1] > df['Low'][i-2]):
        trend = 'Uptrend'
    # Downtrend condition
    elif (df['Close'][i] < df['Open'][i] and df['Close'][i-1] < df['Open'][i-1] and 
          df['Close'][i-2] < df['Open'][i-2] and df['High'][i] < df['High'][i-1] and 
          df['High'][i-1] < df['High'][i-2] and df['Low'][i] < df['Low'][i-1] and 
          df['Low'][i-1] < df['Low'][i-2]):
        trend = 'Downtrend'
    else:
        trend = 'No clear trend'

    return trend

# Fetch 5-minute and 15-minute data
#df_1min = fetchOHLC2("NSE:INFY-EQ", "5", 1) 
#df_5min = fetchOHLC2("NSE:INFY-EQ", "5", 1)   # Fetch 5-minute data for last 5 days
df_15min = fetchOHLC2("NSE:INFY-EQ", "15", 21)  # Fetch 15-minute data for last 5 days
df_30min = fetchOHLC2("NSE:INFY-EQ", "30", 21) 
df_1hr= fetchOHLC2("NSE:INFY-EQ", "60", 21) 
df_1Day = fetchOHLC2("NSE:INFY-EQ", "D", 21) 
# Determine trend for both timeframes
#trend_1min = trend(df_5min)
#trend_5min = trend(df_5min)
trend_15min = trend(df_15min)
trend_30min = trend(df_30min)
trend_1hr = trend(df_1hr)
trend_1Day = trend(df_1Day)


#print("1-Minute candles Trend:", trend_1min)
#print("5-Minute candlesTrend:", trend_5min)
print("15-Minute candles Trend:", trend_15min)
print("30-Minute candlesTrend:", trend_30min)
print("1-hr candlesTrend:", trend_1hr)
print("1-day candles Trend:", trend_1Day)