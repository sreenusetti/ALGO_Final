# file_utils.py
import json
import os

def outputfile(symbol, base_dir="output_files"):
    # Paths for JSON and text files
    indicator_json_path = os.path.join(base_dir, f'indicator_values_{symbol}.json')
    updated_json_path = os.path.join(base_dir, f'updated_indicator_values_{symbol}.json')
    output_txt_path = os.path.join(base_dir, f'output_{symbol}.txt')
    output_terminal_path = os.path.join(base_dir, f'output_terminal_{symbol}.txt')
    order_data_json_path = os.path.join(base_dir, f'order_data_{symbol}.json')

    # Create base directory if it does not exist
    try:
        os.makedirs(base_dir, exist_ok=True)
        print(f"Directory '{base_dir}' created or already exists.")
    except Exception as e:
        print(f"Failed to create directory '{base_dir}': {e}")

    # Function to create and initialize JSON files with error checking
    def create_json_file(file_path, initial_data=None):
        try:
            if not os.path.exists(file_path):
                with open(file_path, 'w') as file:
                    json.dump(initial_data if initial_data is not None else {}, file)
                print(f"JSON file '{file_path}' created successfully.")
            else:
                print(f"JSON file '{file_path}' already exists.")
        except Exception as e:
            print(f"Failed to create JSON file '{file_path}': {e}")

    # Function to create text files with error checking
    def create_text_file(file_path):
        try:
            if not os.path.exists(file_path):
                with open(file_path, 'w') as file:
                    file.write('')  # Create an empty text file
                print(f"Text file '{file_path}' created successfully.")
            else:
                print(f"Text file '{file_path}' already exists.")
        except Exception as e:
            print(f"Failed to create text file '{file_path}': {e}")

    # Initialize each file with error checking
    create_json_file(indicator_json_path, initial_data={})
    create_json_file(updated_json_path, initial_data={})
    create_json_file(order_data_json_path, initial_data={})
    create_text_file(output_txt_path)
    create_text_file(output_terminal_path)

    print("All files have been checked for creation.")

    return (indicator_json_path, updated_json_path, order_data_json_path, output_txt_path,  output_terminal_path )
