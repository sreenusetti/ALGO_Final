import pandas as pd
import datetime as dt
import pytz
from fyers_apiv3 import fyersModel
from modules.Fyers.signal.service import signal
import numpy as np
import json

# Generate trading session
client_id = open("client_id.txt", 'r').read()
access_token = open("access_token.txt", 'r').read()

# Initialize the FyersModel instance
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")



# Function to fetch OHLC data
def fetchOHLC2(ticker, interval, duration):
    range_from = dt.date.today() - dt.timedelta(days=duration)
    range_to = dt.date.today()

    from_date_string = range_from.strftime("%Y-%m-%d")
    to_date_string = range_to.strftime("%Y-%m-%d")
    data = {
        "symbol": ticker,
        "resolution": interval,
        "date_format": "1",
        "range_from": from_date_string,
        "range_to": to_date_string,
        "cont_flag": "1"
    }

    response = fyers.history(data=data)
    
    # Check if 'candles' is in the response
    if 'candles' not in response:
        print(f"Error fetching data for {ticker}: {response}")
        return pd.DataFrame()  # Return an empty DataFrame if the response is invalid

    # Create a DataFrame
    columns = ['Timestamp', 'Open', 'High', 'Low', 'Close', 'Volume']
    df = pd.DataFrame(response['candles'], columns=columns)

    # Convert Timestamp to datetime in UTC and then to IST
    df['Timestamp2'] = pd.to_datetime(df['Timestamp'], unit='s').dt.tz_localize(pytz.utc)
    df['Timestamp2'] = df['Timestamp2'].dt.tz_convert('Asia/Kolkata')

    return df

# Function to calculate pivot points and supports/resistances
def pivotpoints_today(ohlc_day):
    """Returns pivot point and support/resistance levels."""
    high = round(ohlc_day["High"].iloc[-1], 2)
    low = round(ohlc_day["Low"].iloc[-1], 2)
    close = round(ohlc_day["Close"].iloc[-1], 2)
    
    pivot = round((high + low + close) / 3, 2)
    r1 = round((2 * pivot - low), 2)
    r2 = round((pivot + (high - low)), 2)
    r3 = round((high + 2 * (pivot - low)), 2)
    s1 = round((2 * pivot - high), 2)
    s2 = round((pivot - (high - low)), 2)
    s3 = round((low - 2 * (high - pivot)), 2)

    return pivot, r1, r2, r3, s1, s2, s3

# Function to dynamically set buy/sell/hold signals
def get_dynamic_signals(df):
    ema5 = df["Close"].ewm(span=5).mean().iloc[-1]
    ema21 = df["Close"].ewm(span=21).mean().iloc[-1]
    close = df['Close'].iloc[-1]

    # Define actual conditions based on indicators
    st21Buy = close > ema21  # Buy condition if the close is above EMA 21
    st21Sell = close < ema21  # Sell condition if the close is below EMA 21
    haGreen = st21Buy  # Replace with actual Heikin-Ashi Green logic
    haRed = st21Sell   # Replace with actual Heikin-Ashi Red logic

    return st21Buy, st21Sell, haGreen, haRed
# Function to convert non-serializable objects (e.g., numpy types) to Python types
def convert_to_serializable(obj):
    if isinstance(obj, np.bool_):
        return bool(obj)  # Convert numpy boolean to Python boolean
    elif isinstance(obj, np.integer):
        return int(obj)  # Convert numpy integer to Python integer
    elif isinstance(obj, np.floating):
        return float(obj)  # Convert numpy floating-point to Python float
    elif isinstance(obj, pd.Timestamp):
        return obj.isoformat()  # Convert pandas Timestamp to ISO format
    else:
        return obj


# Function to convert dictionaries or lists to serializable formats
def convert_dict_to_serializable(data):
    if isinstance(data, dict):
        return {k: convert_dict_to_serializable(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [convert_dict_to_serializable(v) for v in data]
    else:
        return convert_to_serializable(data)


# Function to save pivot data to a JSON file
def save_pivot_data(data, json_filename):
    try:
        serializable_data = convert_dict_to_serializable(data)  # Convert data to serializable format
        with open(json_filename, 'w') as file:
            json.dump(serializable_data, file, indent=4)  # Save the serializable data to the JSON file
        print(f"Pivot data successfully saved to {json_filename}")
    except Exception as e:
        print(f"Error saving pivot data: {e}")

# # Function to save pivot data to a JSON file
# def save_pivot_data(data, json_filename):
#     try:
#         serializable_data = convert_dict_to_serializable(data)  # Convert data to serializable format
#         with open(json_filename, 'w') as file:
#             json.dump(serializable_data, file, indent=4)  # Save the serializable data to the JSON file
#         print(f"Pivot data successfully saved to {json_filename}")
#     except Exception as e:
#         print(f"Error saving pivot data: {e}")


# Function to process tickers and save pivot points in JSON format
#def process_and_save_pivots(ticker_list, json_filename):

def process_and_save_pivots(ticker_list):
    all_pivot_data = {}

    for ticker in ticker_list:
        print(f"Processing ticker: {ticker}")
        # Fetch OHLC data
        stock_df = fetchOHLC2(ticker, "15", 1)
        if stock_df.empty:
            print(f"No data found for ticker: {ticker}. Skipping...")
            continue  # Skip if no data is returned

        # Ensure 'Timestamp2' is set as the index
        stock_df['Timestamp2'] = pd.to_datetime(stock_df['Timestamp2'])
        stock_df.set_index('Timestamp2', inplace=True)

        # Resample to daily OHLC
        daily_df = stock_df.resample('D').agg({
            'Open': 'first', 
            'High': 'max', 
            'Low': 'min', 
            'Close': 'last', 
            'Volume': 'sum'
        })
        daily_df.dropna(inplace=True)

        # Check if daily_df is empty after resampling
        if daily_df.empty:
            print(f"No daily data available for ticker: {ticker}. Skipping...")
            continue

        # Calculate pivot points
        try:
            pivot, r1, r2, r3, s1, s2, s3 = pivotpoints_today(daily_df)

            # Convert all pivot points to plain floats
            pivot, r1, r2, r3, s1, s2, s3 = (
                float(pivot), float(r1), float(r2), float(r3),
                float(s1), float(s2), float(s3)
            )

            # Save pivot data in a structured format
            pivot_data = {
                'timestamp': pd.Timestamp.now().isoformat(),
                'pivot': pivot,
                'r1': r1,
                'r2': r2,
                'r3': r3,
                's1': s1,
                's2': s2,
                's3': s3
            }

            # Save by ticker
            all_pivot_data[ticker] = pivot_data
            # print(f"Pivot data for {ticker}: {pivot_data}")

        except Exception as e:
            print(f"Error calculating pivot points for ticker {ticker}: {e}")
    return all_pivot_data


import time
# Function to continuously fetch pivot data and refresh the JSON file
def run_save_pivot_data_every_minute(ticker_list, json_filename):
    while True:
        print(f"Fetching and saving pivot data at {pd.Timestamp.now().isoformat()}")
        try:
            all_pivot_data = process_and_save_pivots(ticker_list)
            if all_pivot_data:
                save_pivot_data(all_pivot_data, json_filename)
            else:
                print("No pivot data to save.")
        except Exception as e:
            print(f"Error during pivot data refresh: {e}")

        # Wait for 60 seconds before fetching data again
        time.sleep(1)


    # # Save all pivot data to a JSON file
    # if all_pivot_data:
    #     save_pivot_data(all_pivot_data, json_filename)
    # else:
    #     print("No pivot data to save.")


# Example usage

    # df_result = pd.DataFrame(result_data)
    # df_result.to_csv('top_symbols_pivot.csv', index=False)


# # Function to process tickers and save pivot points and true signals in CSV
# def process_and_save_pivots(ticker_list):
#     result_data = []

#     for ticker in ticker_list:
#         # Fetch OHLC data
#         stock_df = fetchOHLC2(ticker, "15", 1)
#         if stock_df.empty:
#             continue  # Skip if no data is returned

#         # Ensure 'Timestamp2' is set as the index
#         stock_df['Timestamp2'] = pd.to_datetime(stock_df['Timestamp2'])
#         stock_df.set_index('Timestamp2', inplace=True)

#         # Resample to daily OHLC
#         daily_df = stock_df.resample('D').agg({
#             'Open': 'first', 
#             'High': 'max', 
#             'Low': 'min', 
#             'Close': 'last', 
#             'Volume': 'sum'
#         })
#         daily_df.dropna(inplace=True)

#         # Calculate pivot points
#         pivot, r1, r2, r3, s1, s2, s3 = pivotpoints_today(daily_df)

#         # Convert all pivot points to plain floats
#         pivot, r1, r2, r3, s1, s2, s3 = (
#             float(pivot), float(r1), float(r2), float(r3),
#             float(s1), float(s2), float(s3)
#         )

#         # Get dynamic signals from market data
#         st21Buy, st21Sell, haGreen, haRed = get_dynamic_signals(daily_df)

#         # Use the signal function from the imported module
#         signals = signal(
#             ema5=daily_df["Close"].ewm(span=5).mean().iloc[-1],
#             ema21=daily_df["Close"].ewm(span=21).mean().iloc[-1],
#             st21Buy=st21Buy,  # Use dynamic conditions
#             st21Sell=st21Sell,  # Use dynamic conditions
#             st21Trend=1 if st21Buy else -1,  # Example: 1 for Buy, -1 for Sell
#             haGreen=haGreen,  # Use dynamic conditions
#             haRed=haRed,  # Use dynamic conditions
#             close=daily_df['Close'].iloc[-1],
#             upperBB=1883.67,  # Replace with actual upper BB
#             lowerBB=1875.31,  # Replace with actual lower BB
#             st21UP=1880.0,  # Replace with actual st21UP value
#             st21DN=1870.0,  # Replace with actual st21DN value
#             support=s1,
#             resistance=r1
#         )

#         # Filter out signals that are true
#         true_signals = {k: v for k, v in signals.items() if v}

#         # Prepare data for CSV
#         result_data.append({
#             'Ticker': ticker,
#             'Pivot': pivot,
#             'R1': r1,
#             'R2': r2,
#             'R3': r3,
#             'S1': s1,
#             'S2': s2,
#             'S3': s3,
#             'True_Signals': true_signals
#         })

#         # Display data
#         print(f"Ticker: {ticker}, Pivot: {pivot}, R1: {r1}, R2: {r2}, R3: {r3}, S1: {s1}, S2: {s2}, S3: {s3},  Signals: {true_signals}")
#         return pivot, r1, r2, r3, s1, s2, s3


# # Function to process tickers and save pivot points and true signals in CSV
# def process_and_save_pivots(ticker_list):
#     result_data = []

#     for ticker in ticker_list:
#         # Fetch OHLC data
#         stock_df = fetchOHLC2(ticker, "15", 1)
#         if stock_df.empty:
#             continue  # Skip if no data is returned

#         # Ensure 'Timestamp2' is set as the index
#         stock_df['Timestamp2'] = pd.to_datetime(stock_df['Timestamp2'])
#         stock_df.set_index('Timestamp2', inplace=True)

#         # Resample to daily OHLC
#         daily_df = stock_df.resample('D').agg({
#             'Open': 'first', 
#             'High': 'max', 
#             'Low': 'min', 
#             'Close': 'last', 
#             'Volume': 'sum'
#         })
#         daily_df.dropna(inplace=True)

#         # Calculate pivot points
#         pivot, r1, r2, r3, s1, s2, s3 = pivotpoints_today(daily_df)

#         # Get dynamic signals from market data
#         st21Buy, st21Sell, haGreen, haRed = get_dynamic_signals(daily_df)

#         # Use the signal function from the imported module
#         signals = signal(
#             ema5=daily_df["Close"].ewm(span=5).mean().iloc[-1],
#             ema21=daily_df["Close"].ewm(span=21).mean().iloc[-1],
#             st21Buy=st21Buy,  # Use dynamic conditions
#             st21Sell=st21Sell,  # Use dynamic conditions
#             st21Trend=1 if st21Buy else -1,  # Example: 1 for Buy, -1 for Sell
#             haGreen=haGreen,  # Use dynamic conditions
#             haRed=haRed,  # Use dynamic conditions
#             close=daily_df['Close'].iloc[-1],
#             upperBB=1883.67,  # Replace with actual upper BB
#             lowerBB=1875.31,  # Replace with actual lower BB
#             st21UP=1880.0,  # Replace with actual st21UP value
#             st21DN=1870.0,  # Replace with actual st21DN value
#             support=s1,
#             resistance=r1
#         )

#         # Filter out signals that are true
#         true_signals = {k: v for k, v in signals.items() if v}

#         # Prepare data for CSV
#         result_data.append({
#             'Ticker': ticker,
#             'Pivot': pivot,
#             'R1': r1,
#             'R2': r2,
#             'R3': r3,
#             'S1': s1,
#             'S2': s2,
#             'S3': s3,
#             'True_Signals': true_signals
#         })

#         # Display data
#         print(f"Ticker: {ticker}, Pivot: {pivot}, R1: {r1}, R2: {r2}, R3: {r3}, S1: {s1}, S2: {s2},S3: {s3},  Signals: {true_signals}")
#         return pivot, r1, r2, r3, s1, s2, s3

    # Save to CSV


# Example of reading from CSV and calling the function
#ticker_list = pd.read_csv('top_gainers_symbols.csv')['Symbol'].tolist()
# ticker_list = ["MCX:NATURALGAS24DEC250PE"]
# process_and_save_pivots(ticker_list)

# import json

# def process_and_save_pivots(ticker_list):
#     result_data = []  # For CSV
#     json_data = {}    # For JSON

#     for ticker in ticker_list:
#         # Fetch OHLC data
#         stock_df = fetchOHLC2(ticker, "15", 1)
#         if stock_df.empty:
#             continue  # Skip if no data is returned

#         # Ensure 'Timestamp2' is set as the index
#         stock_df['Timestamp2'] = pd.to_datetime(stock_df['Timestamp2'])
#         stock_df.set_index('Timestamp2', inplace=True)

#         # Resample to daily OHLC
#         daily_df = stock_df.resample('D').agg({
#             'Open': 'first', 
#             'High': 'max', 
#             'Low': 'min', 
#             'Close': 'last', 
#             'Volume': 'sum'
#         })
#         daily_df.dropna(inplace=True)

#         # Calculate pivot points
#         pivot, r1, r2, r3, s1, s2, s3 = pivotpoints_today(daily_df)

#         # Get dynamic signals from market data
#         st21Buy, st21Sell, haGreen, haRed = get_dynamic_signals(daily_df)

#         # Use the signal function from the imported module
#         signals = signal(
#             ema5=daily_df["Close"].ewm(span=5).mean().iloc[-1],
#             ema21=daily_df["Close"].ewm(span=21).mean().iloc[-1],
#             st21Buy=st21Buy,  # Use dynamic conditions
#             st21Sell=st21Sell,  # Use dynamic conditions
#             st21Trend=1 if st21Buy else -1,  # Example: 1 for Buy, -1 for Sell
#             haGreen=haGreen,  # Use dynamic conditions
#             haRed=haRed,  # Use dynamic conditions
#             close=daily_df['Close'].iloc[-1],
#             upperBB=1883.67,  # Replace with actual upper BB
#             lowerBB=1875.31,  # Replace with actual lower BB
#             st21UP=1880.0,  # Replace with actual st21UP value
#             st21DN=1870.0,  # Replace with actual st21DN value
#             support=s1,
#             resistance=r1
#         )

#         # Filter out signals that are true
#         true_signals = {k: v for k, v in signals.items() if v}

#         # Prepare data for CSV
#         result_data.append({
#             'Ticker': ticker,
#             'Pivot': pivot,
#             'R1': r1,
#             'R2': r2,
#             'R3': r3,
#             'S1': s1,
#             'S2': s2,
#             'S3': s3,
#             'True_Signals': true_signals
#         })

#         # Prepare data for JSON
#         json_data[ticker] = {
#             'Pivot': pivot,
#             'Resistance Levels': {'R1': r1, 'R2': r2, 'R3': r3},
#             'Support Levels': {'S1': s1, 'S2': s2, 'S3': s3},
#             'True Signals': {k: int(v) for k, v in true_signals.items()}  # Convert bool to int
#         }

#         # Display data
#         print(f"Ticker: {ticker}, Pivot: {pivot}, R1: {r1}, R2: {r2}, R3: {r3}, S1: {s1}, S2: {s2},S3: {s3},  Signals: {true_signals}")
        
    

#     # Save to CSV
#     df_result = pd.DataFrame(result_data)
#     df_result.to_csv('top_symbols_pivot.csv', index=False)

#     # # Save to JSON
#     # with open('pivot_data.json', 'w') as json_file:
#     #     json.dump(json_data, json_file, indent=4)


# # Example of reading from CSV and calling the function
# #ticker_list = pd.read_csv('top_gainers_symbols.csv')['Symbol'].tolist()
# # ticker_list = ["MCX:NATURALGAS24DEC250PE"]
# # process_and_save_pivots(ticker_list)

