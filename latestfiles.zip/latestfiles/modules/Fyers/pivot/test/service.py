import pandas as pd
import datetime as dt
import pytz
from fyers_apiv3 import fyersModel
from modules.Fyers.signal.service import signal
import numpy as np
import json

# Generate trading session
client_id = open("client_id.txt", 'r').read()
access_token = open("access_token.txt", 'r').read()

# Initialize the FyersModel instance
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")



# Function to fetch OHLC data
def fetchOHLC2(ticker, interval, duration):
    range_from = dt.date.today() - dt.timedelta(days=duration)
    range_to = dt.date.today()

    from_date_string = range_from.strftime("%Y-%m-%d")
    to_date_string = range_to.strftime("%Y-%m-%d")
    data = {
        "symbol": ticker,
        "resolution": interval,
        "date_format": "1",
        "range_from": from_date_string,
        "range_to": to_date_string,
        "cont_flag": "1"
    }

    response = fyers.history(data=data)
    
    # Check if 'candles' is in the response
    if 'candles' not in response:
        print(f"Error fetching data for {ticker}: {response}")
        return pd.DataFrame()  # Return an empty DataFrame if the response is invalid

    # Create a DataFrame
    columns = ['Timestamp', 'Open', 'High', 'Low', 'Close', 'Volume']
    df = pd.DataFrame(response['candles'], columns=columns)

    # Convert Timestamp to datetime in UTC and then to IST
    df['Timestamp2'] = pd.to_datetime(df['Timestamp'], unit='s').dt.tz_localize(pytz.utc)
    df['Timestamp2'] = df['Timestamp2'].dt.tz_convert('Asia/Kolkata')

    return df

# # Function to calculate pivot points and supports/resistances
# def pivotpoints_today(ohlc_day):
#     """Returns pivot point and support/resistance levels."""
#     high = round(ohlc_day["High"].iloc[-1], 2)
#     low = round(ohlc_day["Low"].iloc[-1], 2)
#     close = round(ohlc_day["Close"].iloc[-1], 2)
    
#     pivot = round((high + low + close) / 3, 2)
#     r1 = round((2 * pivot - low), 2)
#     r2 = round((pivot + (high - low)), 2)
#     r3 = round((high + 2 * (pivot - low)), 2)
#     s1 = round((2 * pivot - high), 2)
#     s2 = round((pivot - (high - low)), 2)
#     s3 = round((low - 2 * (high - pivot)), 2)

#     return pivot, r1, r2, r3, s1, s2, s3

# Function to calculate pivot points and CPR
def pivotpoints_today(ohlc_day):
    """Returns pivot point, CPR (TC, BC), and support/resistance levels."""
    high = round(ohlc_day["High"].iloc[-1], 2)
    low = round(ohlc_day["Low"].iloc[-1], 2)
    close = round(ohlc_day["Close"].iloc[-1], 2)
    
    PP = round((high + low + close) / 3, 2)  # Pivot Point
    TC = round((PP + high) / 2, 2)  # Top Central Pivot
    BC = round((PP + low) / 2, 2)   # Bottom Central Pivot

    # Support & Resistance levels
    R1 = round((2 * PP - low), 2)
    R2 = round((PP + (high - low)), 2)
    R3 = round((high + 2 * (PP - low)), 2)
    S1 = round((2 * PP - high), 2)
    S2 = round((PP - (high - low)), 2)
    S3 = round((low - 2 * (high - PP)), 2)

    return high, low, close, PP, TC, BC, R1, R2, R3, S1, S2, S3


# Function to dynamically set buy/sell/hold signals
def get_dynamic_signals(df):
    ema5 = df["Close"].ewm(span=5).mean().iloc[-1]
    ema21 = df["Close"].ewm(span=21).mean().iloc[-1]
    close = df['Close'].iloc[-1]

    # Define actual conditions based on indicators
    st21Buy = close > ema21  # Buy condition if the close is above EMA 21
    st21Sell = close < ema21  # Sell condition if the close is below EMA 21
    haGreen = st21Buy  # Replace with actual Heikin-Ashi Green logic
    haRed = st21Sell   # Replace with actual Heikin-Ashi Red logic

    return st21Buy, st21Sell, haGreen, haRed
# Function to convert non-serializable objects (e.g., numpy types) to Python types
def convert_to_serializable(obj):
    if isinstance(obj, np.bool_):
        return bool(obj)  # Convert numpy boolean to Python boolean
    elif isinstance(obj, np.integer):
        return int(obj)  # Convert numpy integer to Python integer
    elif isinstance(obj, np.floating):
        return float(obj)  # Convert numpy floating-point to Python float
    elif isinstance(obj, pd.Timestamp):
        return obj.isoformat()  # Convert pandas Timestamp to ISO format
    else:
        return obj


# Function to convert dictionaries or lists to serializable formats
def convert_dict_to_serializable(data):
    if isinstance(data, dict):
        return {k: convert_dict_to_serializable(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [convert_dict_to_serializable(v) for v in data]
    else:
        return convert_to_serializable(data)


# Function to save pivot data to a JSON file
def save_pivot_data(data, json_filename):
    try:
        serializable_data = convert_dict_to_serializable(data)  # Convert data to serializable format
        with open(json_filename, 'w') as file:
            json.dump(serializable_data, file, indent=4)  # Save the serializable data to the JSON file
        print(f"Pivot data successfully saved to {json_filename}")
    except Exception as e:
        print(f"Error saving pivot data: {e}")


# Function to process tickers and save pivots + CPR
def process_and_save_pivots(ticker_list):
    all_pivot_data = {}
    
    for ticker in ticker_list:
        print(f"Processing ticker: {ticker}")
        stock_df = fetchOHLC2(ticker, "15", 1)
        if stock_df.empty:
            print(f"No data found for ticker: {ticker}. Skipping...")
            continue
        
        stock_df['Timestamp2'] = pd.to_datetime(stock_df['Timestamp2'])
        stock_df.set_index('Timestamp2', inplace=True)
        
        daily_df = stock_df.resample('D').agg({
            'Open': 'first', 
            'High': 'max', 
            'Low': 'min', 
            'Close': 'last', 
            'Volume': 'sum'
        })
        daily_df.dropna(inplace=True)
        
        if daily_df.empty:
            print(f"No daily data available for ticker: {ticker}. Skipping...")
            continue
        
        try:
            high, low, close, PP, TC, BC, R1, R2, R3, S1, S2, S3 = pivotpoints_today(daily_df)
            
            pivot_data = {
                'timestamp': pd.Timestamp.now().isoformat(),
                'High': float(high),  # ✅ Added High value
                'Low': float(low),  
                'close': float(close),  # ✅ Added Low value
                'PP': float(PP),
                'TC': float(TC),
                'BC': float(BC),
                'R1': float(R1),
                'R2': float(R2),
                'R3': float(R3),
                'S1': float(S1),
                'S2': float(S2),
                'S3': float(S3)
            }
            
            all_pivot_data[ticker] = pivot_data
        
        except Exception as e:
            print(f"Error calculating pivot points for ticker {ticker}: {e}")
    
    return all_pivot_data


# def process_and_save_pivots(ticker_list):
#     all_pivot_data = {}

#     for ticker in ticker_list:
#         print(f"Processing ticker: {ticker}")
#         # Fetch OHLC data
#         stock_df = fetchOHLC2(ticker, "15", 1)
#         if stock_df.empty:
#             print(f"No data found for ticker: {ticker}. Skipping...")
#             continue  # Skip if no data is returned

#         # Ensure 'Timestamp2' is set as the index
#         stock_df['Timestamp2'] = pd.to_datetime(stock_df['Timestamp2'])
#         stock_df.set_index('Timestamp2', inplace=True)

#         # Resample to daily OHLC
#         daily_df = stock_df.resample('D').agg({
#             'Open': 'first', 
#             'High': 'max', 
#             'Low': 'min', 
#             'Close': 'last', 
#             'Volume': 'sum'
#         })
#         daily_df.dropna(inplace=True)

#         # Check if daily_df is empty after resampling
#         if daily_df.empty:
#             print(f"No daily data available for ticker: {ticker}. Skipping...")
#             continue

#         # Calculate pivot points
#         try:
#             pivot, r1, r2, r3, s1, s2, s3 = pivotpoints_today(daily_df)

#             # Convert all pivot points to plain floats
#             pivot, r1, r2, r3, s1, s2, s3 = (
#                 float(pivot), float(r1), float(r2), float(r3),
#                 float(s1), float(s2), float(s3)
#             )

#             # Save pivot data in a structured format
#             pivot_data = {
#                 'timestamp': pd.Timestamp.now().isoformat(),
#                 'pivot': pivot,
#                 'r1': r1,
#                 'r2': r2,
#                 'r3': r3,
#                 's1': s1,
#                 's2': s2,
#                 's3': s3
#             }

#             # Save by ticker
#             all_pivot_data[ticker] = pivot_data
#             # print(f"Pivot data for {ticker}: {pivot_data}")

#         except Exception as e:
#             print(f"Error calculating pivot points for ticker {ticker}: {e}")
#     return all_pivot_data


# import time
# # Function to continuously fetch pivot data and refresh the JSON file
# def run_save_pivot_data_every_minute(ticker_list, json_filename):
#     while True:
#         print(f"Fetching and saving pivot data at {pd.Timestamp.now().isoformat()}")
#         try:
#             all_pivot_data = process_and_save_pivots(ticker_list)
#             if all_pivot_data:
#                 save_pivot_data(all_pivot_data, json_filename)
#             else:
#                 print("No pivot data to save.")
#         except Exception as e:
#             print(f"Error during pivot data refresh: {e}")

#         # Wait for 60 seconds before fetching data again
#         time.sleep(1)
 