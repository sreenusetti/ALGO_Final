import pandas as pd
import datetime as dt
import pytz
from fyers_apiv3 import fyersModel
import numpy as np
import json
import time

# Generate trading session
client_id = open("client_id.txt", 'r').read()
access_token = open("access_token.txt", 'r').read()

# Initialize the FyersModel instance
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")

# Function to fetch OHLC data
def fetchOHLC(ticker, interval, duration):
    range_from = dt.date.today() - dt.timedelta(days=duration)
    range_to = dt.date.today()
    
    data = {
        "symbol": ticker,
        "resolution": interval,
        "date_format": "1",
        "range_from": range_from.strftime("%Y-%m-%d"),
        "range_to": range_to.strftime("%Y-%m-%d"),
        "cont_flag": "1"
    }
    response = fyers.history(data=data)
    
    if 'candles' not in response:
        print(f"Error fetching data for {ticker}: {response}")
        return pd.DataFrame()
    
    columns = ['Timestamp', 'Open', 'High', 'Low', 'Close', 'Volume']
    df = pd.DataFrame(response['candles'], columns=columns)
    df['Timestamp'] = pd.to_datetime(df['Timestamp'], unit='s').dt.tz_localize(pytz.utc).dt.tz_convert('Asia/Kolkata')
    return df

# Function to calculate Pivot Points and CPR
def calculate_pivot_cpr(ohlc_day):
    high = round(ohlc_day["High"].iloc[-1], 2)
    low = round(ohlc_day["Low"].iloc[-1], 2)
    close = round(ohlc_day["Close"].iloc[-1], 2)
    
    pivot = round((high + low + close) / 3, 2)
    bc = round((high + low) / 2, 2)
    tc = round((pivot - bc) + pivot, 2)
    
    r1, r2, r3 = round(2 * pivot - low, 2), round(pivot + (high - low), 2), round(high + 2 * (pivot - low), 2)
    s1, s2, s3 = round(2 * pivot - high, 2), round(pivot - (high - low), 2), round(low - 2 * (high - pivot), 2)
    
    return {
        "pivot": pivot, "r1": r1, "r2": r2, "r3": r3,
        "s1": s1, "s2": s2, "s3": s3,
        "tc": tc, "bc": bc  # CPR values
    }

# Function to process tickers and save CPR
def process_and_save_pivots(ticker_list, json_filename):
    all_pivot_data = {}
    for ticker in ticker_list:
        print(f"Processing ticker: {ticker}")
        
        stock_df = fetchOHLC(ticker, "D", 2)  # Fetch daily OHLC for last 2 days
        if stock_df.empty:
            print(f"No data for {ticker}. Skipping...")
            continue
        
        yesterday_data = stock_df.iloc[-2]  # Use previous day's OHLC
        pivot_data = calculate_pivot_cpr(pd.DataFrame([yesterday_data]))
        pivot_data['timestamp'] = pd.Timestamp.now().isoformat()
        
        all_pivot_data[ticker] = pivot_data
    
    with open(json_filename, 'w') as file:
        json.dump(all_pivot_data, file, indent=4)
    print(f"Pivot & CPR data saved to {json_filename}")

# Run the function every minute
def run_save_pivot_data_every_minute(ticker_list, json_filename):
    while True:
        print(f"Fetching and saving pivot data at {pd.Timestamp.now().isoformat()}")
        try:
            process_and_save_pivots(ticker_list, json_filename)
        except Exception as e:
            print(f"Error during pivot data refresh: {e}")
        time.sleep(60)

# Example usage:
# run_save_pivot_data_every_minute(["NSE:INFY-EQ", "NSE:RELIANCE-EQ"], "pivot_data.json")
