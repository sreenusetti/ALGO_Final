"""
Created By: Aseem Singhal
Fyers API V3

"""

import datetime as dt
from fyers_apiv3 import fyersModel
import pandas as pd
import pytz

#generate trading session
client_id = open("client_id.txt",'r').read()
access_token = open("access_token.txt",'r').read()

# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")



"""
Created By: Aseem Singhal
Fyers API V3
"""

import datetime as dt
from fyers_apiv3 import fyersModel
import pandas as pd
import pytz

# Load credentials
def load_credentials():
    client_id = open("client_id.txt", 'r').read().strip()
    access_token = open("access_token.txt", 'r').read().strip()
    return client_id, access_token

# Initialize the FyersModel instance
def initialize_fyers(client_id, access_token):
    return fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")

# Fetch OHLC data
def fetchOHLC2(fyers, ticker, interval, duration):
    range_from = dt.date.today() - dt.timedelta(days=duration)
    range_to = dt.date.today()

    data = {
        "symbol": ticker,
        "resolution": interval,
        "date_format": "1",
        "range_from": range_from.strftime("%Y-%m-%d"),
        "range_to": range_to.strftime("%Y-%m-%d"),
        "cont_flag": "1"
    }
    
    response = fyers.history(data=data)['candles']
    columns = ['Timestamp', 'Open', 'High', 'Low', 'Close', 'Volume']
    df = pd.DataFrame(response, columns=columns)
    
    # Convert timestamp to IST timezone
    df['Timestamp2'] = pd.to_datetime(df['Timestamp'], unit='s').dt.tz_localize(pytz.utc).dt.tz_convert('Asia/Kolkata')
    df.drop(columns=['Timestamp'], inplace=True)
    df.set_index('Timestamp2', inplace=True)
    
    return df

# Calculate pivot points and support/resistance levels
def calculate_pivot_points(ohlc_day):
    high = round(ohlc_day["High"].iloc[-1], 2)
    low = round(ohlc_day["Low"].iloc[-1], 2)
    close = round(ohlc_day["Close"].iloc[-1], 2)
    pivot = round((high + low + close) / 3, 2)
    r1 = round((2 * pivot - low), 2)
    r2 = round((pivot + (high - low)), 2)
    r3 = round((high + 2 * (pivot - low)), 2)
    s1 = round((2 * pivot - high), 2)
    s2 = round((pivot - (high - low)), 2)
    s3 = round((low - 2 * (high - pivot)), 2)
    return pivot, r1, r2, r3, s1, s2, s3

# Main function to execute the workflow
def main(ticker, interval, duration):
    client_id, access_token = load_credentials()
    fyers = initialize_fyers(client_id, access_token)
    
    # Fetch OHLC data
    stock_df = fetchOHLC2(fyers, ticker, interval, duration)
    print(stock_df)

    # Resample daily data and calculate pivot points
    daily_df = stock_df.resample('D').agg({'Open': 'first', 'High': 'max', 'Low': 'min', 'Close': 'last', 'Volume': 'sum'}).dropna()
    print(daily_df)

    pivot, r1, r2, r3, s1, s2, s3 = calculate_pivot_points(daily_df)
    print(f"Pivot of today: {pivot}")
    print(f"R1: {r1}, S1: {s1}")
    print(f"R2: {r2}, S2: {s2}")
    print(f"R3: {r3}, S3: {s3}")

# # Example usage
# if __name__ == "__main__":
#     main(ticker="NSE:SBIN-EQ", interval="30", duration=100)
