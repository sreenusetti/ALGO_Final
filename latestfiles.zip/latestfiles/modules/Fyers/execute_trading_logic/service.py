
import pandas as pd
from fyers_apiv3 import fyersModel
from modules.Fyers.service import save_to_json, load_from_json, fetchOHLC2, bollinger_bands, ema, atr, supertrend
from modules.Fyers.placeorder.service import placeOrder
from modules.Fyers.signal.service import signal

import datetime as dt
import pytz
import numpy as np
import time

import json
import os

#generate trading session
client_id = open("client_id.txt",'r').read()
access_token = open("access_token.txt",'r').read()
# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")





# Function to load existing order data (if any) from JSON
def load_order_data(json_filename):
    try:
        with open(json_filename, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return {}  # Return an empty dict if no data exists
    

# Function to save order information to JSON
def save_order_data(order_data, json_filename):
    with open(json_filename, 'w') as file:
        json.dump(order_data, file, indent=4)


#def execute_trading_logic(ohlc, ticker, json_filename='placed_orders.json''indicator_values.json'):
def execute_trading_logic(ohlc, ticker, json_filename='placed_orders.json'):
    order_data = load_order_data(json_filename)
    
    

    # Fetch the last values for calculations
    close = ohlc['Close'].iloc[-1]
    ema_5 = ema(ohlc, window=5)['EMA5'].iloc[-1]  # Calculate EMA5
    ema_21 = ohlc['EMA21'].iloc[-1]
    upper_bb = ohlc['BB_upper'].iloc[-1]
    lower_bb = ohlc['BB_lower'].iloc[-1]
    st21Buy = ohlc['st1'].iloc[-1] < close
    st21Sell = ohlc['st1'].iloc[-1] > close
    st21Trend = 1 if st21Buy else -1  # Simplified trend logic
    st21UP = ohlc['st1'].iloc[-1]
    st21DN = ohlc['st1'].iloc[-1]
    haGreen = True  # Assuming Heiken-Ashi calculation (dummy value)
    haRed = False   # Assuming Heiken-Ashi calculation (dummy value)
    support = lower_bb  # Simplified logic
    resistance = upper_bb  # Simplified logic

    # Ensure all comparisons are valid floats
    try:
        close = float(close) if close is not None else 0.0
        upper_bb = float(upper_bb) if upper_bb is not None else 0.0
        lower_bb = float(lower_bb) if lower_bb is not None else 0.0
        ema_5 = float(ema_5) if ema_5 is not None else 0.0
        ema_21 = float(ema_21) if ema_21 is not None else 0.0
    except ValueError as e:
        print(f"ValueError encountered: {e}")
        return  # Exit if any conversion fails

    # Define quantity and LTP
    qty = 1
    ltp = close

    # Call the signal function
    signals = signal(ema_5, ema_21, st21Buy, st21Sell, st21Trend, haGreen, haRed, close, upper_bb, lower_bb, st21UP, st21DN, support, resistance)

    # Save indicator data
    indicator_data = {
        'close': close,
        'ema_5': ema_5,
        'ema_21': ema_21,
        'upper_bb': upper_bb,
        'lower_bb': lower_bb,
        'st21Buy': st21Buy,
        'st21Sell': st21Sell,
        'st21Trend': st21Trend,
        'signals': signals
    }

    
    # Check for buy signal and place buy order
    if st21Trend == 1 :
        print(f"Placing BUY order for {ticker}")
        orderid = placeOrder(ticker, "BUY", qty, "MARKET", ltp)
        if orderid:
            order_data[ticker] = {"order_id": orderid, "type": "BUY", "ltp": ltp}

    # Check for sell signal and place sell order (exit from buy position)
    elif st21Trend == -1 :
        print(f"Exiting BUY, placing SELL for {ticker}")
        orderid = placeOrder(ticker, "SELL", qty, "MARKET", ltp)
        if orderid:
            order_data[ticker] = {"order_id": orderid, "type": "SELL", "ltp": ltp}


    # Save the updated order data to JSON
    save_order_data(order_data, json_filename)
