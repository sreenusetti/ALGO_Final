
import pandas as pd
from fyers_apiv3 import fyersModel
 



# Generate trading session
client_id = open("client_id.txt", 'r').read()
access_token = open("access_token.txt", 'r').read()

# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")


 

def get_open_position():
    """
    Fetch all open positions using fyers API and return as a DataFrame.
    """
    position_response = fyers.positions()  # Fetch all positions
    if position_response.get('netPositions'):  # Check if 'netPositions' exists and has data
        position_df = pd.DataFrame(position_response['netPositions'])
    else:
        position_df = pd.DataFrame()  # Return empty DataFrame if no positions
    return position_df


def close_ticker_position(name):
    """
    Close a position for a given symbol (name).
    
    Args:
    - name (str): The symbol name to close the position for.
    """
    position_df = get_open_position()  # Get all open positions

    

    # Check if the DataFrame is not empty and if the symbol exists in the DataFrame
    if not position_df.empty and name in position_df['symbol'].to_list():
        # Extract the position ID for the given symbol
        position_id = position_df[position_df['symbol'] == name]['id'].iloc[0]

        # Prepare the data payload with the extracted position ID
        data = {"id": position_id}
        print(f"Closing position for {name} with ID: {position_id}")

        # Call fyers API to exit the position
        response = fyers.exit_positions(data=data)
        print("API Response:", response)

        # Check the API response
        if response.get("s") == "ok":
            print(f"Successfully closed position for-----working {name}.")
        else:
            print(f"Failed to close position for {name}. Response: {response}")
    else:
        print(f"Position does not exist for {name}.")


# # Example Usage
# # Make sure `fyers` is properly authenticated before calling these functions
# symbol_name = "MCX:CRUDEOIL24DEC6300CE"  # Replace with your symbol
# close_ticker_position(symbol_name)
