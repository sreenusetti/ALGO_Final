

import pandas as pd
from fyers_apiv3 import fyersModel
import datetime as dt
import pytz
import numpy as np
import time

import json
import os

#generate trading session
client_id = open("client_id.txt",'r').read()
access_token = open("access_token.txt",'r').read()
# Initialize the FyersModel instance with your client_id, access_token, and enable async mode
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")




# # Example structure for the signal function based on your conditions

# def signal(ema5, ema21, st21Buy, st21Sell, st21Trend, haGreen, haRed, close, upperBB, lowerBB, st21UP, st21DN, support, resistance):
#     buy_signal = False
#     sell_signal = False
#     best_buy_signal = False
#     best_sell_signal = False
#     strong_buy_signal = False
#     strong_sell_signal = False
#     exit_buy_signal = False
#     exit_sell_signal = False
#     exit_best_buy_signal = False
#     exit_best_sell_signal = False
#     exit_strong_buy_signal = False
#     exit_strong_sell_signal = False

#     # 1. Regular Buy/Sell
#     if st21Buy and not buy_signal:  # Regular Buy Condition
#         buy_signal = True
#     elif st21Sell and not sell_signal:  # Regular Sell Condition
#         sell_signal = True

#     # Exit Buy Condition
#     if st21Trend == -1 or (close < resistance and haRed):
#         buy_signal = False
    
#     # Exit Sell Condition
#     if st21Trend == 1 or (close > support and haGreen):
#         sell_signal = False

#     # 2. Best Buy/Sell
#     if ema5 > ema21 and st21Trend == 1:  # Best Buy Condition
#         best_buy_signal = True
#     elif ema5 < ema21 and st21Trend == -1:  # Best Sell Condition
#         best_sell_signal = True

#     # Exit Best Buy
#     if ema5 < ema21 or st21Trend == -1:
#         best_buy_signal = False
    
#     # Exit Best Sell
#     if ema5 > ema21 or st21Trend == 1:
#         best_sell_signal = False

#     # 3. Strong Buy/Sell
#     if ema5 > st21UP and close > upperBB:  # Strong Buy Condition
#         strong_buy_signal = True
#     elif ema5 < st21DN and close < lowerBB:  # Strong Sell Condition
#         strong_sell_signal = True

#     # Exit Strong Buy
#     if ema5 < ema21 and st21Trend == -1:
#         strong_buy_signal = False
    
#     # Exit Strong Sell
#     if ema5 > ema21 and st21Trend == 1:
#         strong_sell_signal = False






#     # Return all signals
#     return {
#         'buy_signal': buy_signal,
#         'sell_signal': sell_signal,
#         'best_buy_signal': best_buy_signal,
#         'best_sell_signal': best_sell_signal,
#         'strong_buy_signal': strong_buy_signal,
#         'strong_sell_signal': strong_sell_signal
#     }

def signal(
    ema5, ema21, st21Buy, st21Sell, st21Trend, haGreen, haRed, close, 
    upperBB, lowerBB, st21UP, st21DN, support, resistance
):
    # Initialize all signals
    buy_signal = False
    sell_signal = False
    best_buy_signal = False
    best_sell_signal = False
    strong_buy_signal = False
    strong_sell_signal = False
    exit_buy_signal = False
    exit_sell_signal = False
    exit_best_buy_signal = False
    exit_best_sell_signal = False
    exit_strong_buy_signal = False
    exit_strong_sell_signal = False

    # 1. Regular Buy/Sell
    if st21Buy:
        buy_signal = True
    elif st21Sell:
        sell_signal = True

    # Exit Regular Buy
    if buy_signal and (st21Trend == -1 or (close < resistance and haRed)):
        exit_buy_signal = True
        buy_signal = False

    # Exit Regular Sell
    if sell_signal and (st21Trend == 1 or (close > support and haGreen)):
        exit_sell_signal = True
        sell_signal = False

    # 2. Best Buy/Sell
    if ema5 > ema21 and st21Trend == 1:
        best_buy_signal = True
    elif ema5 < ema21 and st21Trend == -1:
        best_sell_signal = True

    # Exit Best Buy
    if best_buy_signal and (ema5 < ema21 or st21Trend == -1):
        exit_best_buy_signal = True
        best_buy_signal = False

    # Exit Best Sell
    if best_sell_signal and (ema5 > ema21 or st21Trend == 1):
        exit_best_sell_signal = True
        best_sell_signal = False

    # 3. Strong Buy/Sell
    if ema5 > st21UP and close > upperBB:  # Strong Buy Condition
        strong_buy_signal = True
    elif ema5 < st21DN and close < lowerBB:  # Strong Sell Condition
        strong_sell_signal = True

    # Exit Strong Buy
    if strong_buy_signal and (ema21 > close or st21Trend == -1):
        exit_strong_buy_signal = True
        strong_buy_signal = False

    # Exit Strong Sell
    if strong_sell_signal and (ema21 < close or st21Trend == 1):
        exit_strong_sell_signal = True
        strong_sell_signal = False

    # Return all signals
    return {
        'buy_signal': buy_signal,
        'sell_signal': sell_signal,
        'best_buy_signal': best_buy_signal,
        'best_sell_signal': best_sell_signal,
        'strong_buy_signal': strong_buy_signal,
        'strong_sell_signal': strong_sell_signal,
        'exit_buy_signal': exit_buy_signal,
        'exit_sell_signal': exit_sell_signal,
        'exit_best_buy_signal': exit_best_buy_signal,
        'exit_best_sell_signal': exit_best_sell_signal,
        'exit_strong_buy_signal': exit_strong_buy_signal,
        'exit_strong_sell_signal': exit_strong_sell_signal
    }
