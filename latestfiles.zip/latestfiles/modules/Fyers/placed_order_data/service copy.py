import pandas as pd
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws
from modules.Fyers.service import save_to_json, load_from_json, fetchOHLC2, bollinger_bands, ema, atr, supertrend
from modules.Fyers.placeorder.service import placeOrder
from modules.Fyers.signal.service import signal
from modules.Fyers.save_indicator_data.service import save_indicator_data
from modules.Fyers.HA.service import calculate_heikin_ashi
from modules.Fyers.trend.service import trend # Import from candels_trend.py
from modules.Fyers.placeorder.placeorder_BO.service import placeOrderBracket

import datetime as dt
import pytz
import numpy as np
import time
import json
import os
import contextlib
import datetime

# Paths for JSON files
indicator_json_path = 'indicator_values.json'
updated_json_path = 'updated_indicator_values.json'
output_txt_path = 'output.txt'  # Path for the output data file
output_terminal_path = 'output_terminal.txt'  # Path for the terminal output file

# Initialize the FyersModel instance
client_id = open("client_id.txt", 'r').read().strip()
access_token = open("access_token.txt", 'r').read().strip()
fyers = fyersModel.FyersModel(client_id=client_id, is_async=True, token=access_token, log_path="")

# Function to load JSON data from a file
def load_json_data(json_filename):
    try:
        with open(json_filename, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        log_message(f"File not found: {json_filename}")
        return None
    except json.JSONDecodeError as e:
        log_message(f"Error decoding JSON from {json_filename}: {e}")
        return None

# Function to save indicator data to JSON
def save_indicator_data(data, json_filename):
    with open(json_filename, 'w') as file:
        json.dump(data, file, indent=4)

# Function to save output to a text file
def save_output_to_txt(output, file_path):
    with open(file_path, 'a') as file:  # Open in append mode
        file.write(output + '\n')

# Function to log messages and save to terminal output file
def log_message(message):
    print(message)  # Print to console
    save_output_to_txt(message, output_terminal_path)  # Save to terminal output file

# Function to convert non-serializable objects (e.g., numpy types) to Python types
def convert_to_serializable(obj):
    if isinstance(obj, np.bool_):
        return bool(obj)
    elif isinstance(obj, np.integer):
        return int(obj)
    elif isinstance(obj, np.floating):
        return float(obj)
    else:
        return obj

# Function to convert dictionaries or lists to serializable formats
def convert_dict_to_serializable(data):
    if isinstance(data, dict):
        return {k: convert_dict_to_serializable(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [convert_dict_to_serializable(v) for v in data]
    else:
        return convert_to_serializable(data)

# Function to handle order placement based on st21Trend and Heikin-Ashi trend
def place_order_based_on_trend(all_timeframe_data):
    try:
        st21_1min = all_timeframe_data['1min']['st21Trend']
        st21_5min = all_timeframe_data['5min']['st21Trend']

        ha_trend_1min = all_timeframe_data['1min']['ha_trend']
        ha_trend_5min = all_timeframe_data['5min']['ha_trend']

        # Check if all timeframes have st21Trend = 1 and Heikin-Ashi green for a BUY order
        if st21_1min == 1 and st21_5min == 1 and ha_trend_1min == 'green' and ha_trend_5min == 'green':
            order_message = "BUY condition met. Placing a BUY order."
            log_message(order_message)
           # placeOrder(inst="NSE:INFY-EQ", t_type="BUY", qty=20, order_type="MARKET")
            placeOrderBracket(inst="symbols" ,t_type="BUY",qty=20,order_type="MARKET", targetPrice=10, slPrice=5)

        # Check if all timeframes have st21Trend = -1 and Heikin-Ashi red for a SELL order
        elif st21_1min == -1 and st21_5min == -1 and ha_trend_1min == 'red' and ha_trend_5min == 'red':
            order_message = "SELL condition met. Placing a SELL order."
            log_message(order_message)
            #placeOrder(inst="NSE:INFY-EQ", t_type="SELL", qty=20, order_type="MARKET")
            placeOrderBracket(inst="symbols" ,t_type="SELL",qty=20,order_type="MARKET", targetPrice=10, slPrice=5)

    except KeyError as ke:
        log_message(f"KeyError when accessing timeframe data: {ke}")
    except Exception as e:
        log_message(f"Error during order placement: {e}")