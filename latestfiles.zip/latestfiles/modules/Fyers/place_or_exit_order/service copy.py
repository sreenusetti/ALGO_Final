import pandas as pd
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws
from modules.Fyers.service import save_to_json, load_from_json, fetchOHLC2, bollinger_bands, ema, atr, supertrend
from modules.Fyers.placeorder.placeorder_BO.service import placeOrderBracket
from modules.Fyers.signal.service import signal
from modules.Fyers.save_indicator_data.service import save_indicator_data
from modules.Fyers.placeorder.service import placeOrder
#from modules.Fyers.save_indicator_data_every_min.service import run_save_indicator_data_every_minute


from modules.Fyers.placeorder.placeorderall.service import placeOrder, modifyOrder, cancelOrder
import datetime as dt
import pytz
import numpy as np
import time
import json
import os
import contextlib

# Paths for JSON files
indicator_json_path = 'indicator_values_HDFC1.json'
updated_json_path = 'updated_indicator_values41.json'
output_txt_path = 'output41.txt'  # Path for the output data file
output_terminal_path = 'output_terminal41.txt'  # Path for the terminal output file
order_data_json_path = 'order_data41.json'  # New file to save order details

# Initialize the FyersModel instance
client_id = open("client_id.txt", 'r').read().strip()
access_token = open("access_token.txt", 'r').read().strip()
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")

# Function to load JSON data from a file
def load_json_data(json_filename):
    try:
        with open(json_filename, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        log_message(f"File not found: {json_filename}")
        return None
    except json.JSONDecodeError as e:
        log_message(f"Error decoding JSON from {json_filename}: {e}")
        return None

# Function to save output to a text file
def save_output_to_txt(output, file_path):
    with open(file_path, 'a') as file:  # Open in append mode
        file.write(output + '\n')

# Function to log messages and save to terminal output file
def log_message(message):
    print(message)  # Print to console
    save_output_to_txt(message, output_terminal_path)  # Save to terminal output file

def save_indicator_data(data, json_filename):
    with open(json_filename, 'w') as file:
        json.dump(data, file, indent=4)


def convert_dict_to_serializable(data):
    if isinstance(data, dict):
        return {k: convert_dict_to_serializable(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [convert_dict_to_serializable(v) for v in data]
    else:
        return convert_to_serializable(data)

# Function to save order details to a JSON file
def save_order_data(symbol, order_id):
    order_data = load_json_data(order_data_json_path) or {}  # Load existing order data or start with an empty dict
    order_data[symbol] = order_id  # Save order id with symbol as the key
    save_indicator_data(order_data, order_data_json_path)  # Save to the JSON file
    log_message(f"Order ID {order_id} for {symbol} saved to {order_data_json_path}")

# Function to load order details from the JSON file
def load_order_data(symbol):
    order_data = load_json_data(order_data_json_path)
    if order_data and symbol in order_data:
        return order_data[symbol]
    return None

# Function to convert non-serializable objects (e.g., numpy types) to Python types
def convert_to_serializable(obj):
    if isinstance(obj, np.bool_):
        return bool(obj)  # Convert numpy boolean to Python boolean
    elif isinstance(obj, np.integer):
        return int(obj)  # Convert numpy integer to Python integer
    elif isinstance(obj, np.floating):
        return float(obj)  # Convert numpy floating-point to Python float
    else:
        return obj

# Function to convert dictionaries or lists to serializable formats
def convert_dict_to_serializable(data):
    if isinstance(data, dict):
        return {k: convert_dict_to_serializable(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [convert_dict_to_serializable(v) for v in data]
    else:
        return convert_to_serializable(data)

# Function to save indicator data to JSON
def save_indicator_data(data, json_filename):
    serializable_data = convert_dict_to_serializable(data)  # Convert data to serializable format
    with open(json_filename, 'w') as file:
        json.dump(serializable_data, file, indent=4)  # Save the serializable data to the JSON file
# Initialize the last order and trend variables

# Function to handle order placement based on trend changes (BUY only, modify PE to CE on sell signal)
def place_or_exit_order(fyers, current_st21Trend, all_timeframe_data):
    
    global last_order_type, previous_st21Trend
    
    # Retrieve 1-minute timeframe data
    data = all_timeframe_data["5min"]
    
    # Corrected condition for stb_signal and sts_signal
    stb_signal = (data["signals"]["buy_signal"] == True or
                  data["signals"]["best_buy_signal"] == True or
                  data["signals"]["strong_buy_signal"] == True)  # If any buy-related signal is true

    sts_signal = (data["signals"]["sell_signal"] == True or
                  data["signals"]["best_sell_signal"] == True or
                  data["signals"]["strong_sell_signal"] == True)  # If any sell-related signal is true

    # Define the PE (Put) and CE (Call) symbols
    symbol_pe = "NSE:BANKNIFTY24O2351300PE"  # PE contract
    symbol_ce = "NSE:BANKNIFTY24O2351300CE"  # CE contract

    # Check if trend has changed
    if previous_st21Trend is None or current_st21Trend != previous_st21Trend:
        
        # If last order was a BUY and now trend is SELL, modify to CE instead of placing a SELL order
        if last_order_type == "buy" and current_st21Trend == -1 and sts_signal:
            log_message("Trend changed to SELL. Modifying the order from PE to CE instead of placing SELL.")
            log_message(f"Sell signal: {sts_signal}")
            
            # Modify the order to CE (Call) contract
            modify_order_to_ce(symbol_ce)

        # If no previous orders exist, place the first BUY order based on the trend
        elif last_order_type is None:
            if current_st21Trend == 1 and stb_signal:
                log_message("Placing initial BUY order for PE.")
                buy_order = placeOrder(symbol_pe, "BUY", qty=15, order_type="MARKET")
                
                # Save the order ID and update order type if successful
                if buy_order['s'] == 'ok':
                    order_id = buy_order['id']  # Get the order ID from the response
                    save_order_data(symbol_pe, order_id)  # Save the order ID for future reference
                    last_order_type = "buy"  # Update the last order type to "buy"
                else:
                    log_message(f"Error placing initial BUY order for PE: {buy_order['message']}")
                    
            elif current_st21Trend == -1 and sts_signal:
                log_message("Trend is SELL, but will modify to CE. Avoiding SELL order for PE.")
                log_message(f"Sell signal: {sts_signal}")
                
                # Modify the order to CE (Call) contract
                modify_order_to_ce(symbol_ce)

        # Update the previous trend after placing the order
        previous_st21Trend = current_st21Trend


# Function to modify the order from PE to CE if the trend is SELL
def modify_order_to_ce(symbol_ce):
    log_message(f"Modifying order to CE: {symbol_ce}")
    buy_order = placeOrder(symbol_ce, "BUY", qty=15, order_type="MARKET")
    
    # Save the order ID if successful
    if buy_order['s'] == 'ok':
        order_id = buy_order['id']
        save_order_data(symbol_ce, order_id)
        log_message(f"BUY order placed for CE: {symbol_ce}")
    else:
        log_message(f"Error modifying to BUY order for CE: {buy_order['message']}")
