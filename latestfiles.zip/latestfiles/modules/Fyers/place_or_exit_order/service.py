import pandas as pd
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws
from modules.Fyers.service import save_to_json, load_from_json, fetchOHLC2, bollinger_bands, ema, atr, supertrend
from modules.Fyers.placeorder.placeorder_BO.service import placeOrderBracket
from modules.Fyers.signal.service import signal
from modules.Fyers.save_indicator_data.service import save_indicator_data
from modules.Fyers.placeorder.service import placeOrder
from modules.Fyers.signal.service import signal


#from modules.Fyers.save_indicator_data_every_min.service import run_save_indicator_data_every_minute


from modules.Fyers.placeorder.placeorderall.service import placeOrder, modifyOrder, cancelOrder
import datetime as dt
import pytz
import numpy as np
import time
import json
import os
import contextlib



# Paths for JSON files
indicator_json_path = 'indicator_values_BN.json'
updated_json_path = 'updated_indicator_valuesBN.json'
output_txt_path = 'outputBN.txt'  # Path for the output data file
output_terminal_path = 'output_terminalBN.txt'  # Path for the terminal output file
order_data_json_path = 'order_dataBN.json'  # New file to save order details

# Initialize the FyersModel instance
client_id = open("client_id.txt", 'r').read().strip()
access_token = open("access_token.txt", 'r').read().strip()
fyers = fyersModel.FyersModel(client_id=client_id, is_async=False, token=access_token, log_path="")

# Function to load JSON data from a file
def load_json_data(json_filename):
    try:
        with open(json_filename, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        log_message(f"File not found: {json_filename}")
        return None
    except json.JSONDecodeError as e:
        log_message(f"Error decoding JSON from {json_filename}: {e}")
        return None

# Function to save output to a text file
def save_output_to_txt(output, file_path):
    with open(file_path, 'a') as file:  # Open in append mode
        file.write(output + '\n')

# Function to load JSON data from a file
def load_json_data(json_filename):
    try:
        with open(json_filename, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        log_message(f"File not found: {json_filename}")
        return None
    except json.JSONDecodeError as e:
        log_message(f"Error decoding JSON from {json_filename}: {e}")
        return None

# Function to check if 'signals' exists in the data
def process_signals_data(data):
    if data:
        signals = data.get("signals", None)  # Use get to avoid KeyError
        if signals:
            # Proceed with signal processing
            # Example: log_message(f"Signals data: {signals}")
            return signals
        else:
            log_message("Signals data not found.")
            return None
    else:
        log_message("Data is None.")
        return None

# Function to log messages and save to terminal output file
def log_message(message):
    print(message)  # Print to console
    save_output_to_txt(message, output_terminal_path)  # Save to terminal output file

def save_indicator_data(data, json_filename):
    with open(json_filename, 'w') as file:
        json.dump(data, file, indent=4)


def convert_dict_to_serializable(data):
    if isinstance(data, dict):
        return {k: convert_dict_to_serializable(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [convert_dict_to_serializable(v) for v in data]
    else:
        return convert_to_serializable(data)

# Function to save order details to a JSON file
def save_order_data(symbol, order_id):
    order_data = load_json_data(order_data_json_path) or {}  # Load existing order data or start with an empty dict
    order_data[symbol] = order_id  # Save order id with symbol as the key
    save_indicator_data(order_data, order_data_json_path)  # Save to the JSON file
    log_message(f"Order ID {order_id} for {symbol} saved to {order_data_json_path}")

# Function to load order details from the JSON file
def load_order_data(symbol):
    order_data = load_json_data(order_data_json_path)
    if order_data and symbol in order_data:
        return order_data[symbol]
    return None

# Function to convert non-serializable objects (e.g., numpy types) to Python types
def convert_to_serializable(obj):
    if isinstance(obj, np.bool_):
        return bool(obj)  # Convert numpy boolean to Python boolean
    elif isinstance(obj, np.integer):
        return int(obj)  # Convert numpy integer to Python integer
    elif isinstance(obj, np.floating):
        return float(obj)  # Convert numpy floating-point to Python float
    else:
        return obj

# Function to convert dictionaries or lists to serializable formats
def convert_dict_to_serializable(data):
    if isinstance(data, dict):
        return {k: convert_dict_to_serializable(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [convert_dict_to_serializable(v) for v in data]
    else:
        return convert_to_serializable(data)

# Function to save indicator data to JSON
def save_indicator_data(data, json_filename):
    serializable_data = convert_dict_to_serializable(data)  # Convert data to serializable format
    with open(json_filename, 'w') as file:
        json.dump(serializable_data, file, indent=4)  # Save the serializable data to the JSON file
# Initialize the last order and trend variables
last_order_type = None
previous_st21Trend = None

#tickers = ["NSE:BANKNIFTY24O2351300PE"]


# Function to handle order placement based on trend changes (only BUY, modify PE/CE on SELL)# Function to handle order placement based on trend changes (only BUY, modify PE/CE on SELL)
def place_or_exit_order( current_st21Trend, all_timeframe_data, contract_params):
    # Get the signals from the data (add a fallback if signals are missing)
    
    signals = all_timeframe_data.get("signals", None)
    
    
    if signals is None:
        log_message("No signals found in the data. Exiting function.")
        return  # Exit or handle missing signals appropriately
    signals = all_timeframe_data['signals']

    # Extract relevant information from the signals
    stb_signal = signals.get("stb_signal", None)  # Strong Buy signal
    sts_signal = signals.get("sts_signal", None)  # Strong Sell signal
    # Define the PE (Put) and CE (Call) symbols
    symbol_pe = "NSE:BANKNIFTY24OCT51300PE"  # PE contract
    symbol_ce = "NSE:BANKNIFTY24OCT51300CE"  # CE contract
    # Log the extracted signals
    log_message(f"Strong Buy Signal: {stb_signal}, Strong Sell Signal: {sts_signal}")
    
    # Handling trend changes and placing orders
    if last_order_type == "buy" and current_st21Trend == -1 and sts_signal:
        log_message("Trend changed to SELL. Modifying the contract (PE to CE or CE to PE).")
        log_message(f"Sell signal detected: {sts_signal}")
        
        # Modify the contract between PE and CE (flip the current position)
        if symbol_pe in previous_st21Trend:
            modify_order_to_ce(symbol_ce)
        else:
            modify_order_to_pe(symbol_pe)

    elif last_order_type is None:
        if current_st21Trend == 1 and stb_signal:
            log_message("Placing initial BUY order for PE.")
            buy_order = placeOrder(symbol_pe, "BUY", qty=15, order_type="MARKET")
            
            if buy_order['s'] == 'ok':
                order_id = buy_order['id']
                save_order_data(symbol_pe, order_id)
                last_order_type = "buy"
            else:
                log_message(f"Error placing initial BUY order for PE: {buy_order['message']}")
                
        elif current_st21Trend == -1 and sts_signal:
            log_message("Trend is SELL, modifying to CE. Avoiding SELL order for PE.")
            log_message(f"Sell signal: {sts_signal}")
            modify_order_to_ce(symbol_ce)

    previous_st21Trend = current_st21Trend

# Function to modify the order to CE (Call) if the trend is SELL
def modify_order_to_ce(symbol_ce):
    log_message(f"Modifying order to CE: {symbol_ce}")
    buy_order = placeOrder(symbol_ce, "BUY", qty=15, order_type="MARKET")
    
    # Save the order ID if successful
    if buy_order['s'] == 'ok':
        order_id = buy_order['id']
        save_order_data(symbol_ce, order_id)
        log_message(f"BUY order placed for CE: {symbol_ce}")
    else:
        log_message(f"Error modifying to BUY order for CE: {buy_order['message']}")


# Function to modify the order to PE (Put) if the trend is BUY
def modify_order_to_pe(symbol_pe):
    log_message(f"Modifying order to PE: {symbol_pe}")
    buy_order = placeOrder(symbol_pe, "BUY", qty=15, order_type="MARKET")
    
    # Save the order ID if successful
    if buy_order['s'] == 'ok':
        order_id = buy_order['id']
        save_order_data(symbol_pe, order_id)
        log_message(f"BUY order placed for PE: {symbol_pe}")
    else:
        log_message(f"Error modifying to BUY order for PE: {buy_order['message']}")


# Function to modify or cancel orders using the saved order ID
def modify_or_cancel_order(symbol, action):
    order_id = load_order_data(symbol)  # Load the saved order ID for the symbol
    if order_id:
        if action == "modify":
            log_message(f"Modifying order {order_id} for {symbol}")
            modifyOrder(symbol, "SELL", qty=10, order_type="MARKET")  # Call modifyOrder with the order ID
        elif action == "cancel":
            log_message(f"Cancelling order {order_id} for {symbol}")
            cancelOrder(order_id)  # Call cancelOrder with the order ID
    else:
        log_message(f"No order ID found for {symbol}")
